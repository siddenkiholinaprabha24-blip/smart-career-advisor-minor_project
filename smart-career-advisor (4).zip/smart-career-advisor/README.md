# Smart Career Advisor — Full-Stack Project

This project has two parts:

- **`smart-career-advisor/`** — the original frontend. `index.html`, `css/style.css`,
  `js/data.js`, and `sql/schema.sql` are **unchanged**. Only `js/app.js` was edited,
  to replace `localStorage` calls with `fetch()` calls to the new backend.
- **`backend/`** — a new Flask + scikit-learn backend with a real trained ML model
  for career recommendation, and a SQLite database for users, assessments,
  financial plans, documents, and notifications.

## Quick start

```bash
cd backend
pip install -r requirements.txt --break-system-packages
python app.py
```

Then open **http://localhost:5000** — the Flask server serves the frontend directly, so there's nothing else to run separately.

Full details, architecture, API reference, and sample requests are in
[`backend/README.md`](backend/README.md).
