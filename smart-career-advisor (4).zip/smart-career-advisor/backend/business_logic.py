"""
business_logic.py — deterministic formulas ported 1:1 from the original
AIEngine object in js/data.js (loan probability, scholarship probability,
EMI, action plan, skill gap analysis). These are legitimate closed-form /
lookup-table computations, not classification problems, so they remain
rule-based by design — only the career-fit prediction (ml_engine.py) was a
genuine ML problem and was rebuilt as a trained model.
"""

from reference_data import CAREER_SLUGS, CAREER_TITLES, match_scholarships


def calc_loan_probability(marks12, family_income, loan_amount):
    s = 10
    s += 35 if marks12 >= 90 else 25 if marks12 >= 75 else 15 if marks12 >= 60 else 5
    s += 30 if family_income <= 300000 else 20 if family_income <= 600000 else 10 if family_income <= 1200000 else 5
    s += 25 if loan_amount <= 750000 else 15 if loan_amount <= 2000000 else 8
    return min(s, 97)


def calc_scholarship_probability(marks12, family_income, gender):
    p = 0
    p += 40 if marks12 >= 90 else 28 if marks12 >= 80 else 15 if marks12 >= 70 else 5
    p += 30 if family_income <= 250000 else 20 if family_income <= 500000 else 10 if family_income <= 800000 else 0
    if gender == "Female":
        p += 10
    return min(p, 95)


def generate_action_plan(marks12, family_income, career_id, gender, loan_prob, schol_prob, is_school_level=False):
    plan = []
    if marks12 < 75:
        plan.append(dict(step=1, action="Improve Academic Profile",
                          detail="Consider bridge courses or entrance coaching to strengthen academic credentials."))
    if not is_school_level and loan_prob is not None and loan_prob > 70:
        plan.append(dict(step=len(plan) + 1, action="Apply for Education Loan Early",
                          detail=f"Your loan approval probability is {loan_prob}%. Apply 3-6 months before admission."))
    if schol_prob > 50:
        matched = match_scholarships(marks12, family_income, career_id, gender)
        plan.append(dict(step=len(plan) + 1, action="Apply for Scholarships",
                          detail=f"You qualify for {len(matched)} scholarships. Apply before deadlines."))
    plan.append(dict(step=len(plan) + 1, action="Prepare Document Checklist",
                      detail="Upload all required documents in the Document Vault to speed up loan processing."))
    if not is_school_level:
        plan.append(dict(step=len(plan) + 1, action="Open Education Loan Account",
                          detail="Visit the nearest SBI/HDFC branch or apply online with pre-sanction for your institution."))
    return plan


def calc_emi(principal, annual_rate, n_months):
    r = annual_rate / 12 / 100
    if r == 0:
        return principal / n_months
    return principal * r * (1 + r) ** n_months / ((1 + r) ** n_months - 1)


def skill_gaps(math_score, english_score, tech_skills, research_interest, career_id):
    gaps = []
    if math_score < 75:
        gaps.append(dict(skill="Mathematics", gap=round(75 - math_score),
                          action="Enroll in JEE/GRE Math coaching"))
    if english_score < 70:
        gaps.append(dict(skill="Communication", gap=round(70 - english_score),
                          action="Join debate club / Toastmasters"))
    if tech_skills < 3 and career_id in (1, 4):
        gaps.append(dict(skill="Technical Skills", gap=(3 - tech_skills) * 20,
                          action="Learn Python / coding fundamentals"))
    if CAREER_SLUGS.get(career_id) == "abroad-ms" and research_interest < 2:
        gaps.append(dict(skill="Research Orientation", gap=30,
                          action="Take up a research project or publication under a mentor"))
    return gaps


def calc_readiness(marks12, suitability, tech_skills, communication, leadership):
    readiness = round(
        (marks12 * 0.35)
        + (suitability * 0.35)
        + (((tech_skills + communication + leadership) / 15) * 100 * 0.30)
    )
    return min(readiness, 99)


def career_title(career_id):
    return CAREER_TITLES.get(int(career_id), "Unknown")
