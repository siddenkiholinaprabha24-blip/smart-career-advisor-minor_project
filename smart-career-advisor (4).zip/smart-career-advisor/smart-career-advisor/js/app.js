// ============================================================
// Smart Career Advisor — app.js
// Full SPA Logic: Auth, Routing, Career Evaluator, Financial Hub
// ============================================================

'use strict';

// ── State ────────────────────────────────────────────────────
// NOTE: assessment, documents, financialPlan and notifications are now
// PER-USER data owned by the Flask + SQLite backend (see /api/* routes).
// Only the auth token and UI theme preference stay in localStorage — the
// token is how the browser proves who's logged in on the next visit; no
// user data itself is stored client-side anymore.
const API_BASE = window.SCA_API_BASE || '';

const State = {
  currentView: 'dashboard',
  user: null,
  assessment: null,
  documents: {},
  financialPlan: null,
  examPrep: {},
  selectedCareer: null,
  selectedLoan: null,
  notifications: [],
  evalStep: 1,
  evalData: {},
  theme: localStorage.getItem('sca_theme') || 'dark',
  coachFilter: {},
  notifShowAll: false,
};

// ── API client ───────────────────────────────────────────────
function getToken() { return localStorage.getItem('sca_token'); }
function setToken(t) { t ? localStorage.setItem('sca_token', t) : localStorage.removeItem('sca_token'); }

async function apiFetch(path, options = {}) {
  const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, Object.assign({}, options, { headers }));
  let body = null;
  try { body = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const message = (body && body.error) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return body;
}

const api = {
  register: (data) => apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify(data) }),
  login: (data) => apiFetch('/api/auth/login', { method: 'POST', body: JSON.stringify(data) }),
  me: () => apiFetch('/api/auth/me'),
  updateUser: (patch) => apiFetch('/api/users/me', { method: 'PUT', body: JSON.stringify(patch) }),

  createAssessment: (data) => apiFetch('/api/assessments', { method: 'POST', body: JSON.stringify(data) }),
  latestAssessment: () => apiFetch('/api/assessments/latest'),
  assessmentHistory: () => apiFetch('/api/assessments/history'),

  predictFinancial: (data) => apiFetch('/api/financial/predict', { method: 'POST', body: JSON.stringify(data) }),
  getFinancialPlan: () => apiFetch('/api/financial/plan'),
  clearFinancialPlan: () => apiFetch('/api/financial/plan', { method: 'DELETE' }),

  listDocuments: () => apiFetch('/api/documents'),
  uploadDocument: (data) => apiFetch('/api/documents/upload', { method: 'POST', body: JSON.stringify(data) }),

  listNotifications: () => apiFetch('/api/notifications'),
  createNotification: (data) => apiFetch('/api/notifications', { method: 'POST', body: JSON.stringify(data) }),
  markNotificationRead: (id) => apiFetch(`/api/notifications/${id}/read`, { method: 'PUT' }),

  // ML-backed admission-chance classifier — see backend/college_ml_engine.py.
  // candidates: [{clientId, relativeStrength, examType}, ...]
  predictCollegeChances: (candidates) => apiFetch('/api/colleges/predict-chance', { method: 'POST', body: JSON.stringify({ candidates }) }),
};

// Load the currently-logged-in user's own slice of data from the backend.
// Called right after login/register so accounts never see each other's data.
async function loadUserSlice() {
  const [assessmentRes, financialRes, documentsRes, notifRes] = await Promise.all([
    api.latestAssessment().catch(() => ({ assessment: null })),
    api.getFinancialPlan().catch(() => ({ plan: null })),
    api.listDocuments().catch(() => ({ documents: {} })),
    api.listNotifications().catch(() => ({ notifications: [] })),
  ]);
  State.assessment = assessmentRes.assessment || null;
  State.financialPlan = financialRes.plan || null;
  State.documents = documentsRes.documents || {};
  State.notifications = notifRes.notifications || [];
  State.examPrep = {};
}

function clearUserSlice() {
  State.assessment = null;
  State.documents = {};
  State.financialPlan = null;
  State.examPrep = {};
  State.notifications = [];
  State.coachFilter = {};
  State.notifShowAll = false;
}

// Push a local careerChoice/readinessScore/familyIncome/educationLevel
// change to the backend in the background (optimistic UI — State is
// already updated by the caller before this runs).
function syncUserProfile(patch) {
  api.updateUser(patch).catch(err => console.error('Profile sync failed:', err));
}

// ── Utility ──────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const fmt = n => '₹' + Number(n).toLocaleString('en-IN');
const fmtShort = n => n >= 1e7 ? `₹${(n/1e7).toFixed(1)}Cr` : n >= 1e5 ? `₹${(n/1e5).toFixed(1)}L` : fmt(n);
const pct = (val, max) => Math.min(100, Math.round(val / max * 100));

// Returns 'school' | 'inter' | 'poly' | 'grad' | null for whichever
// education level the logged-in student is currently at — used to gate
// content that only makes sense post-10th (competitive exams, college
// predictor) away from students who haven't reached that stage yet.
function currentEduGroup() {
  const level = State.user?.educationLevel || State.evalData.eduLevel;
  return EDUCATION_LEVELS.find(l => l.key === level)?.group || null;
}

// ── Theme ────────────────────────────────────────────────────
function applyTheme(t) {
  State.theme = t;
  document.documentElement.setAttribute('data-theme', t);
  $('theme-icon').textContent = t === 'dark' ? '☀️' : '🌙';
  localStorage.setItem('sca_theme', t);
}
function toggleTheme() { applyTheme(State.theme === 'dark' ? 'light' : 'dark'); }

// ── Auth ─────────────────────────────────────────────────────
function initAuth() {
  const eduSelect = $('reg-edulevel');
  if (eduSelect) {
    eduSelect.innerHTML = `<option value="" selected disabled>-- Select your education level --</option>` +
      EDUCATION_LEVELS.map(l => `<option value="${l.key}">${l.label}</option>`).join('');
  }

  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      $('login-form').classList.toggle('hidden', tab.dataset.tab !== 'login');
      $('register-form').classList.toggle('hidden', tab.dataset.tab !== 'register');
    });
  });

  $('login-btn').addEventListener('click', handleLogin);
  $('register-btn').addEventListener('click', handleRegister);

  $('reset-data-link')?.addEventListener('click', (e) => {
    e.preventDefault();
    if (confirm('This signs you out and clears this browser\'s saved session token. Continue?')) {
      setToken(null);
      showToast('Session cleared. You can register or log in fresh now.', 'success');
      setTimeout(() => location.reload(), 1200);
    }
  });

  [$('login-email'), $('login-password')].forEach(el =>
    el.addEventListener('keydown', e => e.key === 'Enter' && handleLogin())
  );
}

async function handleLogin() {
  const email = $('login-email').value.trim().toLowerCase();
  const pass  = $('login-password').value;
  if (!email || !pass) return showToast('Please fill all fields.', 'warning');
  try {
    const { user, token } = await api.login({ email, password: pass });
    setToken(token);
    await loginSuccess(user);
  } catch (err) {
    showToast(err.message || 'Invalid credentials. Please try again.', 'danger');
  }
}

async function handleRegister() {
  const name   = $('reg-name').value.trim();
  const email  = $('reg-email').value.trim().toLowerCase();
  const pass   = $('reg-password').value;
  const eduLevel = $('reg-edulevel')?.value;
  const gender = $('reg-gender')?.value;
  if (!name || !email || !pass) return showToast('Please fill all required fields.', 'warning');
  if (!eduLevel) return showToast('Please select your current education level.', 'warning');
  if (!gender) return showToast('Please select your gender.', 'warning');
  try {
    const { user, token } = await api.register({ name, email, password: pass, educationLevel: eduLevel, gender });
    setToken(token);
    await loginSuccess(user);
    showToast('Account created successfully! 🎉', 'success');
  } catch (err) {
    showToast(err.message || 'That email is already registered — try logging in instead, or use a different email.', 'danger');
  }
}

async function loginSuccess(user) {
  State.user = user;
  State.currentQuote = quoteOfTheDay();
  await loadUserSlice();
  State.evalData.eduLevel = State.assessment?.eduLevel || user.educationLevel || null;
  $('auth-screen').style.display = 'none';
  $('app-shell').classList.add('active');
  updateSidebarUser();
  navigateTo('dashboard');
  addNotification('Welcome back!', `Good to see you, ${user.name.split(' ')[0]}!`, 'success', '👋');
}

function handleLogout() {
  State.user = null;
  setToken(null);
  clearUserSlice();
  $('app-shell').classList.remove('active');
  $('auth-screen').style.display = 'flex';
  $('login-email').value = '';
  $('login-password').value = '';
}

// Restore a session from a saved token on page load (e.g. after a refresh).
async function tryRestoreSession() {
  const token = getToken();
  if (!token) return false;
  try {
    const { user } = await api.me();
    await loginSuccess(user);
    return true;
  } catch (err) {
    setToken(null);
    return false;
  }
}

function updateSidebarUser() {
  if (!State.user) return;
  $('sb-avatar').textContent = State.user.name.charAt(0).toUpperCase();
  $('sb-name').textContent = State.user.name.split(' ')[0];
  $('sb-career').textContent = State.user.careerChoice || 'No career selected';
  $('header-user-name').textContent = State.user.name.split(' ')[0];
  updateReadinessBadge();
}

function updateReadinessBadge() {
  const score = State.assessment?.readinessScore || State.user?.readinessScore || 0;
  $('readiness-badge').textContent = `🎯 Readiness: ${score}%`;
}

// ── Router ───────────────────────────────────────────────────
function navigateTo(view) {
  State.currentView = view;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const viewEl = $(`view-${view}`);
  if (viewEl) viewEl.classList.add('active');
  const navEl = document.querySelector(`.nav-item[data-view="${view}"]`);
  if (navEl) navEl.classList.add('active');
  $('header-title').textContent = VIEW_TITLES[view] || 'Dashboard';
  // Render page
  const renderers = {
    dashboard: renderDashboard,
    evaluator: renderEvaluator,
    exams: renderExams,
    colleges: renderColleges,
    govtjobs: renderGovtJobs,
    financial: renderFinancial,
    notifications: renderNotifications,
  };
  if (renderers[view]) renderers[view]();
  window.scrollTo(0,0);
}

const VIEW_TITLES = {
  dashboard: 'Dashboard Overview',
  evaluator: 'Career Evaluator',
  exams: 'Exam Guidance',
  colleges: 'College & Fee Finder',
  govtjobs: 'Government Jobs Guidance',
  financial: 'Financial Guidance Hub',
  notifications: 'Notifications',
};

// ── Sidebar toggle ───────────────────────────────────────────
function initSidebar() {
  $('sidebar-toggle').addEventListener('click', () => {
    $('sidebar').classList.toggle('collapsed');
  });
  document.querySelectorAll('.nav-item[data-view]').forEach(item => {
    item.addEventListener('click', () => navigateTo(item.dataset.view));
  });
  $('logout-btn').addEventListener('click', handleLogout);
  $('theme-toggle').addEventListener('click', toggleTheme);
  $('notif-btn').addEventListener('click', toggleNotifDropdown);
  document.addEventListener('click', e => {
    if (!e.target.closest('#notif-btn') && !e.target.closest('#notif-dropdown')) {
      $('notif-dropdown')?.classList.remove('open');
    }
  });
}

function toggleNotifDropdown() {
  $('notif-dropdown').classList.toggle('open');
  renderNotifDropdown();
}

// ── Toast ────────────────────────────────────────────────────
function showToast(msg, type = 'info') {
  const t = document.createElement('div');
  t.className = `alert alert-${type}`;
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;max-width:360px;min-width:260px;animation:fadeSlideUp 0.35s ease;';
  t.innerHTML = `<span class="alert-icon">${{info:'ℹ️',success:'✅',warning:'⚠️',danger:'❌'}[type]||'ℹ️'}</span><span>${msg}</span>`;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

function addNotification(title, msg, type, icon, examId = null) {
  const tempId = 'tmp-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  State.notifications.unshift({ id: tempId, title, msg, type, icon, time: 'Just now', read: false, examId });
  updateNotifBadge();
  if (State.user) {
    api.createNotification({ title, msg, type, icon, examId }).then(saved => {
      const n = State.notifications.find(n => n.id === tempId);
      if (n) n.id = saved.id;
    }).catch(err => console.error('Failed to save notification:', err));
  }
}

function updateNotifBadge() {
  const unread = State.notifications.filter(n => !n.read).length;
  const dot = document.querySelector('.notif-dot');
  if (dot) dot.style.display = unread > 0 ? 'block' : 'none';
  const badge = $('notif-count');
  if (badge) badge.textContent = unread;
}

function renderNotifDropdown() {
  const list = $('notif-list-dd');
  if (!list) return;
  list.innerHTML = State.notifications.slice(0, 5).map(n => `
    <div class="notif-item" onclick="markNotifRead(${n.id})">
      <div class="notif-item-icon" style="background:rgba(99,102,241,0.12)">${n.icon}</div>
      <div>
        <div class="notif-title ${n.read ? 'text-muted' : ''}">${n.title}</div>
        <div class="notif-time">${n.time}</div>
      </div>
    </div>`).join('');
}

function markNotifRead(id) {
  const n = State.notifications.find(n => n.id === id);
  if (n) n.read = true;
  updateNotifBadge();
  renderNotifDropdown();
  if (typeof id === 'number') {
    api.markNotificationRead(id).catch(err => console.error('Failed to mark notification read:', err));
  }
}

// ============================================================
// VIEW: DASHBOARD
// ============================================================
function renderDashboard() {
  const career = DB.careers.find(c => c.slug === State.user?.careerChoice) || null;
  const score  = State.assessment?.readinessScore || 0;
  const docsUploaded = Object.values(State.documents).filter(d => d === 'uploaded').length;
  const totalDocs = DB.docTypes.filter(d => d.required).length;
  const q = State.currentQuote || (State.currentQuote = quoteOfTheDay());
  const selectedExamId = State.user?.selectedExamId || null;
  const selectedExam = selectedExamId ? DB.exams.find(e => e.id === selectedExamId) : null;

  $('view-dashboard').innerHTML = `
  <div class="section-header">
    <div class="section-title">Welcome back, ${State.user?.name?.split(' ')[0] || 'Student'} 👋</div>
    <div class="section-sub">Here's your career readiness overview for today.</div>
  </div>

  <div class="card mb-6" style="background:linear-gradient(135deg,rgba(99,102,241,0.12),rgba(139,92,246,0.08));border:1px solid rgba(99,102,241,0.25)">
    <div class="card-body flex items-center gap-3">
      <div style="font-size:26px">💬</div>
      <div><div class="text-sm" style="font-style:italic">"${q.text}"</div><div class="text-xs text-muted mt-1">— ${q.author}</div></div>
    </div>
  </div>

  <div class="grid grid-4 mb-6">
    ${statCard('Career Readiness', `${score}%`, '📊', score >= 70 ? 'up' : '', score >= 70 ? '↑ Strong profile' : 'Keep improving', '#6366f1')}
    ${statCard('Target Career', career?.title || 'Not Set', '🎯', '', career ? `${career.durationYears}yr program` : 'Select a career', '#10b981')}
    ${statCard('Documents Ready', `${docsUploaded}/${totalDocs}`, '📁', docsUploaded === totalDocs ? 'up' : '', docsUploaded === totalDocs ? 'All uploaded ✓' : `${totalDocs - docsUploaded} pending`, '#f59e0b')}
    ${statCard('Scholarships', matchedScholarshipsCount(), '🏆', 'up', 'Eligible schemes', '#ec4899')}
  </div>

  <div class="grid grid-2 mb-6">
    <div class="card">
      <div class="card-body">
        <div class="flex items-center justify-between mb-4">
          <div class="font-display font-bold" style="font-size:16px">Career Readiness Score</div>
          <span class="tag tag-accent">AI Evaluated</span>
        </div>
        ${renderCircularProgress(score, 120, '#6366f1', 'Overall Score')}
        <div class="skill-bars mt-4">
          ${skillBar('Academic Strength', State.assessment?.mathScore || 0, '#6366f1')}
          ${skillBar('Career Suitability', State.assessment?.suitabilityScore || 0, '#10b981')}
          ${skillBar('Document Readiness', pct(docsUploaded, totalDocs), '#f59e0b')}
          ${skillBar('Financial Planning', State.financialPlan ? 75 : 20, '#ec4899')}
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-4" style="font-size:16px">Choose Your Career Path</div>
        <div class="grid" style="grid-template-columns:1fr 1fr;gap:10px">
          ${DB.careers.map(c => `
          <div class="career-card ${State.user?.careerChoice === c.slug ? 'selected' : ''}" onclick="selectCareerDash('${c.slug}')">
            <div class="career-card-banner" style="background:${c.gradient}">${c.icon}</div>
            <div class="career-card-body">
              <div class="career-card-title" style="font-size:13px">${c.title}</div>
              <div class="career-card-tags">
                <span class="tag tag-accent" style="font-size:10px">${c.durationYears}yr</span>
                <span class="tag tag-green" style="font-size:10px">${c.marketDemand}</span>
              </div>
            </div>
          </div>`).join('')}
        </div>
      </div>
    </div>
  </div>

  ${selectedExam ? renderExamFocusHub(selectedExam) : renderExamSelectionGate()}
  `;
}

// Shown when the student hasn't chosen which exam to prepare for yet — the
// full exam catalogue (optionally narrowed to their chosen career) is only
// visible here, in this one-time picker. Once chosen, the dashboard switches
// to the focused hub below and stops listing every exam.
function renderExamSelectionGate() {
  const careerFilter = State.user?.careerChoice;
  const career = DB.careers.find(c => c.slug === careerFilter);
  const exams = careerFilter ? DB.exams.filter(e => e.careerId === career?.id) : DB.exams;
  return `
  <div class="card">
    <div class="card-body">
      <div class="font-display font-bold mb-1" style="font-size:16px">🎯 Which exam are you preparing for?</div>
      <div class="text-sm text-muted mb-4">Pick one exam and your dashboard will focus on just that exam's notifications, coaching classes, books and study plan — instead of showing every exam at once.</div>
      <div class="grid grid-3" style="gap:10px">
        ${exams.map(e => `
        <div class="career-card" style="cursor:pointer" onclick="selectDashboardExam(${e.id})">
          <div class="career-card-body" style="padding:14px">
            <div class="font-bold text-sm">${e.name}</div>
            <div class="text-xs text-muted mt-1">${e.conductingBody} · ${e.examDate}</div>
          </div>
        </div>`).join('')}
      </div>
      ${!careerFilter ? `<div class="text-xs text-muted mt-3">💡 Tip: pick a career above first to narrow this list down.</div>` : ''}
    </div>
  </div>`;
}

// Shown once an exam is selected — everything here is scoped to that one
// exam only (notifications, coaching classes, books, study plan).
function renderExamFocusHub(exam) {
  generateExamNotifications(exam.id); // idempotent — seeds exam-specific alerts once
  const examNotifs = State.notifications.filter(n => n.examId === exam.id).slice(0, 5);
  const books = BOOKS_BY_EXAM[exam.id] || [];
  const plan = studyPlanForExam(exam);

  return `
  <div class="section-header flex items-center justify-between mt-2">
    <div><div class="section-title" style="font-size:20px">📌 ${exam.name} Prep Hub</div>
    <div class="section-sub">Everything below is scoped to ${exam.name} only.</div></div>
    <button class="btn btn-secondary btn-sm" onclick="changeDashboardExam()">🔄 Change Exam</button>
  </div>

  <div class="grid grid-3 mb-6">
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-4" style="font-size:15px">⏰ Key Dates</div>
        <div class="flex items-center justify-between mb-3"><div class="text-sm">📝 Registration</div><span class="tag tag-accent" style="font-size:11px">${exam.regDate}</span></div>
        <div class="flex items-center justify-between mb-3"><div class="text-sm">📅 Exam Date</div><span class="tag tag-accent" style="font-size:11px">${exam.examDate}</span></div>
        <div class="flex items-center justify-between"><div class="text-sm">🔁 Frequency</div><span class="tag" style="font-size:11px">${exam.frequency}</span></div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-4" style="font-size:15px">💡 Quick Actions</div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <button class="btn btn-primary btn-sm" onclick="navigateTo('colleges')">🏫 Predict My Colleges</button>
          <button class="btn btn-secondary btn-sm" onclick="navigateTo('financial')">💰 Plan Finances</button>
          <button class="btn btn-secondary btn-sm" onclick="copySyllabusForExam(${exam.id})">📋 Copy Syllabus</button>
          <a href="${exam.url}" target="_blank" class="btn btn-secondary btn-sm" style="text-align:center;text-decoration:none">🌐 Official Website</a>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-4" style="font-size:15px">🔔 ${exam.name} Notifications</div>
        ${examNotifs.length ? examNotifs.map(n => `
        <div class="flex gap-3 mb-3">
          <span style="font-size:18px">${n.icon}</span>
          <div><div class="text-sm ${n.read?'text-muted':''}">${n.title}</div><div class="text-xs text-muted mt-1">${n.msg}</div></div>
        </div>`).join('') : `<div class="text-sm text-muted">No alerts for this exam yet.</div>`}
        <a href="#" onclick="navigateTo('notifications');return false;" style="font-size:12px;color:var(--accent);text-decoration:underline">View all →</a>
      </div>
    </div>
  </div>

  <div class="card mb-6">
    <div class="card-body">
      <div class="flex items-center justify-between mb-2 flex-wrap gap-2">
        <div class="font-display font-bold" style="font-size:16px">🏫 Best Coaching Classes for ${exam.name}</div>
        <span class="tag tag-accent">Online + Offline · All India</span>
      </div>
      <div class="grid grid-3 gap-3 mb-4">
        <select class="form-input" id="coach-mode-filter" onchange="onCoachModeChange()">
          <option value="">All Modes (Online + Offline)</option>
          <option value="Online" ${State.coachFilter?.mode==='Online'?'selected':''}>Online only</option>
          <option value="Offline" ${State.coachFilter?.mode==='Offline'?'selected':''}>Offline only</option>
        </select>
        <select class="form-input" id="coach-state-filter" onchange="onCoachStateChange()">
          <option value="">All States (India)</option>
          ${Object.keys(INDIA_STATES_DISTRICTS).map(s=>`<option value="${s}" ${State.coachFilter?.state===s?'selected':''}>${s}</option>`).join('')}
        </select>
        <select class="form-input" id="coach-district-filter" onchange="onCoachDistrictChange()" ${!State.coachFilter?.state?'disabled':''}>
          <option value="">${State.coachFilter?.state ? 'All Districts' : 'Select a state first'}</option>
          ${(INDIA_STATES_DISTRICTS[State.coachFilter?.state] || []).map(d=>`<option value="${d}" ${State.coachFilter?.district===d?'selected':''}>${d}</option>`).join('')}
        </select>
      </div>
      ${renderCoachingList(exam.id)}
    </div>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-3" style="font-size:15px">📖 Recommended Books</div>
        ${books.length ? books.map(b=>`<div class="text-sm mb-2">📘 ${b}</div>`).join('') : `<div class="text-sm text-muted">No book list available for this exam yet.</div>`}
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="flex items-center justify-between mb-3">
          <div class="font-display font-bold" style="font-size:15px">🗓️ Study Plan & Syllabus</div>
          <button class="btn btn-secondary btn-sm" onclick="copySyllabusForExam(${exam.id})">📋 Copy Syllabus</button>
        </div>
        ${plan.weeks.map(w => `<div class="mb-2"><div class="font-bold text-sm">${w.phase}</div><div class="text-xs text-muted">${w.focus}</div></div>`).join('')}
        <div class="divider"></div>
        <div class="font-bold text-sm mb-2">Syllabus</div>
        ${plan.syllabus.map(s=>`<div class="text-xs text-muted mb-1">• ${s}</div>`).join('')}
      </div>
    </div>
  </div>`;
}

function renderCoachingList(examId) {
  let list = coachingForExam(examId);
  const f = State.coachFilter || {};
  if (f.mode) list = list.filter(c => c.mode === f.mode);
  if (f.state) list = list.filter(c => c.mode === 'Online' || c.state === f.state);
  if (f.district) list = list.filter(c => c.mode === 'Online' || c.district === f.district);

  const locationLabel = f.district ? `${f.district}, ${f.state}` : (f.state || null);
  const hasOffline = list.some(c => c.mode === 'Offline');
  const noticeHTML = (locationLabel && !hasOffline && f.mode !== 'Online')
    ? `<div class="alert alert-warning mb-3"><span class="alert-icon">⚠️</span> No offline coaching centres listed yet for this exam in ${locationLabel} — showing nearby/online options below. Try a different district, or use one of the online programs which are available Pan-India.</div>`
    : '';

  if (!list.length) return noticeHTML + `<div class="text-sm text-muted" style="padding:12px">No coaching classes matched this filter — try widening it (e.g. All States, All Modes).</div>`;

  return noticeHTML + `<div class="grid grid-2 gap-3">
    ${list.map(c => `
    <div style="background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;padding:12px">
      <div class="flex items-center justify-between mb-1">
        <div class="font-bold text-sm">${c.name}</div>
        <span class="tag ${c.mode==='Online'?'tag-blue':'tag-green'}" style="font-size:10px">${c.mode==='Online'?'💻 Online':'🏫 Offline'}</span>
      </div>
      <div class="text-xs text-muted">${c.mode==='Online' ? '🌐 Pan-India' : `📍 ${c.city}, ${c.state}`}</div>
      <div class="text-xs text-muted mt-1">💰 ${c.fees}</div>
      ${c.mode==='Online' ? `<a href="${c.link}" target="_blank" class="text-xs" style="color:var(--accent);text-decoration:underline">Visit site →</a>` : `<div class="text-xs text-muted">📞 ${c.phone||'Contact institute'}</div>`}
    </div>`).join('')}
  </div>`;
}

function onCoachModeChange() {
  State.coachFilter = { ...(State.coachFilter||{}), mode: $('coach-mode-filter').value };
  renderDashboard();
}
function onCoachStateChange() {
  State.coachFilter = { ...(State.coachFilter||{}), state: $('coach-state-filter').value, district: '' };
  renderDashboard();
}
function onCoachDistrictChange() {
  State.coachFilter = { ...(State.coachFilter||{}), district: $('coach-district-filter').value };
  renderDashboard();
}

function selectDashboardExam(examId) {
  if (!State.user) return;
  State.user.selectedExamId = examId;
  State.coachFilter = {};
  syncUserProfile({ selectedExamId: examId });
  renderDashboard();
  const exam = DB.exams.find(e => e.id === examId);
  showToast(`Focused your dashboard on ${exam?.name || 'this exam'} ✓`, 'success');
}

function changeDashboardExam() {
  if (!State.user) return;
  State.user.selectedExamId = null;
  syncUserProfile({ selectedExamId: null });
  renderDashboard();
}

function copySyllabusForExam(examId) {
  const text = copySyllabusText(examId);
  if (!text) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(
      () => showToast('Syllabus copied to clipboard 📋', 'success'),
      () => showToast('Could not copy — please copy manually.', 'warning')
    );
  } else {
    showToast('Clipboard not available in this browser.', 'warning');
  }
}

// Seeds a small set of exam-specific notifications the first time an exam
// is selected (idempotent — checks for an existing marker before adding).
function generateExamNotifications(examId) {
  const exam = DB.exams.find(e => e.id === examId);
  if (!exam) return;
  const already = State.notifications.some(n => n.examId === examId);
  if (already) return;
  addNotification(`${exam.name} Registration Window`, `Registrations for ${exam.name} typically open around ${exam.regDate}. Keep documents ready.`, 'info', '📋', examId);
  addNotification(`${exam.name} Exam Date`, `${exam.name} is usually conducted around ${exam.examDate} (${exam.frequency}).`, 'warning', '📅', examId);
  if (exam.feeWaiver) addNotification(`${exam.name} Fee Waiver`, exam.feeWaiver, 'success', '🎗️', examId);
}

function statCard(label, value, icon, changeType, change, color) {
  return `<div class="stat-card">
    <div class="stat-label">${icon} ${label}</div>
    <div class="stat-value" style="color:${color}">${value}</div>
    <div class="stat-change ${changeType}">${change}</div>
  </div>`;
}

function matchedScholarshipsCount() {
  if (!State.user) return '0';
  const profile = { careerId: DB.careers.find(c => c.slug === State.user.careerChoice)?.id || 1, marks12: State.assessment?.marks12 || 75, familyIncome: State.user.familyIncome || 600000, gender: 'Male', state: '' };
  return AIEngine.matchScholarships(profile).length;
}

function skillBar(label, val, color) {
  return `<div class="skill-bar-item">
    <div class="skill-bar-meta"><span class="skill-name text-sm">${label}</span><span class="skill-pct">${Math.round(val)}%</span></div>
    <div class="progress-bar-wrap"><div class="progress-bar-fill" style="width:${val}%;background:${color}"></div></div>
  </div>`;
}

function renderCircularProgress(val, size, color, sub) {
  const r = (size - 20) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (val / 100) * circ;
  return `<div class="circular-progress" style="width:${size}px;height:${size}px">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle class="cp-bg" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="10"/>
      <circle class="cp-fill" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="10"
        stroke="${color}" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
    </svg>
    <div class="cp-label">
      <span class="cp-value" style="color:${color}">${val}%</span>
      <span class="cp-sub">${sub}</span>
    </div>
  </div>`;
}

function upcomingDeadlines() {
  const items = [
    { name:'JEE Main Registration', date:'15 Nov', color:'#6366f1' },
    { name:'NSP Scholarship',        date:'31 Oct', color:'#10b981' },
    { name:'NEET UG Form',           date:'10 Mar', color:'#f59e0b' },
    { name:'UPSC Prelims',           date:'20 Feb', color:'#ec4899' },
  ];
  return items.map(i => `
    <div class="flex items-center justify-between mb-3">
      <div class="flex items-center gap-2">
        <div style="width:8px;height:8px;border-radius:50%;background:${i.color};flex-shrink:0"></div>
        <span class="text-sm">${i.name}</span>
      </div>
      <span class="tag tag-accent" style="font-size:11px">${i.date}</span>
    </div>`).join('');
}

function announcements() {
  const items = [
    { icon:'📣', text:'NEET 2025 seat allotment round 3 announced', time:'Today' },
    { icon:'🎓', text:'New IIT campuses to open in 5 more states', time:'2 days ago' },
    { icon:'💰', text:'SBI Education Loan interest rate revised to 8.15%', time:'1 week ago' },
  ];
  return items.map(i => `
    <div class="flex gap-3 mb-3">
      <span style="font-size:18px">${i.icon}</span>
      <div><div class="text-sm">${i.text}</div><div class="text-xs text-muted mt-1">${i.time}</div></div>
    </div>`).join('');
}

function selectCareerDash(slug) {
  if (State.user) { State.user.careerChoice = slug; syncUserProfile({ careerChoice: slug }); }
  State.selectedCareer = DB.careers.find(c => c.slug === slug);
  updateSidebarUser();
  renderDashboard();
  showToast(`Career set to ${State.selectedCareer.title} ✓`, 'success');
}

// ============================================================
// VIEW: CAREER EVALUATOR
// ============================================================
function renderEvaluator() {
  $('view-evaluator').innerHTML = `
  <div class="section-header">
    <div class="section-title">🧠 AI Career Evaluator</div>
    <div class="section-sub">We ask about your current education first, then your goals — so every question after that is tailored to you.</div>
  </div>
  <div class="steps-track" id="eval-steps"></div>
  <div class="card"><div class="card-body" id="eval-step-content"></div></div>
  ${State.assessment ? `<div class="card mt-4"><div class="card-body" id="eval-results"></div></div>` : ''}`;
  renderEvalStep(State.evalStep);
  if (State.assessment) renderAssessmentResults();
}

const EVAL_STEP_LABELS = ['Education','Academics','Family','Skills','Interests','Career','Results'];

function renderEvalStep(step) {
  $('eval-steps').innerHTML = EVAL_STEP_LABELS.map((s, i) => `
    <div class="step-dot ${i+1 === step ? 'active' : i+1 < step ? 'complete' : ''}">
      <div class="step-dot-circle">${i+1 < step ? '✓' : i+1}</div>
      <div class="step-dot-label">${s}</div>
    </div>`).join('');

  const content = $('eval-step-content');
  const d = State.evalData;

  if (step === 1) {
    const level = EDUCATION_LEVELS.find(l => l.key === d.eduLevel);
    content.innerHTML = `
      <h3 class="font-display mb-2" style="font-size:18px">Step 1: Your Current Education Level</h3>
      <div class="text-sm text-muted mb-4">Tell us where you are right now — we'll ask about your goals next, based on this.</div>
      <div class="form-group mb-4">
        <label class="form-label">Current Education Level</label>
        <select class="form-input" id="ev-edulevel" onchange="onEduLevelChange()">
          <option value="" ${!d.eduLevel ? 'selected' : ''} disabled>-- Select your education level --</option>
          ${EDUCATION_LEVELS.map(l => `<option value="${l.key}" ${d.eduLevel===l.key?'selected':''}>${l.label}</option>`).join('')}
        </select>
      </div>
      <div id="edu-path-wrap">${renderEduPathBlock(level)}</div>
      <button class="btn btn-primary mt-4" onclick="evalNext(1)">Next: Academic Profile →</button>`;
  } else if (step === 2) {
    const level = EDUCATION_LEVELS.find(l => l.key === d.eduLevel);
    const group = level?.group;
    const isAdvanced = group === 'grad';
    content.innerHTML = `
      <h3 class="font-display mb-4" style="font-size:18px">Step 2: Academic Profile</h3>
      <div class="grid grid-2 gap-4">
        <div class="form-group">
          <label class="form-label">Current Education</label>
          <input class="form-input" value="${level?.label || ''}" disabled>
        </div>
        ${group === 'school' ? renderStreamInterestField(d) : `
        <div class="form-group"><label class="form-label">Stream / Specialisation</label>
          <input type="text" class="form-input" id="ev-stream" placeholder="e.g. MPC, CSE, Commerce..." value="${d.stream||''}"></div>`}
        ${group === 'school' ? '' : `
        <div class="form-group"><label class="form-label">${isAdvanced ? 'Current CGPA / Percentage' : 'Class 12 / Latest Overall %'}</label>
          <input type="number" class="form-input" id="ev-marks12" placeholder="e.g. 88" min="0" max="100" value="${d.marks12||''}"></div>`}
        <div class="form-group"><label class="form-label">Class 10 Overall %</label>
          <input type="number" class="form-input" id="ev-marks10" placeholder="e.g. 92" min="0" max="100" value="${d.marks10||''}"></div>
      </div>
      <div class="flex gap-3 mt-4">
        <button class="btn btn-secondary" onclick="evalNext(0)">← Back</button>
        <button class="btn btn-primary" onclick="evalNext(2)">Next: Family Background →</button>
      </div>`;
  } else if (step === 3) {
    content.innerHTML = `
      <h3 class="font-display mb-4" style="font-size:18px">Step 3: Family Background</h3>
      <div class="grid grid-2 gap-4">
        <div class="form-group"><label class="form-label">Annual Family Income (₹)</label>
          <input type="number" class="form-input" id="ev-income" placeholder="e.g. 500000" value="${d.familyIncome||State.user?.familyIncome||''}"></div>
        <div class="form-group"><label class="form-label">Gender</label>
          <select class="form-input" id="ev-gender">
            <option value="Male" ${(d.gender||State.user?.gender)==='Male'?'selected':''}>Male</option>
            <option value="Female" ${(d.gender||State.user?.gender)==='Female'?'selected':''}>Female</option>
            <option value="Other" ${(d.gender||State.user?.gender)==='Other'?'selected':''}>Other</option>
          </select>
          ${State.user?.gender ? `<div class="text-xs text-muted mt-1">Pre-filled from your registration — change here any time.</div>` : ''}</div>
      </div>
      <div class="text-xs text-muted mt-1">Family income helps us match you to scholarships and estimate loan/scholarship eligibility — it's never shared anywhere.</div>
      <div class="flex gap-3 mt-4">
        <button class="btn btn-secondary" onclick="evalNext(0)">← Back</button>
        <button class="btn btn-primary" onclick="evalNext(3)">Next: Skills →</button>
      </div>`;
  } else if (step === 4) {
    const selected = d.skills || [];
    content.innerHTML = `
      <h3 class="font-display mb-2" style="font-size:18px">Step 4: Your Skills</h3>
      <div class="text-sm text-muted mb-4">Select all the skills that describe you — pick as many as apply.</div>
      <div class="flex gap-2" style="flex-wrap:wrap">
        ${SKILLS_LIST.map(sk => `
        <label style="display:inline-flex;align-items:center;gap:6px;background:${selected.includes(sk) ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.05)'};border:1px solid ${selected.includes(sk) ? 'var(--accent)' : 'var(--border)'};border-radius:20px;padding:8px 16px;cursor:pointer;font-size:14px">
          <input type="checkbox" class="ev-skill-cb" value="${sk}" ${selected.includes(sk)?'checked':''} style="accent-color:var(--accent)">
          ${sk}
        </label>`).join('')}
      </div>
      <div class="flex gap-3 mt-4">
        <button class="btn btn-secondary" onclick="evalNext(0)">← Back</button>
        <button class="btn btn-primary" onclick="evalNext(4)">Next: Interests →</button>
      </div>`;
  } else if (step === 5) {
    content.innerHTML = `
      <h3 class="font-display mb-2" style="font-size:18px">Step 5: Research Interest</h3>
      <div class="text-sm text-muted mb-4">How interested are you in research-oriented work (higher studies, R&D, academia)?</div>
      <div class="flex gap-2" style="flex-wrap:wrap">
        ${RESEARCH_INTEREST_SCALE.map(r => `
        <label style="display:inline-flex;align-items:center;gap:8px;background:${d.researchInterest==r.v ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.05)'};border:1px solid ${d.researchInterest==r.v ? 'var(--accent)' : 'var(--border)'};border-radius:12px;padding:12px 16px;cursor:pointer;font-size:14px">
          <input type="radio" name="ev-research" value="${r.v}" ${d.researchInterest==r.v?'checked':''} style="accent-color:var(--accent)">
          <span><strong>${r.v}</strong> — ${r.label}</span>
        </label>`).join('')}
      </div>
      <div class="flex gap-3 mt-4">
        <button class="btn btn-secondary" onclick="evalNext(0)">← Back</button>
        <button class="btn btn-primary" onclick="evalNext(5)">Next: Preferred Career →</button>
      </div>`;
  } else if (step === 6) {
    content.innerHTML = `
      <h3 class="font-display mb-4" style="font-size:18px">Step 6: Preferred Career</h3>
      <div class="form-group mb-4"><label class="form-label">Choose Career *</label>
        <select class="form-input" id="ev-careerId">
          <option value="" ${!d.careerId?'selected':''} disabled>-- Choose Career --</option>
          ${DB.careers.map(c=>`<option value="${c.id}" ${d.careerId==c.id?'selected':''}>${c.icon} ${c.title}</option>`).join('')}
        </select></div>
      <div class="grid grid-2 gap-4">
        <div class="form-group"><label class="form-label">Interested in Government Jobs?</label>
          <select class="form-input" id="ev-govtInterest" onchange="onGovtInterestChange()">
            <option value="No" ${d.govtInterest!=='Yes'?'selected':''}>No</option>
            <option value="Yes" ${d.govtInterest==='Yes'?'selected':''}>Yes</option>
          </select></div>
        <div class="form-group"><label class="form-label">Interested in Higher Education?</label>
          <select class="form-input" id="ev-higherEdInterest">
            <option value="No" ${d.higherEdInterest!=='Yes'?'selected':''}>No</option>
            <option value="Yes" ${d.higherEdInterest==='Yes'?'selected':''}>Yes</option>
          </select></div>
      </div>
      <div class="form-group mb-4 ${d.govtInterest==='Yes'?'':'hidden'}" id="ev-govtcat-wrap">
        <label class="form-label">Preferred Government Job Category</label>
        <select class="form-input" id="ev-govtCategory">
          <option value="">-- Any / Not sure yet --</option>
          ${GOVT_JOBS.map(g=>`<option value="${g.key}" ${d.govtCategory===g.key?'selected':''}>${g.icon} ${g.name}</option>`).join('')}
        </select>
      </div>
      <div class="flex gap-3 mt-4">
        <button class="btn btn-secondary" onclick="evalNext(0)">← Back</button>
        <button class="btn btn-success" onclick="evalNext(6)">🚀 Generate Assessment</button>
      </div>`;
  }
}

// Shown instead of "Stream/Specialisation" for 10th-class students, who
// haven't chosen a stream yet — asks what they're interested in based on
// the Intermediate/Polytechnic choice made in Step 1.
function renderStreamInterestField(d) {
  const opts = STREAM_INTEREST_OPTIONS[d.eduPath] || [...STREAM_INTEREST_OPTIONS['Intermediate'], ...STREAM_INTEREST_OPTIONS['Polytechnic']];
  return `
    <div class="form-group">
      <label class="form-label">Which stream/branch are you interested in?</label>
      <select class="form-input" id="ev-streaminterest">
        <option value="" ${!d.streamInterest ? 'selected' : ''} disabled>-- Select your interest --</option>
        ${opts.map(o => `<option value="${o}" ${d.streamInterest===o?'selected':''}>${o}</option>`).join('')}
      </select>
    </div>`;
}

// Renders the conditional "what next" question shown right under the
// Education Level dropdown in Step 1 (before any career-goal question).
function renderEduPathBlock(level) {
  if (!level) return '';
  const opts = EDU_PATH_OPTIONS[level.group];
  if (!opts) return '';
  const chosen = State.evalData.eduPath;
  return `
    <div class="form-group mb-2">
      <label class="form-label">${opts.question}</label>
      <div class="flex gap-2" style="flex-wrap:wrap">
        ${opts.options.map(o => `
        <label style="display:inline-flex;align-items:center;gap:6px;background:${chosen===o ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.05)'};border:1px solid ${chosen===o ? 'var(--accent)' : 'var(--border)'};border-radius:20px;padding:8px 16px;cursor:pointer;font-size:13px">
          <input type="radio" name="ev-edupath" value="${o}" ${chosen===o?'checked':''} onchange="onEduPathChange('${o}')" style="accent-color:var(--accent)">
          ${o}
        </label>`).join('')}
      </div>
    </div>`;
}

function onEduLevelChange() {
  State.evalData.eduLevel = $('ev-edulevel').value;
  State.evalData.eduPath = null;
  const level = EDUCATION_LEVELS.find(l => l.key === State.evalData.eduLevel);
  $('edu-path-wrap').innerHTML = renderEduPathBlock(level);
}

function onEduPathChange(opt) {
  State.evalData.eduPath = opt;
}

function onGovtInterestChange() {
  $('ev-govtcat-wrap')?.classList.toggle('hidden', $('ev-govtInterest').value !== 'Yes');
}

function evalNext(step) {
  if (step === 0) { State.evalStep = Math.max(1, State.evalStep - 1); renderEvalStep(State.evalStep); return; }
  const d = State.evalData;
  if (step === 1) {
    const level = $('ev-edulevel')?.value;
    if (!level) return showToast('Please select your current education level.', 'warning');
    const group = EDUCATION_LEVELS.find(l => l.key === level)?.group;
    if (EDU_PATH_OPTIONS[group] && !d.eduPath) return showToast('Please choose an option for what\'s next.', 'warning');
    d.eduLevel = level;
    State.evalStep = 2;
  } else if (step === 2) {
    const group = EDUCATION_LEVELS.find(l => l.key === d.eduLevel)?.group;
    if (group === 'school') {
      const interest = $('ev-streaminterest')?.value;
      if (!interest) return showToast('Please select the stream/branch you\'re interested in.', 'warning');
      const m10 = parseFloat($('ev-marks10')?.value);
      if (!m10 || m10 < 0 || m10 > 100) return showToast('Enter a valid Class 10 percentage (0-100).', 'warning');
      d.streamInterest = interest;
      d.stream = interest;
      d.marks10 = m10;
      d.marks12 = m10; // used internally for scoring until they reach the next level
    } else {
      const m12 = parseFloat($('ev-marks12')?.value);
      if (!m12 || m12 < 0 || m12 > 100) return showToast('Enter a valid percentage/CGPA (0-100).', 'warning');
      d.stream = $('ev-stream')?.value.trim() || '';
      d.marks12 = m12;
      d.marks10 = parseFloat($('ev-marks10')?.value) || m12;
    }
    State.evalStep = 3;
  } else if (step === 3) {
    d.familyIncome = parseFloat($('ev-income')?.value) || 0;
    d.gender = $('ev-gender')?.value || 'Other';
    if (State.user && State.user.gender !== d.gender) { State.user.gender = d.gender; syncUserProfile({ gender: d.gender }); }
    State.evalStep = 4;
  } else if (step === 4) {
    d.skills = Array.from(document.querySelectorAll('.ev-skill-cb:checked')).map(cb => cb.value);
    if (!d.skills.length) return showToast('Please select at least one skill.', 'warning');
    State.evalStep = 5;
  } else if (step === 5) {
    const r = document.querySelector('input[name="ev-research"]:checked');
    d.researchInterest = r ? parseInt(r.value) : 3;
    State.evalStep = 6;
  } else if (step === 6) {
    const careerId = parseInt($('ev-careerId')?.value);
    if (!careerId) return showToast('Please choose a preferred career.', 'warning');
    d.careerId = careerId;
    d.govtInterest = $('ev-govtInterest')?.value || 'No';
    d.govtCategory = $('ev-govtCategory')?.value || '';
    d.higherEdInterest = $('ev-higherEdInterest')?.value || 'No';
    computeAssessment();
    return;
  }
  renderEvalStep(State.evalStep);
}

// Converts the multi-select skills + other evaluator answers into the
// numeric-ish profile shape AIEngine's scoring functions expect.
function buildDerivedProfile(d) {
  const skills = d.skills || [];
  const has = s => skills.includes(s);
  return {
    eduLevel: d.eduLevel, eduPath: d.eduPath, stream: d.stream,
    marks12: d.marks12, marks10: d.marks10,
    familyIncome: d.familyIncome || 0,
    gender: d.gender || 'Other', state: d.state || '',
    careerId: d.careerId,
    researchInterest: d.researchInterest || 3,
    mathScore: has('Mathematics') ? Math.min(100, d.marks12 + 8) : d.marks12,
    scienceScore: has('Analytical Skills') ? Math.min(100, d.marks12 + 5) : d.marks12,
    biologyScore: d.marks12,
    englishScore: (has('Communication') || has('Public Speaking')) ? Math.min(100, d.marks12 + 8) : d.marks12,
    techSkills: (has('Coding') || has('Technical Skills')) ? 5 : (has('Problem Solving') ? 3 : 2),
    communication: (has('Communication') || has('Public Speaking')) ? 5 : 2,
    leadership: has('Leadership') ? 5 : 2,
    skills,
    govtInterest: d.govtInterest === 'Yes',
    govtCategory: d.govtCategory || '',
    higherEdInterest: d.higherEdInterest === 'Yes'
  };
}

// Submits the profile to the backend, which runs it through the trained
// scikit-learn model (see backend/ml_engine.py) for the genuine ML pieces
// (career-fit suitability %, readiness score, skill gaps). The roadmap,
// college list, scholarship matches and government-job suggestions stay
// client-side via AIEngine.generateRecommendation since they're static
// reference-data lookups, not a classification problem.
async function computeAssessment() {
  const d = State.evalData;
  const profile = buildDerivedProfile(d);
  const rec = AIEngine.generateRecommendation(profile);

  const submitBtn = document.querySelector('#eval-step-content .btn-success');
  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '🤖 Running ML model...'; }

  try {
    const assessment = await api.createAssessment({ ...d, ...profile });
    State.assessment = { ...assessment, recommendation: rec, skills: profile.skills };

    if (State.user) {
      State.user.readinessScore = assessment.readinessScore;
      State.user.careerChoice = rec.preferred.slug;
      State.user.educationLevel = d.eduLevel;
      syncUserProfile({ readinessScore: assessment.readinessScore, careerChoice: rec.preferred.slug, educationLevel: d.eduLevel });
    }

    State.evalStep = 7;
    updateSidebarUser();
    renderEvaluatorResults();
    showToast('Assessment complete! 🎉', 'success');
  } catch (err) {
    showToast(err.message || 'Could not generate assessment. Please try again.', 'danger');
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '🚀 Generate Assessment'; }
  }
}

function renderEvaluatorResults() {
  const a = State.assessment;
  const rec = a.recommendation;
  const career = rec.preferred;
  const isPilot = career.slug === 'pilot';

  const otherPrediction = a.predictedCareerId && a.predictedCareerId !== a.careerId
    ? DB.careers.find(c => c.id === a.predictedCareerId) : null;

  $('view-evaluator').innerHTML = `
  <div class="section-header">
    <div class="section-title">🎯 Your Assessment Results</div>
    <div class="section-sub">ML-powered career suitability & readiness (model: ${a.modelVersion || 'rf-v1'}), plus a complete roadmap.</div>
  </div>
  ${otherPrediction ? `
  <div class="alert alert-warning mb-4">
    <span class="alert-icon">🤖</span>
    Based on your full profile, our trained model actually rates <b>${otherPrediction.icon} ${otherPrediction.title}</b>
    as your statistically strongest fit (${a.predictedConfidence}% confidence), ahead of your selected path.
    Worth exploring!
  </div>` : ''}
  <div class="grid grid-2 mb-6">
    <div class="card">
      <div class="card-body" style="text-align:center">
        <div class="text-muted text-sm mb-3">Career Readiness Score</div>
        ${renderCircularProgress(a.readinessScore, 150, '#6366f1', 'Overall')}
        <div class="mt-4 font-display font-bold" style="font-size:20px">${career.icon} ${career.title}</div>
        <div class="mt-2">${getReadinessLabel(a.readinessScore)}</div>
        <div class="text-xs text-muted mt-3">Est. Salary Range: <strong>${fmtShort(rec.salaryRange.min)} – ${fmtShort(rec.salaryRange.max)}</strong> per year</div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-4" style="font-size:16px">Your Skills & Suitability</div>
        <div class="flex gap-2 mb-4" style="flex-wrap:wrap">
          ${(a.skills||[]).map(sk=>`<span class="tag tag-accent">${sk}</span>`).join('')}
        </div>
        <div class="skill-bars">
          ${skillBar('Academic Strength', a.marks12, '#6366f1')}
          ${skillBar('Career Suitability', a.suitabilityScore, '#10b981')}
          ${skillBar('Research Interest', (a.researchInterest/5)*100, '#f59e0b')}
        </div>
      </div>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="font-display font-bold mb-3" style="font-size:16px">🏆 Top Career Matches For You</div>
      <div class="grid grid-3">
        ${rec.ranked.slice(0,3).map(r => `
        <div class="career-card ${r.career.id===career.id?'selected':''}">
          <div class="career-card-banner" style="background:${r.career.gradient}">${r.career.icon}</div>
          <div class="career-card-body">
            <div class="career-card-title" style="font-size:13px">${r.career.title}</div>
            <div class="career-card-tags"><span class="tag tag-green" style="font-size:10px">${r.score}% match</span></div>
          </div>
        </div>`).join('')}
      </div>
    </div>
  </div>

  <div class="grid grid-2 mb-4">
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-3" style="font-size:15px">📖 Suitable Courses / Roles</div>
        ${rec.suitableCourses.map(c=>`<div class="text-sm text-muted mb-1">• ${c}</div>`).join('')}
        <div class="divider"></div>
        <div class="font-display font-bold mb-3" style="font-size:15px">🧩 Required Skills</div>
        ${rec.requiredSkills.map(s=>`<span class="tag tag-blue" style="margin:0 6px 6px 0">${s}</span>`).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-3" style="font-size:15px">📝 Entrance Exams</div>
        ${rec.exams.length ? rec.exams.map(e=>`<div class="text-sm mb-1">• <strong>${e.name}</strong> <span class="text-muted">— ${e.conductingBody}</span></div>`).join('') : `<div class="text-sm text-muted">No dedicated entrance exam — check the roadmap →</div>`}
      </div>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <div class="font-display font-bold mb-3" style="font-size:16px">${isPilot ? '✈️ ' + PILOT_ROADMAP.title : '🗺️ Career Roadmap'}</div>
      ${isPilot ? `<div class="text-sm text-muted mb-3">${PILOT_ROADMAP.note}</div>` : ''}
      <div class="timeline">
        ${rec.roadmap.map(step => `
        <div class="timeline-item">
          <div class="timeline-dot"></div>
          <div class="timeline-card timeline-body text-sm">${step}</div>
        </div>`).join('')}
      </div>
    </div>
  </div>

  <div class="grid grid-2 mb-4">
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-3" style="font-size:15px">🏫 Top Colleges</div>
        ${rec.topColleges.length ? rec.topColleges.map(c=>`<div class="text-sm mb-1">• ${c.name} <span class="text-muted">— ${c.location}</span></div>`).join('') : `<div class="text-sm text-muted">No colleges listed for this career yet.</div>`}
        ${rec.localColleges.length ? `<div class="divider"></div><div class="font-bold text-sm mb-2">📍 Local Colleges (Warangal / Telangana)</div>${rec.localColleges.map(c=>`<div class="text-sm mb-1">• ${c.name}</div>`).join('')}` : ''}
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-display font-bold mb-3" style="font-size:15px">🎓 Matched Scholarships</div>
        ${rec.scholarships.length ? rec.scholarships.slice(0,5).map(s=>`<div class="text-sm mb-1">• ${s.name} <span class="text-muted">— ${fmtShort(s.amountPerYear)}/yr</span></div>`).join('') : `<div class="text-sm text-muted">No scholarships matched yet — refine your profile for better matches.</div>`}
      </div>
    </div>
  </div>

  ${rec.govtOpportunities.length ? `
  <div class="card mb-4">
    <div class="card-body">
      <div class="font-display font-bold mb-3" style="font-size:16px">🏛️ Government Opportunities</div>
      <div class="grid grid-3">
        ${rec.govtOpportunities.map(g => `
        <div style="background:rgba(99,102,241,0.06);border:1px solid var(--border);border-radius:10px;padding:14px">
          <div class="font-bold text-sm mb-1">${g.icon} ${g.name}</div>
          <div class="text-xs text-muted">${g.desc}</div>
        </div>`).join('')}
      </div>
    </div>
  </div>` : ''}

  ${a.skillGaps.length > 0 ? `
  <div class="card mb-4">
    <div class="card-body">
      <div class="font-display font-bold mb-4" style="font-size:16px">⚡ Skill Gap Analysis</div>
      <div class="grid grid-2">
        ${a.skillGaps.map(g => `
        <div style="background:rgba(239,68,68,0.07);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:16px">
          <div class="flex items-center justify-between mb-2">
            <div class="font-bold text-sm">${g.skill}</div>
            <span class="tag" style="background:rgba(239,68,68,0.12);color:#ef4444;border:1px solid rgba(239,68,68,0.25)">${g.gap}pt gap</span>
          </div>
          <div class="text-sm text-muted">💡 ${g.action}</div>
        </div>`).join('')}
      </div>
    </div>
  </div>` : `<div class="alert alert-success"><span class="alert-icon">🌟</span> Excellent! No critical skill gaps detected for your chosen career path.</div>`}
  <div class="flex gap-3">
    <button class="btn btn-secondary" onclick="State.evalStep=1;renderEvaluator()">🔄 Retake Assessment</button>
    <button class="btn btn-primary" onclick="navigateTo('financial')">💰 Plan Finances →</button>
  </div>`;
}

function renderAssessmentResults() {
  const el = $('eval-results');
  if (!el || !State.assessment) return;
  const a = State.assessment;
  el.innerHTML = `
    <div class="flex items-center justify-between">
      <div class="font-display font-bold" style="font-size:16px">Previous Assessment — ${a.careerTitle}</div>
      <span class="tag tag-green">Score: ${a.readinessScore}%</span>
    </div>
    <div class="text-sm text-muted mt-2">Completed: ${new Date(a.timestamp).toLocaleDateString('en-IN', {dateStyle:'long'})}</div>`;
}

function getReadinessLabel(score) {
  if (score >= 85) return `<span class="tag tag-green">🌟 Excellent — Top Candidate</span>`;
  if (score >= 70) return `<span class="tag tag-accent">✅ Good — On Track</span>`;
  if (score >= 55) return `<span class="tag tag-amber">⚡ Average — Needs Work</span>`;
  return `<span class="tag tag-pink">⚠️ Needs Improvement</span>`;
}

// ============================================================
// VIEW: EXAMS
// ============================================================
function renderExams() {
  // 10th-class students haven't reached entrance-exam territory yet — show
  // them Intermediate vs Polytechnic guidance instead of JEE/NEET/EAMCET etc.
  if (currentEduGroup() === 'school') {
    $('view-exams').innerHTML = `
    <div class="section-header">
      <div class="section-title">📚 Exam Guidance</div>
      <div class="section-sub">Competitive entrance exams (JEE, NEET, EAMCET etc.) apply after Intermediate/Polytechnic — here's what to plan for right after 10th.</div>
    </div>
    <div class="grid grid-2">
      <div class="card">
        <div class="card-body">
          <div class="font-display font-bold mb-2" style="font-size:16px">📘 Intermediate (11th & 12th)</div>
          <div class="text-sm text-muted mb-3">Choose a stream based on your interest — this determines which competitive exams you'll prepare for later.</div>
          <div class="text-sm mb-1">• <strong>MPC</strong> (Maths, Physics, Chemistry) → JEE Main/Advanced, EAMCET, BITSAT for Engineering</div>
          <div class="text-sm mb-1">• <strong>BiPC</strong> (Biology, Physics, Chemistry) → NEET for Medical (MBBS/BDS)</div>
          <div class="text-sm mb-1">• <strong>MEC / CEC</strong> (Commerce/Civics + Economics) → CA/CS foundation, CLAT, CUET for Degree/Law/Management</div>
          <div class="text-sm mb-1">• <strong>HEC</strong> (Humanities) → CUET, UPSC foundation, Degree courses</div>
        </div>
      </div>
      <div class="card">
        <div class="card-body">
          <div class="font-display font-bold mb-2" style="font-size:16px">⚙️ Polytechnic (Diploma)</div>
          <div class="text-sm text-muted mb-3">A 3-year diploma straight after 10th, with direct entry into 2nd-year B.Tech (Lateral Entry) later.</div>
          <div class="text-sm mb-1">• Entry via <strong>POLYCET</strong> (state polytechnic common entrance test)</div>
          <div class="text-sm mb-1">• Branches: Mechanical, Civil, EEE, ECE, CSE and more</div>
          <div class="text-sm mb-1">• After diploma: Lateral Entry B.Tech, Government/PSU technical jobs, or direct employment</div>
        </div>
      </div>
    </div>
    <div class="alert alert-info mt-4"><span class="alert-icon">💡</span> Once you complete the Career Evaluator and update your education level to Intermediate or Polytechnic, this page will automatically show the relevant competitive entrance exams for your stream.</div>`;
    return;
  }

  const careerFilter = State.user?.careerChoice;
  const career = DB.careers.find(c => c.slug === careerFilter);
  const allExams = careerFilter ? DB.exams.filter(e => e.careerId === career?.id) : DB.exams;

  // Intermediate students get a stream-based nudge toward the competitive
  // exams that matter most for them (e.g. MPC → JEE/EAMCET, BiPC → NEET),
  // shown as a suggestion banner without forcing the career filter.
  const eduLevel = State.user?.educationLevel || State.evalData.eduLevel;
  const STREAM_EXAM_SUGGESTIONS = {
    inter_mpc:  { slug:'engineering', label:'MPC', note:'JEE Main/Advanced, EAMCET and BITSAT are the key competitive exams for Engineering admissions.' },
    inter_bipc: { slug:'mbbs',        label:'BiPC', note:'NEET is the sole gateway to MBBS/BDS admissions in India.' },
    inter_mec:  { slug:'management',  label:'MEC', note:'Consider CA/CS Foundation, CUET and management entrance exams for Commerce-based careers.' },
    inter_cec:  { slug:'law',         label:'CEC', note:'CLAT and CUET open doors to Law and Commerce degree programs.' },
    inter_hec:  { slug:'civil-services', label:'HEC', note:'CUET for degree admissions, with UPSC Civil Services as a strong long-term path.' }
  };
  const suggestion = STREAM_EXAM_SUGGESTIONS[eduLevel];

  const suggestionBanner = (!careerFilter && suggestion) ? `
  <div class="alert alert-info mb-6">
    <span class="alert-icon">🎯</span> Since you're in Intermediate (${suggestion.label}), here are your key competitive exams below. Want to see them specifically? <a href="#" onclick="filterExamsByCareer('${suggestion.slug}');return false;" style="color:var(--accent);text-decoration:underline">Filter by ${DB.careers.find(c=>c.slug===suggestion.slug)?.title}</a>. ${suggestion.note}
  </div>` : '';

  // Which exams (within the current career filter) has the student chosen to prepare for?
  // Default: if the student hasn't picked any yet for these exams, show all of them.
  const prepKey = careerFilter || 'all';
  const chosen = State.examPrep[prepKey];
  const hasChosenAny = Array.isArray(chosen) && chosen.length > 0;
  const exams = hasChosenAny ? allExams.filter(e => chosen.includes(e.id)) : allExams;

  $('view-exams').innerHTML = `
  <div class="section-header flex items-center justify-between">
    <div><div class="section-title">📚 Exam Guidance</div><div class="section-sub">Roadmaps, syllabus & preparation tips for all major entrance exams.</div></div>
    <select class="form-input" style="width:220px" onchange="filterExamsByCareer(this.value)">
      <option value="">All Careers</option>
      ${DB.careers.map(c=>`<option value="${c.slug}" ${careerFilter===c.slug?'selected':''}>${c.icon} ${c.title}</option>`).join('')}
    </select>
  </div>

  ${suggestionBanner}

  ${careerFilter === 'pilot' ? `
  <div class="card mb-6">
    <div class="card-body">
      <div class="font-display font-bold mb-2" style="font-size:16px">✈️ ${PILOT_ROADMAP.title}</div>
      <div class="text-sm text-muted mb-4">${PILOT_ROADMAP.note}</div>
      <div class="timeline">
        ${PILOT_ROADMAP.steps.map(s => `
        <div class="timeline-item">
          <div class="timeline-dot"></div>
          <div class="timeline-card timeline-body">
            <div class="font-bold text-sm mb-1">${s.stage}</div>
            <div class="text-sm text-muted">${s.detail}</div>
          </div>
        </div>`).join('')}
      </div>
    </div>
  </div>` : ''}

  ${allExams.length > 1 ? `
  <div class="card mb-6">
    <div class="card-body">
      <div class="font-bold text-sm mb-1">🎯 Which exam(s) are you preparing for?</div>
      <div class="text-sm text-muted mb-3">Select one or more — the roadmap below will focus on just those. Leave none selected to see all exams${career ? ` for ${career.title}` : ''}.</div>
      <div class="flex gap-2" style="flex-wrap:wrap">
        ${allExams.map(e => `
        <label style="display:inline-flex;align-items:center;gap:6px;background:${(chosen||[]).includes(e.id) ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.05)'};border:1px solid ${(chosen||[]).includes(e.id) ? 'var(--accent)' : 'var(--border)'};border-radius:20px;padding:6px 14px;cursor:pointer;font-size:13px">
          <input type="checkbox" ${(chosen||[]).includes(e.id) ? 'checked' : ''} onchange="toggleExamPrep('${prepKey}', ${e.id})" style="accent-color:var(--accent)">
          ${e.name}
        </label>`).join('')}
      </div>
    </div>
  </div>` : ''}

  <div class="timeline" id="exam-timeline">
    ${exams.map(exam => renderExamCard(exam)).join('')}
  </div>`;
}

function toggleExamPrep(prepKey, examId) {
  const current = Array.isArray(State.examPrep[prepKey]) ? [...State.examPrep[prepKey]] : [];
  const idx = current.indexOf(examId);
  if (idx >= 0) current.splice(idx, 1);
  else current.push(examId);
  State.examPrep[prepKey] = current;
  renderExams();
}

function filterExamsByCareer(slug) {
  if (slug && State.user) { State.user.careerChoice = slug; updateSidebarUser(); }
  renderExams();
}

function renderExamCard(exam) {
  const career = DB.careers.find(c => c.id === exam.careerId);
  const feeHtml = (exam.fee === null || exam.fee === undefined || exam.fee === 0)
    ? `<span class="tag" style="background:rgba(16,185,129,0.12);color:#10b981;border:1px solid rgba(16,185,129,0.3)">Free — No Registration Fee</span>`
    : `💳 Registration Fee: <strong>${fmt(exam.fee)}</strong> (General category)`;
  return `
  <div class="timeline-item">
    <div class="timeline-dot"></div>
    <div class="timeline-card timeline-body">
      <div class="flex items-center justify-between mb-2">
        <div class="timeline-exam">${exam.name}</div>
        <span class="tag tag-accent">${exam.mode}</span>
      </div>
      <div class="timeline-date">📅 ${exam.examDate} · 📝 Registration: ${exam.regDate} · ${exam.frequency}</div>
      <div class="text-sm text-muted mb-2">By ${exam.conductingBody} ${career ? `· <span class="text-accent">${career.title}</span>` : ''}</div>
      <div class="text-sm mb-3">${feeHtml}${exam.feeWaiver ? `<div class="text-xs text-muted mt-1">🎗️ ${exam.feeWaiver}</div>` : ''}</div>
      <div class="grid grid-2 gap-3">
        <div>
          <div class="font-bold text-sm mb-2">📖 Syllabus Highlights</div>
          ${exam.syllabus.map(s=>`<div class="text-sm text-muted mb-1">• ${s}</div>`).join('')}
        </div>
        <div>
          <div class="font-bold text-sm mb-2">💡 Preparation Tips</div>
          ${exam.prepTips.map(t=>`<div class="text-sm text-muted mb-1">✓ ${t}</div>`).join('')}
        </div>
      </div>
      <div class="mt-3"><a href="${exam.url}" target="_blank" class="btn btn-secondary btn-sm">🌐 Official Website</a></div>
    </div>
  </div>`;
}

// ============================================================
// VIEW: COLLEGES
// ============================================================
function renderColleges() {
  // 10th-class students haven't reached B.Tech/MBBS/etc. colleges yet — show
  // them Intermediate/Polytechnic Junior Colleges instead, still searchable.
  if (currentEduGroup() === 'school') {
    const searchTerm = (State.collegeSearch || '').trim().toLowerCase();
    const stateFilter = State.collegeStateFilter || '';
    const allStates = [...new Set(JUNIOR_COLLEGES.map(c => c.location.split(', ').pop()))].sort();
    let juniorColleges = JUNIOR_COLLEGES.filter(c => isCollegeVisibleForGender(c, State.user?.gender));
    if (stateFilter) juniorColleges = juniorColleges.filter(c => c.location.endsWith(stateFilter));
    if (searchTerm) juniorColleges = juniorColleges.filter(c => c.name.toLowerCase().includes(searchTerm) || c.location.toLowerCase().includes(searchTerm));

    $('view-colleges').innerHTML = `
    <div class="section-header flex items-center justify-between">
      <div><div class="section-title">🏫 Intermediate & Polytechnic College Finder</div>
      <div class="section-sub">Junior colleges and polytechnics across India — fees, streams offered and location. Competitive-exam colleges (B.Tech/MBBS/etc.) unlock once you move past 10th.</div></div>
      <select class="form-input" style="width:220px" onchange="filterCollegesByState(this.value)">
        <option value="">All States</option>
        ${allStates.map(s=>`<option value="${s}" ${stateFilter===s?'selected':''}>${s}</option>`).join('')}
      </select>
    </div>
    <div class="form-group mb-4">
      <input type="text" class="form-input" id="college-search-input" placeholder="🔎 Search by college name or location..." value="${searchTerm ? State.collegeSearch : ''}" oninput="searchColleges(this.value)">
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th>#</th><th>College</th><th>Location</th><th>Type</th><th>Streams Offered</th>
          <th>Annual Fee</th><th>Total (2yr)</th><th>Seats</th>
        </tr></thead>
        <tbody>
          ${juniorColleges.length ? juniorColleges.map((col, i) => `<tr>
            <td>${i+1}</td>
            <td><div class="font-bold" style="font-size:14px">${col.name}</div></td>
            <td><span class="text-muted text-sm">📍 ${col.location}</span></td>
            <td><span class="tag ${col.type.startsWith('Government')?'tag-green':'tag-accent'}">${col.type}</span></td>
            <td class="text-sm">${col.streams.join(', ')}</td>
            <td class="amount">${col.annualFee ? fmtShort(col.annualFee) : 'Free'}</td>
            <td class="amount" style="color:#10b981">${col.total2yr ? fmtShort(col.total2yr) : 'Free'}</td>
            <td>${col.seats}</td>
          </tr>`).join('') : `<tr><td colspan="8" class="text-muted" style="padding:24px;text-align:center">No colleges found matching your search.</td></tr>`}
        </tbody>
      </table>
    </div>`;

    const input = $('college-search-input');
    if (input && document.activeElement !== input && searchTerm) input.value = searchTerm;
    return;
  }

  const careerFilter = State.user?.careerChoice;
  const career = DB.careers.find(c => c.slug === careerFilter);
  let colleges = careerFilter ? DB.colleges.filter(c => c.careerId === career?.id) : DB.colleges;
  colleges = colleges.filter(c => isCollegeVisibleForGender(c, State.user?.gender));

  const searchTerm = (State.collegeSearch || '').trim().toLowerCase();
  if (searchTerm) {
    colleges = colleges.filter(c =>
      c.name.toLowerCase().includes(searchTerm) || c.location.toLowerCase().includes(searchTerm)
    );
  }

  $('view-colleges').innerHTML = `
  <div class="section-header flex items-center justify-between">
    <div><div class="section-title">🏫 College & Fee Finder</div><div class="section-sub">Detailed fee breakdowns and admission stats for top institutions.</div></div>
    <select class="form-input" style="width:220px" onchange="filterCollegesByCareer(this.value)">
      <option value="">All Careers</option>
      ${DB.careers.map(c=>`<option value="${c.slug}" ${careerFilter===c.slug?'selected':''}>${c.icon} ${c.title}</option>`).join('')}
    </select>
  </div>

  <!-- College Predictor — only relevant once a student has reached Intermediate/12th or beyond -->
  ${currentEduGroup() !== 'school' ? `
  <div class="card mb-6">
    <div class="card-body">
      <div class="font-display font-bold mb-1" style="font-size:16px">🎯 Predict My College</div>
      <div class="text-sm text-muted mb-4">Enter your exam and rank/score to see which colleges you're likely to get into.</div>
      <div class="grid grid-2 gap-4">
        <div class="form-group">
          <label class="form-label">Exam</label>
          <select class="form-input" id="predict-exam" onchange="onPredictExamChange()">
            <option value="">Select an exam</option>
            ${DB.exams.filter(e => DB.colleges.some(c => (c.cutoffs||[]).some(cf=>cf.examId===e.id))).map(e=>`<option value="${e.id}">${e.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" id="predict-score-label">Your Rank / Score</label>
          <input type="number" step="any" class="form-input" id="predict-score" placeholder="e.g. 5000">
        </div>
      </div>
      <div class="form-group hidden" id="predict-branch-wrap">
        <label class="form-label" id="predict-branch-label">Preferred Branch</label>
        <select class="form-input" id="predict-branch">
          <option value="">Any / General cutoff</option>
        </select>
      </div>
      <div class="form-group hidden" id="predict-year-wrap">
        <label class="form-label">Cutoff Year</label>
        <select class="form-input" id="predict-year">
          ${EAMCET_YEARS.map((y,i)=>`<option value="${y}" ${i===0?'selected':''}>${y}${i===0?' (latest)':''}</option>`).join('')}
        </select>
        <div class="text-xs text-muted mt-1">EAMCET cutoff ranks shift year to year — pick the year you want the prediction based on.</div>
      </div>
      <button class="btn btn-primary" onclick="runCollegePredictor()">🔍 Predict Colleges (AI)</button>
      <div id="predict-results" class="mt-4"></div>
      <div class="text-xs text-muted mt-3">🤖 Safe/Moderate/Dream chances are predicted by a trained ML classifier (RandomForest) based on how your rank/score compares to each college's cutoff — not a fixed rule. ⚠️ Cutoffs shown are illustrative, approximate General-category figures for demo purposes — actual cutoffs vary every year and by category (OBC/SC/ST/EWS), and branch-wise cutoffs vary by college. Always confirm with the official counselling authority (JoSAA, MCC, CLAT Consortium, IIM CAP, UPSC, etc.) before making admission decisions. Women-only institutions are automatically excluded/included based on your registered gender.</div>
    </div>
  </div>` : `
  <div class="alert alert-info mb-6"><span class="alert-icon">💡</span> The College Predictor unlocks once you're in Intermediate/12th or beyond — it works off your entrance exam rank/score, which only applies after 10th.</div>`}

  <div class="form-group mb-4">
    <input type="text" class="form-input" id="college-search-input" placeholder="🔎 Search college by name or location..." value="${searchTerm ? State.collegeSearch : ''}" oninput="searchColleges(this.value)">
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr>
        <th>#</th><th>College</th><th>Location</th><th>NIRF Rank</th>
        <th>Annual Fee</th><th>Hostel</th><th>Total (4yr)</th><th>Seats</th><th>Acceptance</th>
      </tr></thead>
      <tbody>
        ${colleges.length ? colleges.map((col, i) => `<tr>
          <td>${i+1}</td>
          <td><div class="font-bold" style="font-size:14px">${col.name}</div></td>
          <td><span class="text-muted text-sm">📍 ${col.location}</span></td>
          <td>${col.rank ? `<span class="tag tag-accent">#${col.rank}</span>` : '<span class="text-muted">—</span>'}</td>
          <td class="amount">${fmtShort(col.tuition)}</td>
          <td class="amount">${col.hostel ? fmtShort(col.hostel) : '—'}</td>
          <td class="amount" style="color:#10b981">${fmtShort(col.total4yr)}</td>
          <td>${col.seats}</td>
          <td><span class="tag ${col.acceptance < 1 ? 'tag-pink' : col.acceptance < 5 ? 'tag-amber' : 'tag-green'}">${col.acceptance}%</span></td>
        </tr>`).join('') : `<tr><td colspan="9" class="text-muted" style="padding:24px;text-align:center">No colleges found matching your search.</td></tr>`}
      </tbody>
    </table>
  </div>
  ${!careerFilter ? `
  <div class="grid grid-3 mt-6">
    ${DB.careers.map(c => {
      const cols = DB.colleges.filter(col => col.careerId === c.id);
      const minFee = Math.min(...cols.map(col => col.total4yr).filter(Boolean));
      const maxFee = Math.max(...cols.map(col => col.total4yr).filter(Boolean));
      return `<div class="card">
        <div class="card-body">
          <div class="flex items-center gap-3 mb-3">
            <div style="font-size:28px">${c.icon}</div>
            <div><div class="font-display font-bold" style="font-size:14px">${c.title}</div>
            <div class="text-xs text-muted">${cols.length} colleges</div></div>
          </div>
          <div class="flex justify-between text-sm mt-2">
            <div><div class="text-muted">Min Cost</div><div class="font-bold" style="color:#10b981">${minFee ? fmtShort(minFee) : 'Free'}</div></div>
            <div style="text-align:right"><div class="text-muted">Max Cost</div><div class="font-bold" style="color:#ec4899">${isFinite(maxFee) ? fmtShort(maxFee) : 'N/A'}</div></div>
          </div>
        </div>
      </div>`;
    }).join('')}
  </div>` : ''}`;

  // Restore focus to search input after re-render if user was typing
  const input = $('college-search-input');
  if (input && document.activeElement !== input && searchTerm) {
    input.value = searchTerm;
  }
}

function filterCollegesByCareer(slug) {
  if (State.user) State.user.careerChoice = slug || null;
  renderColleges();
}

function filterCollegesByState(state) {
  State.collegeStateFilter = state || '';
  renderColleges();
}

function searchColleges(value) {
  State.collegeSearch = value;
  renderColleges();
  const input = $('college-search-input');
  if (input) {
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }
}

function onPredictExamChange() {
  const examId = parseInt($('predict-exam')?.value);
  const exam = DB.exams.find(e => e.id === examId);
  const label = $('predict-score-label');
  const branchWrap = $('predict-branch-wrap');
  const branchLabel = $('predict-branch-label');
  const branchSelect = $('predict-branch');
  const yearWrap = $('predict-year-wrap');
  if (!label) return;
  if (!exam) { label.textContent = 'Your Rank / Score'; branchWrap?.classList.add('hidden'); yearWrap?.classList.add('hidden'); return; }
  label.textContent = exam.scoreLabel || (exam.examType === 'rank' ? 'Your Rank' : 'Your Score');
  yearWrap?.classList.toggle('hidden', !EAMCET_YEAR_TRENDS[examId]);

  // Branch/specialization selection applies to Engineering (JEE/EAMCET etc.)
  // and Management (CAT/XAT) exams — each with its own option list.
  const isEngineering = exam.careerId === 1;
  const isManagement = exam.careerId === 7;
  if (branchWrap) branchWrap.classList.toggle('hidden', !isEngineering && !isManagement);
  if (isEngineering) {
    branchLabel.textContent = 'Preferred Branch';
    branchSelect.innerHTML = `<option value="">Any / General (CSE-level cutoff)</option>` + ENGINEERING_BRANCHES.map(b=>`<option value="${b.key}">${b.label}</option>`).join('');
  } else if (isManagement) {
    branchLabel.textContent = 'Preferred Specialization';
    branchSelect.innerHTML = `<option value="">Any / General Management cutoff</option>` + MANAGEMENT_SPECIALIZATIONS.map(b=>`<option value="${b.key}">${b.label}</option>`).join('');
  }
}

async function runCollegePredictor() {
  const examId = parseInt($('predict-exam')?.value);
  const value = parseFloat($('predict-score')?.value);
  const branchKey = $('predict-branch')?.value || null;
  const year = EAMCET_YEAR_TRENDS[examId] ? parseInt($('predict-year')?.value) : null;
  const resultsEl = $('predict-results');
  if (!resultsEl) return;

  if (!examId) return showToast('Please select an exam.', 'warning');
  if (!value || value <= 0) return showToast('Please enter your rank/score.', 'warning');

  const { exam, candidates } = AIEngine.buildCollegeCandidates(examId, value, branchKey, year, State.user?.gender);
  const branchList = exam?.careerId === 7 ? MANAGEMENT_SPECIALIZATIONS : ENGINEERING_BRANCHES;

  if (!candidates.length) {
    resultsEl.innerHTML = `<div class="alert alert-warning mt-2"><span class="alert-icon">⚠️</span> No matching colleges found for this rank/score in our current database. Try a different exam or double-check the value entered.</div>`;
    return;
  }

  resultsEl.innerHTML = `<div class="flex items-center gap-2 mt-3 text-sm text-muted"><span class="spinner" style="width:16px;height:16px"></span> Running the ML admission-chance model on ${candidates.length} colleges...</div>`;

  let predictions;
  try {
    const res = await api.predictCollegeChances(candidates.map(c => ({ clientId: c.clientId, relativeStrength: c.relativeStrength, examType: c.examType })));
    predictions = res.predictions;
  } catch (err) {
    resultsEl.innerHTML = `<div class="alert alert-danger mt-2"><span class="alert-icon">❌</span> Couldn't reach the prediction model (${err.message || 'network error'}). Please try again.</div>`;
    return;
  }

  const chanceById = Object.fromEntries(predictions.map(p => [p.clientId, p]));
  const order = { Safe: 0, Moderate: 1, Dream: 2, Unlikely: 3 };
  const results = candidates
    .map(c => ({ ...c, prediction: chanceById[c.clientId] }))
    .filter(r => r.prediction && r.prediction.chance !== 'Unlikely')
    .sort((a, b) => order[a.prediction.chance] - order[b.prediction.chance] || (a.college.rank||99) - (b.college.rank||99));

  if (!results.length) {
    resultsEl.innerHTML = `<div class="alert alert-warning mt-2"><span class="alert-icon">⚠️</span> The model doesn't rate any college in our database as a realistic chance for this rank/score${year ? ` (${year} cutoffs)` : ''}. Try a different exam, branch or year.</div>`;
    return;
  }

  const chanceStyle = { Safe: {bg:'rgba(16,185,129,0.1)', border:'rgba(16,185,129,0.3)', color:'#10b981', icon:'✅'},
                        Moderate: {bg:'rgba(245,158,11,0.1)', border:'rgba(245,158,11,0.3)', color:'#f59e0b', icon:'⚡'},
                        Dream: {bg:'rgba(236,72,153,0.1)', border:'rgba(236,72,153,0.3)', color:'#ec4899', icon:'🌟'} };

  resultsEl.innerHTML = `
  <div class="divider"></div>
  <div class="font-bold text-sm mb-3">Results for ${exam.name}${branchKey ? ` — ${branchList.find(b=>b.key===branchKey)?.label}` : ''}${year ? ` — ${year} cutoffs` : ''} — ${results.length} college${results.length>1?'s':''} matched</div>
  <div class="grid grid-2 gap-3">
    ${results.map(r => {
      const s = chanceStyle[r.prediction.chance];
      return `<div style="background:${s.bg};border:1px solid ${s.border};border-radius:10px;padding:14px">
        <div class="flex items-center justify-between mb-1">
          <div class="font-bold text-sm">${r.college.name}</div>
          <span class="tag" style="background:${s.bg};color:${s.color};border:1px solid ${s.border}">${s.icon} ${r.prediction.chance}</span>
        </div>
        <div class="text-xs text-muted">📍 ${r.college.location} ${r.career ? `· ${r.career.icon} ${r.career.title}` : ''}</div>
        <div class="text-xs text-muted mt-1">Cutoff: ${r.cutoff.value}${exam.examType==='percentile'?'%ile':''} <span style="opacity:.8">(${r.cutoff.label}${r.branchLabel ? ` — ${r.branchLabel}` : ''})</span></div>
        <div class="text-xs text-muted mt-1">🤖 Model confidence: ${r.prediction.confidence}%</div>
      </div>`;
    }).join('')}
  </div>`;
}

// ============================================================
// VIEW: GOVERNMENT JOBS
// ============================================================
function renderGovtJobs() {
  $('view-govtjobs').innerHTML = `
  <div class="section-header">
    <div class="section-title">🏛️ Government Jobs Guidance</div>
    <div class="section-sub">All major government job categories — exams, eligibility and the path to get there.</div>
  </div>
  <div class="grid grid-2" id="govt-jobs-grid">
    ${GOVT_JOBS.map((g, i) => `
    <div class="card">
      <div class="card-body">
        <div class="flex items-center justify-between mb-2">
          <div class="font-display font-bold" style="font-size:16px">${g.icon} ${g.name}</div>
          ${g.exams.length ? `<span class="tag tag-accent">${g.exams.length} exam${g.exams.length>1?'s':''}</span>` : ''}
        </div>
        <div class="text-sm text-muted mb-3">${g.desc}</div>
        ${g.exams.length ? `<div class="flex gap-2 mb-3" style="flex-wrap:wrap">${g.exams.map(e=>`<span class="tag tag-blue">${e}</span>`).join('')}</div>` : ''}
        <button class="btn btn-secondary btn-sm" onclick="toggleGovtRoadmap(${i})">🗺️ View Roadmap</button>
        <div id="govt-roadmap-${i}" class="hidden mt-4">
          <div class="timeline">
            ${g.roadmap.map(step => `
            <div class="timeline-item">
              <div class="timeline-dot"></div>
              <div class="timeline-card timeline-body text-sm">${step}</div>
            </div>`).join('')}
          </div>
        </div>
      </div>
    </div>`).join('')}
  </div>`;
}

function toggleGovtRoadmap(i) {
  $(`govt-roadmap-${i}`)?.classList.toggle('hidden');
}

// ============================================================
// VIEW: FINANCIAL GUIDANCE HUB
// ============================================================
function renderFinancial() {
  const a = State.assessment;
  const isSchoolLevel = currentEduGroup() === 'school';
  const marksLabel = isSchoolLevel ? 'Class 10 Marks (%)' : 'Class 12 / Latest Marks (%)';
  const marksValue = a ? (isSchoolLevel ? a.marks10 : a.marks12) : '';
  const marksLocked = !!(a && marksValue);
  const incomeValue = a?.familyIncome || State.user?.familyIncome || '';
  const incomeLocked = !!(a && a.familyIncome);

  $('view-financial').innerHTML = `
  <div class="section-header">
    <div class="section-title">💰 Financial Guidance Hub</div>
    <div class="section-sub">AI-powered loan planning, scholarship matching, EMI calculator & document vault.</div>
  </div>

  <!-- AI Predictor -->
  <div class="ai-predictor mb-6" id="ai-predictor-section">
    <div class="ai-header">
      <div class="ai-icon">🤖</div>
      <div><div class="ai-title">Financial Guide</div><div class="ai-sub">Instant loan probability & scholarship eligibility predictions</div></div>
    </div>
    <div class="grid grid-2 gap-4">
      <div class="form-group">
        <label class="form-label">${marksLabel}</label>
        <input type="number" class="form-input" id="ai-marks" placeholder="e.g. 85" value="${marksValue||''}" ${marksLocked?'disabled':''}>
        ${marksLocked ? `<div class="text-xs text-muted mt-1">✅ Auto-filled from your Career Evaluator profile.</div>` : ''}
      </div>
      <div class="form-group">
        <label class="form-label">Family Annual Income (₹)</label>
        <input type="number" class="form-input" id="ai-income" placeholder="e.g. 600000" value="${incomeValue||''}" ${incomeLocked?'disabled':''}>
        ${incomeLocked ? `<div class="text-xs text-muted mt-1">✅ Auto-filled from your Career Evaluator profile.</div>` : ''}
      </div>
      <div class="form-group"><label class="form-label">Target Career</label>
        <select class="form-input" id="ai-career">
          ${DB.careers.map(c=>`<option value="${c.id}" ${State.user?.careerChoice===c.slug?'selected':''}>${c.icon} ${c.title}</option>`).join('')}
        </select></div>
      <div class="form-group">
        <label class="form-label">Loan Amount Required (₹)</label>
        ${isSchoolLevel
          ? `<input type="text" class="form-input" value="Available after 12th / Intermediate" disabled>`
          : `<input type="number" class="form-input" id="ai-loan-amt" placeholder="e.g. 1500000" value="${State.financialPlan?.loanAmount||''}">`}
      </div>
    </div>
    ${(marksLocked || incomeLocked) ? `<div class="text-xs text-muted mb-2">Want to change these? <a href="#" onclick="navigateTo('evaluator');return false;" style="color:var(--accent);text-decoration:underline">Update your Career Evaluator profile</a>.</div>` : ''}
    <div class="flex gap-3 mt-2">
      <button class="btn btn-primary" onclick="runAIPredictor()">🔍 Analyse My Profile</button>
      ${State.financialPlan ? `<button class="btn btn-secondary btn-sm" onclick="clearFinancialPlan()">🗑️ Clear Plan</button>` : ''}
    </div>
    <div id="ai-prediction-result"></div>
  </div>

  <!-- Tabs -->
  <div class="flex gap-2 mb-6" id="fin-tabs">
    ${['Scholarship Matcher','Loan Comparison','EMI Calculator','Document Vault'].map((t,i)=>`
    <button class="btn ${i===0?'btn-primary':'btn-secondary'} btn-sm" onclick="switchFinTab(${i}, this)">${t}</button>`).join('')}
  </div>

  <div id="fin-tab-content"></div>`;

  switchFinTab(0, document.querySelector('#fin-tabs button'));
  if (State.financialPlan) renderAIPrediction(State.financialPlan);
}

function switchFinTab(idx, btn) {
  document.querySelectorAll('#fin-tabs button').forEach(b => b.className = 'btn btn-secondary btn-sm');
  if (btn) btn.className = 'btn btn-primary btn-sm';
  const tabs = [renderScholarshipMatcher, renderLoanComparison, renderEMICalc, renderDocVault];
  tabs[idx]();
}

// ── AI Predictor ────────────────────────────────────────────
async function runAIPredictor() {
  const isSchoolLevel = currentEduGroup() === 'school';
  const marks12 = parseFloat($('ai-marks')?.value) || (isSchoolLevel ? State.assessment?.marks10 : State.assessment?.marks12) || 0;
  const income  = parseFloat($('ai-income')?.value) || State.assessment?.familyIncome || 0;
  const careerId= parseInt($('ai-career')?.value);
  const loanAmt = isSchoolLevel ? 0 : parseFloat($('ai-loan-amt')?.value);

  if (!marks12 || !income) return showToast('Please fill marks and income fields.', 'warning');

  try {
    const plan = await api.predictFinancial({
      marks12, familyIncome: income, careerId, loanAmount: loanAmt || 1000000,
      gender: State.assessment?.gender || 'Male', isSchoolLevel,
    });
    State.financialPlan = plan;
    renderAIPrediction(plan);
  } catch (err) {
    showToast(err.message || 'Prediction failed. Please try again.', 'danger');
  }
}

function renderAIPrediction(plan) {
  const el = $('ai-prediction-result');
  if (!el) return;
  el.innerHTML = `
  <div class="divider"></div>
  <div class="prediction-grid">
    ${plan.isSchoolLevel ? `
    <div class="prediction-item">
      <div style="font-size:14px;color:var(--text-muted);padding:8px 0">🔒 Loan planning<br>available after 12th</div>
    </div>` : `
    <div class="prediction-item">
      <div class="prediction-pct" style="color:${plan.loanProbability>=70?'#10b981':'#f59e0b'}">${plan.loanProbability}%</div>
      <div class="prediction-label">Loan Approval Probability</div>
      <div class="text-xs text-muted mt-2">${plan.loanProbability>=70?'High chance of approval':'Apply with co-applicant'}</div>
    </div>`}
    <div class="prediction-item">
      <div class="prediction-pct" style="color:${plan.scholarshipProb>=60?'#6366f1':'#f59e0b'}">${plan.scholarshipProb}%</div>
      <div class="prediction-label">Scholarship Match Score</div>
      <div class="text-xs text-muted mt-2">${plan.scholarshipProb>=60?'Strong scholarship eligibility':'Explore more schemes'}</div>
    </div>
  </div>
  <div class="mt-4">
    <div class="font-bold text-sm mb-3">🗓️ Recommended Action Plan</div>
    ${plan.actionPlan.map(a=>`
    <div class="flex gap-3 mb-3">
      <div style="width:26px;height:26px;border-radius:50%;background:rgba(99,102,241,0.2);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0">${a.step}</div>
      <div><div class="font-bold text-sm">${a.action}</div><div class="text-xs text-muted mt-1">${a.detail}</div></div>
    </div>`).join('')}
  </div>`;
}

async function clearFinancialPlan() {
  State.financialPlan = null;
  renderFinancial();
  try { await api.clearFinancialPlan(); } catch (err) { console.error('Failed to clear plan:', err); }
}

// ── Scholarship Matcher ──────────────────────────────────────
function renderScholarshipMatcher() {
  const careerId = State.financialPlan?.careerId || DB.careers.find(c=>c.slug===State.user?.careerChoice)?.id || 1;
  const marks12  = State.financialPlan?.marks12 || State.assessment?.marks12 || 75;
  const income   = State.financialPlan?.familyIncome || State.user?.familyIncome || 600000;
  const gender   = State.assessment?.gender || 'Male';
  const profile  = { careerId, marks12, familyIncome: income, gender, state: '' };
  const matched  = AIEngine.matchScholarships(profile);
  const others   = DB.scholarships.filter(s => !matched.find(m => m.id === s.id));

  $('fin-tab-content').innerHTML = `
  <div class="font-display font-bold mb-4" style="font-size:18px">🏆 Scholarship Matcher</div>
  ${matched.length > 0 ? `
  <div class="alert alert-success mb-4"><span class="alert-icon">🎉</span> You match <strong>${matched.length}</strong> scholarship(s) based on your profile!</div>
  <div class="grid grid-auto mb-6">
    ${matched.map(s => renderScholarshipCard(s, true)).join('')}
  </div>` : `<div class="alert alert-warning mb-4"><span class="alert-icon">⚠️</span> No scholarships matched your current profile. Complete the AI Predictor above to improve results.</div>`}
  ${others.length > 0 ? `
  <div class="font-display font-bold mb-3" style="font-size:15px">Other Available Scholarships</div>
  <div class="grid grid-auto">
    ${others.map(s => renderScholarshipCard(s, false)).join('')}
  </div>` : ''}`;
}

function renderScholarshipCard(s, matched) {
  return `<div class="scholarship-card" style="${matched?`border-top:3px solid ${s.color}`:''}">
    ${matched ? `<div class="scholarship-match-badge">${s.matchScore}% Match</div>` : ''}
    <div style="font-size:22px mb-2">${s.type==='Government'?'🏛️':'🏢'}</div>
    <div class="scholarship-name mt-2">${s.name}</div>
    <div class="scholarship-provider">${s.provider}</div>
    <div class="scholarship-amount" style="color:${s.color}">${fmtShort(s.amountPerYear)}<span class="text-sm font-body text-muted">/year</span></div>
    <div class="text-xs text-muted mb-3">Total: ${fmtShort(s.totalAmount)} · Apply: ${s.applicationStart}–${s.applicationEnd}</div>
    <div class="flex gap-2 flex-wrap mb-3">
      <span class="tag tag-accent" style="font-size:10px">Min Marks: ${s.eligibility.minMarks}%</span>
      ${s.eligibility.maxIncome ? `<span class="tag tag-amber" style="font-size:10px">Income ≤ ${fmtShort(s.eligibility.maxIncome)}</span>` : ''}
      ${s.eligibility.gender ? `<span class="tag tag-pink" style="font-size:10px">${s.eligibility.gender} only</span>` : ''}
    </div>
    <a href="${s.url}" target="_blank" class="btn btn-secondary btn-sm w-full">Apply Now →</a>
  </div>`;
}

// ── Loan Comparison ──────────────────────────────────────────
function renderLoanComparison() {
  if (currentEduGroup() === 'school') {
    $('fin-tab-content').innerHTML = `
    <div class="alert alert-info"><span class="alert-icon">🔒</span> Education loans become relevant once you're applying for Intermediate/Degree/Professional courses — this section unlocks after 12th.</div>`;
    return;
  }
  State.selectedLoan = State.selectedLoan || DB.loans[0];
  $('fin-tab-content').innerHTML = `
  <div class="font-display font-bold mb-4" style="font-size:18px">🏦 Loan Comparison</div>
  <div class="grid grid-3 mb-6">
    ${DB.loans.map(l => `
    <div class="loan-card ${State.selectedLoan?.id===l.id?'selected':''}" onclick="selectLoan(${l.id})">
      <div class="loan-bank">${l.bank}</div>
      <div class="loan-scheme">${l.scheme}</div>
      <div class="loan-rate">${l.rate}% <span class="text-sm text-muted" style="font-size:14px">p.a.</span></div>
      <div class="loan-meta">
        <div class="loan-meta-item"><span class="loan-meta-val">${fmtShort(l.maxAmount)}</span>Max Amount</div>
        <div class="loan-meta-item"><span class="loan-meta-val">${l.tenure} yrs</span>Max Tenure</div>
        <div class="loan-meta-item"><span class="loan-meta-val">${l.processingFee}%</span>Processing</div>
      </div>
      <div class="mt-3 text-xs" style="color:#10b981">✓ ${l.special.split(';')[0]}</div>
    </div>`).join('')}
  </div>
  ${State.selectedLoan ? renderLoanDetail(State.selectedLoan) : ''}`;
}

function selectLoan(id) {
  State.selectedLoan = DB.loans.find(l => l.id === id);
  renderLoanComparison();
}

function renderLoanDetail(l) {
  return `
  <div class="card">
    <div class="card-body">
      <div class="font-display font-bold mb-4" style="font-size:16px">📋 ${l.bank} — ${l.scheme} Details</div>
      <div class="grid grid-2 gap-4 mb-4">
        <div>
          <div class="font-bold text-sm mb-2">Eligibility Criteria</div>
          ${Object.entries(l.eligibility).map(([k,v])=>`<div class="flex gap-2 mb-2"><span class="text-muted text-sm capitalize">${k.replace(/_/g,' ')}:</span><span class="text-sm font-bold">${v}</span></div>`).join('')}
        </div>
        <div>
          <div class="font-bold text-sm mb-2">Key Features</div>
          <div class="text-sm text-muted mb-2">💳 Rate Type: <strong>${l.rateType}</strong></div>
          <div class="text-sm text-muted mb-2">⏳ Moratorium: <strong>${l.moratorium}</strong></div>
          <div class="text-sm text-muted mb-2">🏠 Collateral: <strong>${l.collateralReq ? `Required above ${fmtShort(l.collateralLimit)}` : 'Not required'}</strong></div>
          <div class="text-sm text-muted mb-2">💡 <em>${l.special}</em></div>
        </div>
      </div>
      <div class="font-bold text-sm mb-2">📄 Required Documents</div>
      <div class="grid grid-2">
        ${l.documents.map(d=>`<div class="text-sm text-muted mb-1">• ${d}</div>`).join('')}
      </div>
    </div>
  </div>`;
}

// ── EMI Calculator ───────────────────────────────────────────
function renderEMICalc() {
  if (currentEduGroup() === 'school') {
    $('fin-tab-content').innerHTML = `
    <div class="alert alert-info"><span class="alert-icon">🔒</span> The EMI Calculator becomes useful once you actually need an education loan — that's after 12th, not at 10th class. Check back once you've chosen your Intermediate/Degree path.</div>`;
    return;
  }
  const defaults = { principal: State.financialPlan?.loanAmount || 1000000, rate: State.selectedLoan?.rate || 8.15, tenure: 120 };
  $('fin-tab-content').innerHTML = `
  <div class="font-display font-bold mb-4" style="font-size:18px">🧮 Interactive EMI Calculator</div>
  <div class="grid grid-2 gap-6">
    <div class="card">
      <div class="card-body">
        <div class="slider-wrap mb-4">
          <div class="flex justify-between mb-1"><label class="form-label">Loan Amount</label><span class="highlight" id="disp-principal">${fmtShort(defaults.principal)}</span></div>
          <input type="range" id="sl-principal" min="100000" max="15000000" step="50000" value="${defaults.principal}" oninput="updateEMI()">
          <div class="slider-labels"><span>₹1L</span><span>₹1.5Cr</span></div>
        </div>
        <div class="slider-wrap mb-4">
          <div class="flex justify-between mb-1"><label class="form-label">Interest Rate (% p.a.)</label><span class="highlight" id="disp-rate">${defaults.rate}%</span></div>
          <input type="range" id="sl-rate" min="6" max="15" step="0.05" value="${defaults.rate}" oninput="updateEMI()">
          <div class="slider-labels"><span>6%</span><span>15%</span></div>
        </div>
        <div class="slider-wrap mb-4">
          <div class="flex justify-between mb-1"><label class="form-label">Tenure</label><span class="highlight" id="disp-tenure">${defaults.tenure/12} yrs</span></div>
          <input type="range" id="sl-tenure" min="12" max="180" step="12" value="${defaults.tenure}" oninput="updateEMI()">
          <div class="slider-labels"><span>1 yr</span><span>15 yrs</span></div>
        </div>
        <div class="emi-result">
          <div class="emi-label">Monthly EMI</div>
          <div class="emi-amount" id="emi-amount">₹—</div>
          <div class="emi-label mt-2" id="emi-meta"></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="font-bold mb-4" style="font-size:15px">📊 Payment Breakdown</div>
        <div id="emi-donut-wrap"></div>
        <div class="divider"></div>
        <div id="emi-breakdown-table"></div>
        <div class="alert alert-info mt-4"><span class="alert-icon">💡</span>Section 80E of Income Tax Act allows full deduction on interest paid for education loans.</div>
      </div>
    </div>
  </div>`;
  updateEMI();
}

function updateEMI() {
  const P = parseFloat($('sl-principal')?.value) || 1000000;
  const r = parseFloat($('sl-rate')?.value) || 8.15;
  const n = parseInt($('sl-tenure')?.value) || 120;

  $('disp-principal').textContent = fmtShort(P);
  $('disp-rate').textContent = r.toFixed(2) + '%';
  $('disp-tenure').textContent = (n/12) + ' yrs';

  // Update slider track gradient
  ['principal','rate','tenure'].forEach(id => {
    const el = $(`sl-${id}`);
    if (!el) return;
    const min = parseFloat(el.min), max = parseFloat(el.max), val = parseFloat(el.value);
    const pctVal = ((val - min) / (max - min)) * 100;
    el.style.setProperty('--pct', pctVal + '%');
  });

  const emi = AIEngine.calcEMI(P, r, n);
  const totalPay = emi * n;
  const totalInt = totalPay - P;

  if ($('emi-amount')) $('emi-amount').textContent = fmt(Math.round(emi));
  if ($('emi-meta'))   $('emi-meta').textContent = `Total Payment: ${fmtShort(Math.round(totalPay))} · Total Interest: ${fmtShort(Math.round(totalInt))}`;

  renderDonut(P, totalInt);
  renderEMITable(P, totalInt, n, emi);
}

function renderDonut(principal, interest) {
  const total = principal + interest;
  const pPct = Math.round((principal / total) * 100);
  const iPct = 100 - pPct;
  const r = 60, cx = 80, cy = 80, circ = 2 * Math.PI * r;
  const pOffset = circ - (pPct / 100) * circ;
  const el = $('emi-donut-wrap');
  if (!el) return;
  el.innerHTML = `
  <div class="donut-chart">
    <svg class="donut-svg" width="160" height="160" viewBox="0 0 160 160">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.07)" stroke-width="22"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#6366f1" stroke-width="22"
        stroke-dasharray="${circ}" stroke-dashoffset="${pOffset}" stroke-linecap="round" transform="rotate(-90 ${cx} ${cy})"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#ef4444" stroke-width="22"
        stroke-dasharray="${circ}" stroke-dashoffset="${circ - (iPct/100)*circ}" stroke-linecap="round"
        transform="rotate(${-90+(pPct/100)*360} ${cx} ${cy})"/>
      <text x="${cx}" y="${cy-4}" text-anchor="middle" font-size="13" fill="var(--text-primary)" font-weight="700">${pPct}%</text>
      <text x="${cx}" y="${cy+14}" text-anchor="middle" font-size="10" fill="var(--text-muted)">Principal</text>
    </svg>
    <div class="donut-legend">
      <div class="legend-item"><div class="legend-dot" style="background:#6366f1"></div><div><div class="text-sm font-bold">${fmtShort(principal)}</div><div class="text-xs text-muted">Principal (${pPct}%)</div></div></div>
      <div class="legend-item"><div class="legend-dot" style="background:#ef4444"></div><div><div class="text-sm font-bold">${fmtShort(Math.round(interest))}</div><div class="text-xs text-muted">Interest (${iPct}%)</div></div></div>
    </div>
  </div>`;
}

function renderEMITable(P, totalInt, n, emi) {
  const el = $('emi-breakdown-table');
  if (!el) return;
  // Show year-wise summary
  const rows = [];
  let balance = P;
  const monthlyRate = (parseFloat($('sl-rate')?.value)||8.15) / 12 / 100;
  for (let yr = 1; yr <= Math.ceil(n/12) && yr <= 5; yr++) {
    let yearPrincipal = 0, yearInterest = 0;
    for (let m = 0; m < 12 && (yr-1)*12+m < n; m++) {
      const intPart = balance * monthlyRate;
      const prinPart = emi - intPart;
      yearInterest += intPart;
      yearPrincipal += prinPart;
      balance -= prinPart;
    }
    rows.push(`<tr><td>Year ${yr}</td><td class="amount">${fmt(Math.round(emi*12))}</td><td class="amount">${fmt(Math.round(yearPrincipal))}</td><td class="amount" style="color:#ef4444">${fmt(Math.round(yearInterest))}</td><td class="amount" style="color:#10b981">${fmt(Math.max(0,Math.round(balance)))}</td></tr>`);
  }
  el.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Period</th><th>Total Paid</th><th>Principal</th><th>Interest</th><th>Balance</th></tr></thead><tbody>${rows.join('')}${n > 60 ? `<tr><td colspan="5" class="text-muted text-sm" style="text-align:center">...and ${Math.ceil(n/12)-5} more years</td></tr>` : ''}</tbody></table></div>`;
}

// ── Document Vault ───────────────────────────────────────────
function renderDocVault() {
  const el = $('fin-tab-content');
  const uploaded = Object.values(State.documents).filter(s => s === 'uploaded').length;
  const total = DB.docTypes.length;

  el.innerHTML = `
  <div class="flex items-center justify-between mb-4">
    <div class="font-display font-bold" style="font-size:18px">📁 Document Vault</div>
    <span class="tag ${uploaded===total?'tag-green':'tag-amber'}">${uploaded}/${total} Uploaded</span>
  </div>
  <div class="progress-bar-wrap mb-6" style="height:10px">
    <div class="progress-bar-fill" style="width:${pct(uploaded,total)}%;background:linear-gradient(90deg,#6366f1,#10b981)"></div>
  </div>
  <div id="doc-list">
    ${DB.docTypes.map(doc => renderDocItem(doc)).join('')}
  </div>
  <div class="verification-status ${uploaded >= DB.docTypes.filter(d=>d.required).length ? 'complete' : 'incomplete'}" id="verification-banner">
    <span class="vs-icon">${uploaded >= DB.docTypes.filter(d=>d.required).length ? '✅' : '⏳'}</span>
    <div>
      <div class="vs-title">${uploaded >= DB.docTypes.filter(d=>d.required).length ? 'Document Verification Approved!' : 'Pending Verification'}</div>
      <div class="vs-sub">${uploaded >= DB.docTypes.filter(d=>d.required).length ? 'All required documents uploaded. Loan processing can begin.' : `Upload ${DB.docTypes.filter(d=>d.required).length - uploaded} more required document(s) to proceed.`}</div>
    </div>
  </div>`;
}

function renderDocItem(doc) {
  const status = State.documents[doc.key] || 'pending';
  return `
  <div class="doc-item ${status}" id="doc-${doc.key}" onclick="triggerUpload('${doc.key}')">
    <div class="doc-check ${status}">
      ${status === 'uploaded' ? '✓' : status === 'rejected' ? '✗' : doc.required ? '!' : '○'}
    </div>
    <div class="doc-info">
      <div class="doc-name">${doc.label} ${doc.required ? '<span style="color:#ef4444">*</span>' : '<span class="text-xs text-muted">(Optional)</span>'}</div>
      <div class="doc-status">${status === 'uploaded' ? '✅ Uploaded successfully' : status === 'rejected' ? '❌ Rejected - reupload required' : 'Click to upload'}</div>
    </div>
    <button class="btn btn-secondary btn-sm doc-upload-btn" onclick="event.stopPropagation();triggerUpload('${doc.key}')">
      ${status === 'uploaded' ? '🔄 Replace' : '📤 Upload'}
    </button>
    <input type="file" class="upload-input" id="file-${doc.key}" onchange="handleFileUpload(event,'${doc.key}')">
  </div>`;
}

function triggerUpload(key) {
  $(`file-${key}`)?.click();
}

function handleFileUpload(event, key) {
  const file = event.target.files[0];
  if (!file) return;
  const item = document.getElementById(`doc-${key}`);
  if (item) { item.innerHTML = `<div class="doc-check pending"><span class="loading-spin">↻</span></div><div class="doc-info"><div class="doc-name">Uploading ${file.name}...</div><div class="doc-status text-muted">Please wait</div></div>`; }
  setTimeout(async () => {
    try {
      await api.uploadDocument({ docKey: key, fileName: file.name, fileSize: file.size });
      State.documents[key] = 'uploaded';
      renderDocVault();
      showToast(`${file.name} uploaded successfully ✓`, 'success');
      addNotification('Document Uploaded', `${file.name} has been uploaded to your vault.`, 'success', '📄');
      updateReadinessBadge();
    } catch (err) {
      showToast(err.message || 'Upload failed. Please try again.', 'danger');
      renderDocVault();
    }
  }, 1200);
}

// ── Notifications View ───────────────────────────────────────
function renderNotifications() {
  const selectedExamId = State.user?.selectedExamId || null;
  const selectedExam = selectedExamId ? DB.exams.find(e => e.id === selectedExamId) : null;
  const showAll = !selectedExam || State.notifShowAll;
  const list = showAll ? State.notifications : State.notifications.filter(n => n.examId === selectedExamId);

  $('view-notifications').innerHTML = `
  <div class="section-header flex items-center justify-between flex-wrap gap-2">
    <div><div class="section-title">🔔 Notifications</div>
    <div class="section-sub">${selectedExam ? (showAll ? 'All updates and alerts.' : `Showing alerts for ${selectedExam.name} only, since that's your selected exam.`) : 'All updates and alerts for your career planning journey.'}</div></div>
    ${selectedExam ? `<button class="btn btn-secondary btn-sm" onclick="toggleNotifShowAll()">${showAll ? `🎯 Show only ${selectedExam.name}` : '🔔 Show all notifications'}</button>` : ''}
  </div>
  <div style="display:flex;flex-direction:column;gap:10px">
    ${list.length ? list.map(n => `
    <div class="card" onclick="markNotifRead(${n.id})" style="cursor:pointer;${!n.read?'border-color:var(--accent)':''}">
      <div class="card-body flex gap-3 items-center">
        <div class="notif-item-icon" style="background:rgba(99,102,241,0.12);width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">${n.icon}</div>
        <div style="flex:1">
          <div class="font-bold ${n.read?'text-muted':''}">${n.title}</div>
          <div class="text-sm text-muted mt-1">${n.msg}</div>
          <div class="text-xs text-muted mt-2">${n.time}</div>
        </div>
        ${!n.read ? `<span class="tag tag-accent" style="font-size:10px">New</span>` : ''}
      </div>
    </div>`).join('') : `<div class="text-sm text-muted" style="padding:24px;text-align:center">No notifications for this exam yet.</div>`}
  </div>`;
}

function toggleNotifShowAll() {
  State.notifShowAll = !State.notifShowAll;
  renderNotifications();
}

// ── INIT ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  applyTheme(State.theme);
  State.currentQuote = quoteOfTheDay(); // fresh quote every time the app is opened
  initAuth();
  initSidebar();
  const restored = await tryRestoreSession();
  if (!restored) {
    $('auth-screen').style.display = 'flex';
  }
  updateNotifBadge();
});
