"""
reference_data.py — small reference datasets the backend's deterministic
business logic (loan probability, scholarship matching, action plans) needs.
Mirrors the corresponding entries in the frontend's js/data.js DB object so
the two stay consistent. The bulk of the reference catalogue (colleges,
exams, loan bank list, full career descriptions) intentionally stays in the
frontend's js/data.js, since it's static display/reference content, not
user data or ML output — moving it here wouldn't add real value and risks
drifting out of sync with the (untouched) UI copy.
"""

CAREER_TITLES = {
    1: "B.Tech Engineering",
    2: "MBBS / Doctor",
    3: "Commercial Pilot (CPL)",
    4: "MS Abroad (USA/UK/Canada)",
    5: "Civil Services (IAS/IPS)",
    6: "Law (LLB / BA LLB)",
    7: "Management (MBA/PGDM)",
    8: "Defence Services (Armed Forces)",
    9: "Fashion Designing",
    10: "M.Tech / M.E. (India)",
}

CAREER_SLUGS = {
    1: "engineering", 2: "mbbs", 3: "pilot", 4: "abroad-ms",
    5: "civil-services", 6: "law", 7: "management", 8: "defence",
    9: "fashion-design", 10: "mtech",
}

SCHOLARSHIPS = [
    dict(id=1, name="National Scholarship Portal (NSP)", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=80, maxIncome=800000, gender=None, domicile=None)),
    dict(id=2, name="Jagananna Vidya Deevena", careerIds=[1, 2, 5],
         eligibility=dict(minMarks=0, maxIncome=250000, gender=None, domicile="Andhra Pradesh")),
    dict(id=3, name="AICTE Pragati Scholarship", careerIds=[1],
         eligibility=dict(minMarks=60, maxIncome=800000, gender="Female", domicile=None)),
    dict(id=4, name="HDFC Educational Crisis Scholarship", careerIds=[1, 2, 3, 4, 5],
         eligibility=dict(minMarks=55, maxIncome=500000, gender=None, domicile=None)),
    dict(id=5, name="Inlaks Shivdasani Scholarship", careerIds=[4],
         eligibility=dict(minMarks=85, maxIncome=None, gender=None, domicile=None)),
    dict(id=6, name="KVPY Fellowship", careerIds=[1, 4, 10],
         eligibility=dict(minMarks=75, maxIncome=None, gender=None, domicile=None)),
    dict(id=7, name="Post-Matric Scholarship for SC Students", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=0, maxIncome=250000, gender=None, domicile=None)),
    dict(id=8, name="Post-Matric Scholarship for OBC Students", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=0, maxIncome=250000, gender=None, domicile=None)),
    dict(id=9, name="Post-Matric Scholarship for ST Students", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=0, maxIncome=250000, gender=None, domicile=None)),
    dict(id=10, name="National Means-cum-Merit Scholarship (NMMS)", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=55, maxIncome=350000, gender=None, domicile=None)),
    dict(id=11, name="Pre/Post-Matric Scholarship for Minorities", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=50, maxIncome=200000, gender=None, domicile=None)),
    dict(id=12, name="Maulana Azad National Fellowship", careerIds=[4],
         eligibility=dict(minMarks=55, maxIncome=None, gender=None, domicile=None)),
    dict(id=13, name="TS ePASS Post-Matric Scholarship", careerIds=[1, 2, 5, 6, 7],
         eligibility=dict(minMarks=0, maxIncome=200000, gender=None, domicile="Telangana")),
    dict(id=14, name="TS ePASS Fee Reimbursement Scheme", careerIds=[1, 2, 6, 7],
         eligibility=dict(minMarks=0, maxIncome=200000, gender=None, domicile="Telangana")),
    dict(id=15, name="Begum Hazrat Mahal National Scholarship", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=50, maxIncome=200000, gender="Female", domicile=None)),
    dict(id=16, name="Priyadarshini Scholarship for Girl Students", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=60, maxIncome=400000, gender="Female", domicile=None)),
    dict(id=17, name="Tata Trusts Scholarship", careerIds=[1, 2, 4, 7],
         eligibility=dict(minMarks=70, maxIncome=600000, gender=None, domicile=None)),
    dict(id=18, name="Reliance Foundation Undergraduate Scholarship", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=60, maxIncome=1500000, gender=None, domicile=None)),
    dict(id=19, name="Institute Merit-cum-Means Scholarship", careerIds=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         eligibility=dict(minMarks=75, maxIncome=600000, gender=None, domicile=None)),
    dict(id=20, name="AICTE Saksham Scholarship for Specially-Abled", careerIds=[1],
         eligibility=dict(minMarks=0, maxIncome=800000, gender=None, domicile=None)),
]


def match_scholarships(marks12, family_income, career_id, gender, state=""):
    matched = []
    for s in SCHOLARSHIPS:
        elig = s["eligibility"]
        if career_id not in s["careerIds"]:
            continue
        if marks12 < elig["minMarks"]:
            continue
        if elig["maxIncome"] is not None and family_income > elig["maxIncome"]:
            continue
        if elig["gender"] and elig["gender"] != gender:
            continue
        if elig["domicile"] and elig["domicile"] != state:
            continue
        matched.append(s)
    return matched
