from flask import Blueprint, g, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

from auth import create_token, login_required
from db import db_cursor, row_to_dict, seed_default_notifications

bp = Blueprint("auth_routes", __name__, url_prefix="/api/auth")


def serialize_user(row):
    d = row_to_dict(row)
    if not d:
        return None
    return {
        "id": d["id"],
        "name": d["name"],
        "email": d["email"],
        "educationLevel": d["education_level"],
        "familyIncome": d["family_income"],
        "careerChoice": d["career_choice"],
        "readinessScore": d["readiness_score"],
        "gender": d.get("gender") or "",
        "selectedExamId": d.get("selected_exam_id"),
        "createdAt": d["created_at"],
    }


@bp.post("/register")
def register():
    body = request.get_json(force=True) or {}
    name = (body.get("name") or "").strip()
    email = (body.get("email") or "").strip().lower()
    password = body.get("password") or ""
    education_level = body.get("educationLevel") or ""
    gender = (body.get("gender") or "").strip()

    if not name or not email or not password:
        return jsonify({"error": "name, email and password are required"}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400

    with db_cursor(commit=True) as cur:
        cur.execute("SELECT id FROM users WHERE email = ?", (email,))
        if cur.fetchone():
            return jsonify({"error": "That email is already registered — try logging in instead, or use a different email."}), 409

        password_hash = generate_password_hash(password)
        cur.execute(
            "INSERT INTO users (name, email, password_hash, education_level, family_income, career_choice, readiness_score, gender) "
            "VALUES (?,?,?,?,0,NULL,0,?)",
            (name, email, password_hash, education_level, gender),
        )
        user_id = cur.lastrowid
        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user_row = cur.fetchone()

    seed_default_notifications(user_id)

    token = create_token(user_id)
    return jsonify({"user": serialize_user(user_row), "token": token}), 201


@bp.post("/login")
def login():
    body = request.get_json(force=True) or {}
    email = (body.get("email") or "").strip().lower()
    password = body.get("password") or ""

    with db_cursor() as cur:
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        user_row = cur.fetchone()

    if not user_row or not check_password_hash(user_row["password_hash"], password):
        return jsonify({"error": "Invalid credentials. Please try again."}), 401

    token = create_token(user_row["id"])
    return jsonify({"user": serialize_user(user_row), "token": token})


@bp.get("/me")
@login_required
def me():
    with db_cursor() as cur:
        cur.execute("SELECT * FROM users WHERE id = ?", (g.user_id,))
        user_row = cur.fetchone()
    if not user_row:
        return jsonify({"error": "User not found"}), 404
    return jsonify({"user": serialize_user(user_row)})
