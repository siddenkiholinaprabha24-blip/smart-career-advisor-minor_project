from flask import Blueprint, jsonify, request

from auth import login_required
from college_ml_engine import predict_chance

bp = Blueprint("college_routes", __name__, url_prefix="/api/colleges")

MAX_BATCH = 500


@bp.post("/predict-chance")
@login_required
def predict_chance_batch():
    """
    body: { candidates: [ { clientId, relativeStrength, examType }, ... ] }
    returns: { predictions: [ { clientId, chance, confidence, probabilities, modelVersion }, ... ] }

    The frontend computes relativeStrength itself (candidate rank/score vs.
    the year- and branch-adjusted cutoff for each college) since the college
    catalogue lives client-side; this endpoint owns the actual ML inference
    that turns that number into a Safe/Moderate/Dream/Unlikely prediction.
    """
    body = request.get_json(force=True) or {}
    candidates = body.get("candidates") or []
    if not isinstance(candidates, list):
        return jsonify({"error": "'candidates' must be a list"}), 400
    if len(candidates) > MAX_BATCH:
        return jsonify({"error": f"Too many candidates in one request (max {MAX_BATCH})"}), 400

    predictions = []
    for c in candidates:
        try:
            rel = float(c.get("relativeStrength", 0))
        except (TypeError, ValueError):
            rel = 0.0
        exam_type = c.get("examType") or "rank"
        result = predict_chance(rel, exam_type)
        result["clientId"] = c.get("clientId")
        predictions.append(result)

    return jsonify({"predictions": predictions})
