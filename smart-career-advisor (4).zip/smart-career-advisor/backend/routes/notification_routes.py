from flask import Blueprint, g, jsonify, request

from auth import login_required
from db import db_cursor, row_to_dict

bp = Blueprint("notification_routes", __name__, url_prefix="/api/notifications")


def _row(row):
    d = row_to_dict(row)
    if not d:
        return None
    return {
        "id": d["id"], "title": d["title"], "msg": d["msg"], "type": d["type"],
        "icon": d["icon"], "read": bool(d["is_read"]), "time": d["created_at"],
        "examId": d.get("exam_id"),
    }


@bp.get("")
@login_required
def list_notifications():
    with db_cursor() as cur:
        cur.execute("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC", (g.user_id,))
        rows = cur.fetchall()
    return jsonify({"notifications": [_row(r) for r in rows]})


@bp.post("")
@login_required
def create_notification():
    body = request.get_json(force=True) or {}
    title = body.get("title", "")
    msg = body.get("msg", "")
    ntype = body.get("type", "info")
    icon = body.get("icon", "🔔")
    exam_id = body.get("examId")
    with db_cursor(commit=True) as cur:
        cur.execute(
            "INSERT INTO notifications (user_id, title, msg, type, icon, exam_id, is_read) VALUES (?,?,?,?,?,?,0)",
            (g.user_id, title, msg, ntype, icon, exam_id),
        )
        nid = cur.lastrowid
        cur.execute("SELECT * FROM notifications WHERE id = ?", (nid,))
        row = cur.fetchone()
    return jsonify(_row(row)), 201


@bp.put("/<int:notif_id>/read")
@login_required
def mark_read(notif_id):
    with db_cursor(commit=True) as cur:
        cur.execute(
            "UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?",
            (notif_id, g.user_id),
        )
    return jsonify({"id": notif_id, "read": True})
