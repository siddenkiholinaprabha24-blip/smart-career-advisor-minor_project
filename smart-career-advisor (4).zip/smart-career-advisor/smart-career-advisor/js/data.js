// Smart Career Advisor — data.js
'use strict';
// Engineering branches for the College Predictor's "Preferred Branch" filter.
// Multipliers approximate how much easier/harder each branch is to get into
// relative to the college's base (CSE-level) cutoff — illustrative only.
const ENGINEERING_BRANCHES = [
  { key:'AI',        label:'Artificial Intelligence (AI/AIML)',    multiplier:0.85 },
  { key:'CSE',       label:'Computer Science (CSE)',              multiplier:1.0  },
  { key:'IT',        label:'Information Technology (IT)',          multiplier:1.15 },
  { key:'ECE',       label:'Electronics & Communication (ECE)',    multiplier:1.4  },
  { key:'EEE',       label:'Electrical & Electronics (EEE)',       multiplier:1.6  },
  { key:'Mechanical',label:'Mechanical Engineering',                multiplier:2.0  },
  { key:'Civil',     label:'Civil Engineering',                    multiplier:2.4  }
];

// ── Education levels, streams & guided-path options ────────────
// Drives Step 1 of the Career Evaluator: "What's your current education
// level?" is asked before any career-goal questions, and the follow-up
// question/options shown depend on which `group` the level belongs to.
const EDUCATION_LEVELS = [
  { key:'10th',          label:'10th Class',                                   group:'school' },
  { key:'inter_mpc',     label:'Intermediate — MPC (Maths, Physics, Chemistry)',group:'inter'  },
  { key:'inter_bipc',    label:'Intermediate — BiPC (Biology, Physics, Chemistry)', group:'inter' },
  { key:'inter_mec',     label:'Intermediate — MEC (Maths, Economics, Commerce)', group:'inter' },
  { key:'inter_cec',     label:'Intermediate — CEC (Civics, Economics, Commerce)', group:'inter' },
  { key:'inter_hec',     label:'Intermediate — HEC (History, Economics, Civics)', group:'inter' },
  { key:'inter_other',   label:'Intermediate — Others',                        group:'inter'  },
  { key:'polytechnic',   label:'Polytechnic',                                  group:'poly'   },
  { key:'diploma',       label:'Diploma',                                      group:'poly'   },
  { key:'degree',        label:'Degree',                                       group:'grad'   },
  { key:'btech',         label:'B.Tech',                                       group:'grad'   },
  { key:'mbbs',          label:'MBBS',                                         group:'grad'   },
  { key:'postgraduate',  label:'Postgraduate',                                 group:'grad'   },
  { key:'other',         label:'Other',                                       group:'grad'   }
];

// Follow-up "what next" question shown right after the education level is
// picked — before any career-interest questions are asked.
const EDU_PATH_OPTIONS = {
  school: { question:'What would you like to pursue after 10th?', options:['Intermediate','Polytechnic'] },
  inter:  { question:'What are you aiming for after Intermediate?', options:['Engineering','Medical','Degree','Government Jobs','Other'] },
  poly:   { question:'What is your next step after Polytechnic/Diploma?', options:['B.Tech (Lateral Entry)','Degree','Government Jobs','Start Working'] },
  grad:   { question:'What would you like to do next?', options:['Higher Studies (M.Tech/MS/MBA)','Private Job','Government Job','Competitive Exams'] }
};

// Stream/branch interest options shown to 10th-class students (who haven't
// picked a stream yet) based on whether they chose Intermediate or
// Polytechnic in Step 1.
const STREAM_INTEREST_OPTIONS = {
  'Intermediate': ['MPC (Maths, Physics, Chemistry)','BiPC (Biology, Physics, Chemistry)','MEC (Maths, Economics, Commerce)','CEC (Civics, Economics, Commerce)','HEC (History, Economics, Civics)','Other'],
  'Polytechnic':  ['Mechanical Engineering','Civil Engineering','Electrical & Electronics (EEE)','Electronics & Communication (ECE)','Computer Science (CSE)','Other']
};

// Multi-select skills offered in the Career Evaluator's Skills step.
const SKILLS_LIST = ['Coding','Communication','Leadership','Creativity','Problem Solving','Mathematics','Public Speaking','Analytical Skills','Technical Skills'];

// Proper 1–5 Research Interest scale (replaces the old free-form options).
const RESEARCH_INTEREST_SCALE = [
  { v:1, label:'Not Interested'    },
  { v:2, label:'Slightly Interested' },
  { v:3, label:'Neutral'           },
  { v:4, label:'Interested'        },
  { v:5, label:'Very Interested'   }
];

// Government job categories — shown in the dedicated Government Jobs
// guidance section and factored into the AI recommendation engine.
const GOVT_JOBS = [
  { key:'upsc',       name:'UPSC (IAS / IPS / IFS)', icon:'🏛️', desc:'Union Public Service Commission Civil Services — India\'s most prestigious All-India administrative, police and foreign services.', exams:['UPSC CSE'], roadmap:['Complete graduation in any stream','Clear UPSC Prelims (GS + CSAT)','Clear Mains (9 papers)','Clear Personality Test (Interview)','Cadre & service allotment'] },
  { key:'state_psc',  name:'State PSC (Group I / II)', icon:'📜', desc:'State-level administrative and allied services (Group I/II officers, Tehsildar, DSP etc.) conducted by each state\'s Public Service Commission (e.g. TSPSC, APPSC).', exams:['TSPSC Group I','TSPSC Group II'], roadmap:['Graduation in any stream','Clear Prelims','Clear Mains','Interview / Certificate verification'] },
  { key:'ssc',        name:'SSC (Staff Selection Commission)', icon:'📋', desc:'Central government non-gazetted posts — CGL, CHSL, MTS, Stenographer and more.', exams:['SSC CGL','SSC CHSL'], roadmap:['Class 12 or Graduation (per post)','Tier I (Objective)','Tier II (Descriptive/Skill)','Document Verification & Posting'] },
  { key:'banking',    name:'Banking (IBPS / SBI / RBI)', icon:'🏦', desc:'Probationary Officer, Clerk and Specialist Officer roles in public-sector banks and the RBI.', exams:['IBPS PO','SBI PO'], roadmap:['Graduation in any stream','Prelims','Mains','Interview / Group Discussion'] },
  { key:'railways',   name:'Railways (RRB)', icon:'🚆', desc:'Indian Railways technical and non-technical posts via the Railway Recruitment Board — NTPC, Group D, ALP, JE.', exams:['RRB NTPC','RRB Group D'], roadmap:['10th/12th/Diploma/Graduation (per post)','CBT 1','CBT 2','Skill/Physical Test','Document Verification'] },
  { key:'defence',    name:'Defence (Army / Navy / Air Force)', icon:'🎖️', desc:'Commissioned and non-commissioned roles in the Armed Forces via NDA, CDS, Agniveer and technical entries.', exams:['NDA','CDS'], roadmap:['Class 12 (PCM for technical entries)','Written Exam','SSB Interview','Medical Test','Training Academy'] },
  { key:'police',     name:'Police & Central Armed Police Forces', icon:'👮', desc:'Constable, Sub-Inspector and CAPF (CRPF, BSF, CISF etc.) roles.', exams:['SSC CAPF'], roadmap:['10th/12th/Graduation (per post)','Written Exam','Physical Efficiency Test','Medical Test','Training'] },
  { key:'teaching',   name:'Teaching (TET / DSC / NET)', icon:'👩‍🏫', desc:'Government school and college teaching posts via TET, DSC and UGC-NET (for lecturers).', exams:['UGC NET'], roadmap:['B.Ed / relevant PG degree','Clear Eligibility Test (TET/NET)','District Selection Committee (DSC) exam','Counselling & Posting'] },
  { key:'psu',        name:'PSU Jobs (Public Sector Undertakings)', icon:'⚙️', desc:'Engineering and management roles in PSUs like ONGC, BHEL, NTPC, ISRO — mostly via GATE score or dedicated PSU exams.', exams:['GATE'], roadmap:['B.Tech / relevant degree','Qualify via GATE score or PSU-specific exam','Group Discussion / Interview','Medical & Document Verification'] },
  { key:'other_govt', name:'Other Government Opportunities', icon:'🗂️', desc:'Judiciary (via Law), Insurance (LIC/NIACL), ISRO/DRDO scientist posts and various state corporations.', exams:[], roadmap:['Relevant degree for the post','Written Exam','Interview','Appointment'] }
];

// DGCA-based Commercial Pilot career roadmap (careerId 3).
const PILOT_ROADMAP = {
  title:'Commercial Pilot Career Roadmap',
  note:'DGCA (Directorate General of Civil Aviation) examinations and medical certification are mandatory at every stage of becoming a licensed commercial pilot in India.',
  steps: [
    { stage:'Class 12 (PCM)',      detail:'Complete Class 12 with Physics & Mathematics — mandatory eligibility for pilot training.' },
    { stage:'DGCA Class 2 Medical',detail:'Obtain a DGCA Class 2 Medical Certificate before starting flight training.' },
    { stage:'Ground Classes',      detail:'Enroll in DGCA-approved ground classes: Air Navigation, Aviation Meteorology, Air Regulations, Technical & General subjects.' },
    { stage:'DGCA CPL Exams',      detail:'Clear the DGCA computer-based exams for all ground subjects — mandatory before license issue.' },
    { stage:'Flight Training',     detail:'Complete 200 hours of flying at a DGCA-approved Flying Training Organisation (FTO), e.g. IGRUA.' },
    { stage:'DGCA Class 1 Medical',detail:'Clear the more stringent DGCA Class 1 Medical Certificate required to hold a CPL.' },
    { stage:'CPL Issuance',        detail:'DGCA issues the Commercial Pilot License (CPL) once exams, flying hours and medicals are all cleared.' },
    { stage:'Type Rating',         detail:'Get type-rated on a specific aircraft (e.g. A320, B737) — usually sponsored by an airline cadet program.' },
    { stage:'Airline Placement',   detail:'Join as a First Officer with a domestic/international airline and build hours toward becoming a Captain.' }
  ]
};

// Specializations offered within an MBA/PGDM — mirrors ENGINEERING_BRANCHES
// so the College Predictor can give branch-aware Management predictions too.
const MANAGEMENT_SPECIALIZATIONS = [
  { key:'General',   label:'General Management',        multiplier:1.0  },
  { key:'Finance',   label:'Finance',                    multiplier:1.02 },
  { key:'Marketing', label:'Marketing',                  multiplier:1.0  },
  { key:'BusinessAnalytics', label:'Business Analytics', multiplier:1.05 },
  { key:'HR',        label:'Human Resources (HR)',       multiplier:0.9  },
  { key:'Operations',label:'Operations',                 multiplier:0.92 }
];

// Intermediate / Junior Colleges — shown to 10th-class students in the
// College Finder instead of B.Tech/MBBS/etc. colleges, since that's the
// stage relevant to them right after 10th.
const JUNIOR_COLLEGES = [
  { id:1,  name:'Government Junior College, Hanamkonda',        location:'Warangal, Telangana', type:'Government', streams:['MPC','BiPC','MEC','CEC'], annualFee:2000,  hostelFee:0,     total2yr:4000,   seats:480, board:'TSBIE' },
  { id:2,  name:'Telangana Social Welfare Residential Jr. College, Warangal', location:'Warangal, Telangana', type:'Government (Residential)', streams:['MPC','BiPC'], annualFee:0,  hostelFee:0,     total2yr:0,      seats:320, board:'TSBIE' },
  { id:3,  name:'Sri Chaitanya Junior College, Warangal',        location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC'],           annualFee:110000, hostelFee:60000, total2yr:340000, seats:600, board:'TSBIE' },
  { id:4,  name:'Narayana Junior College, Warangal',             location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC'],           annualFee:100000, hostelFee:55000, total2yr:310000, seats:600, board:'TSBIE' },
  { id:5,  name:'Bhashyam Junior College, Warangal',             location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC','MEC'],     annualFee:85000,  hostelFee:50000, total2yr:270000, seats:480, board:'TSBIE' },
  { id:6,  name:'Kakatiya Junior College, Warangal',             location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC','CEC','HEC'], annualFee:45000, hostelFee:30000, total2yr:150000, seats:400, board:'TSBIE' },
  { id:7, name:'SR Junior College, Warangal',                  location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC'], annualFee:105000, hostelFee:58000, total2yr:326000, seats:560, board:'TSBIE' },
  { id:8, name:'SR Junior College, Karimnagar',                location:'Karimnagar, Telangana', type:'Private', streams:['MPC','BiPC'], annualFee:95000,  hostelFee:52000, total2yr:294000, seats:480, board:'TSBIE' },
  { id:9, name:'SR Junior College, Hyderabad (Kukatpally)',    location:'Hyderabad, Telangana', type:'Private', streams:['MPC','BiPC','MEC'], annualFee:130000, hostelFee:65000, total2yr:390000, seats:650, board:'TSBIE' },
  { id:10,  name:'Government Junior College for Girls, Warangal', location:'Warangal, Telangana', type:'Government', streams:['MPC','BiPC','MEC','CEC','HEC'], annualFee:1500, hostelFee:0, total2yr:3000, seats:400, board:'TSBIE', womenOnly:true },
  { id:11,  name:'Sri Chaitanya Junior College, Hyderabad (Ameerpet)', location:'Hyderabad, Telangana', type:'Private', streams:['MPC','BiPC'],  annualFee:150000, hostelFee:70000, total2yr:440000, seats:800, board:'TSBIE' },
  { id:12,  name:'Narayana Junior College, Hyderabad (Kukatpally)', location:'Hyderabad, Telangana', type:'Private', streams:['MPC','BiPC'],     annualFee:140000, hostelFee:65000, total2yr:410000, seats:750, board:'TSBIE' },
  { id:13, name:'Government City College, Hyderabad',            location:'Hyderabad, Telangana', type:'Government', streams:['MEC','CEC','HEC'], annualFee:2000,  hostelFee:0,     total2yr:4000,   seats:360, board:'TSBIE' },
  { id:14, name:'TSWREIS Junior College, Hanamkonda',             location:'Hanamkonda, Telangana', type:'Government (Residential)', streams:['MPC','BiPC'], annualFee:0, hostelFee:0, total2yr:0, seats:280, board:'TSBIE' },
  { id:15, name:'Sri Gayatri Junior College, Warangal',           location:'Warangal, Telangana', type:'Private', streams:['MPC','BiPC'],          annualFee:70000,  hostelFee:40000, total2yr:220000, seats:360, board:'TSBIE' },
  { id:16, name:'Aditya Junior College, Kakinada',                location:'Kakinada, Andhra Pradesh', type:'Private', streams:['MPC','BiPC'],     annualFee:95000,  hostelFee:55000, total2yr:300000, seats:480, board:'BIEAP' },
  { id:17, name:'Delhi Public School Jr. College, Nacharam',      location:'Hyderabad, Telangana', type:'Private (CBSE-affiliated)', streams:['MPC','BiPC','MEC'], annualFee:180000, hostelFee:0, total2yr:360000, seats:200, board:'CBSE' },
  { id:18, name:'Government Polytechnic College, Warangal',       location:'Warangal, Telangana', type:'Government (Polytechnic)', streams:['Mechanical','Civil','ECE','EEE','CSE'], annualFee:3000, hostelFee:0, total2yr:6000, seats:600, board:'SBTET Telangana' },
  { id:19, name:'Sri Indu Polytechnic College, Hyderabad',        location:'Hyderabad, Telangana', type:'Private (Polytechnic)', streams:['Mechanical','ECE','CSE'], annualFee:45000, hostelFee:25000, total2yr:140000, seats:360, board:'SBTET Telangana' },
  // ── Andhra Pradesh ──
  { id:20, name:'Sri Chaitanya Junior College, Vijayawada',       location:'Vijayawada, Andhra Pradesh', type:'Private', streams:['MPC','BiPC'], annualFee:130000, hostelFee:65000, total2yr:390000, seats:700, board:'BIEAP' },
  { id:21, name:'Narayana Junior College, Guntur',                location:'Guntur, Andhra Pradesh', type:'Private', streams:['MPC','BiPC'], annualFee:120000, hostelFee:60000, total2yr:360000, seats:650, board:'BIEAP' },
  { id:22, name:'Government Junior College, Visakhapatnam',       location:'Visakhapatnam, Andhra Pradesh', type:'Government', streams:['MPC','BiPC','MEC','CEC'], annualFee:1800, hostelFee:0, total2yr:3600, seats:420, board:'BIEAP' },
  // ── Maharashtra ──
  { id:23, name:"Fergusson College Junior Section, Pune",         location:'Pune, Maharashtra', type:'Private Aided', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:15000, hostelFee:35000, total2yr:100000, seats:900, board:'Maharashtra State Board' },
  { id:24, name:"St. Xavier's Junior College, Mumbai",            location:'Mumbai, Maharashtra', type:'Private (Minority)', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:35000, hostelFee:0, total2yr:70000, seats:400, board:'Maharashtra State Board' },
  { id:25, name:'Ruia Junior College, Mumbai',                    location:'Mumbai, Maharashtra', type:'Government Aided', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:8000, hostelFee:0, total2yr:16000, seats:600, board:'Maharashtra State Board' },
  { id:26, name:'Government Polytechnic, Mumbai',                 location:'Mumbai, Maharashtra', type:'Government (Polytechnic)', streams:['Mechanical','Civil','ECE','CSE'], annualFee:12000, hostelFee:20000, total2yr:24000, seats:480, board:'MSBTE' },
  // ── Karnataka ──
  { id:27, name:'National College (PU), Basavanagudi, Bengaluru', location:'Bengaluru, Karnataka', type:'Private Aided', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:20000, hostelFee:0, total2yr:40000, seats:700, board:'Karnataka PUE Board' },
  { id:28, name:'Vivekananda PU College, Bengaluru',              location:'Bengaluru, Karnataka', type:'Private', streams:['Science (PCM)','Science (PCB)'], annualFee:60000, hostelFee:45000, total2yr:210000, seats:500, board:'Karnataka PUE Board' },
  { id:29, name:'Sri Chaitanya PU College, Bengaluru',            location:'Bengaluru, Karnataka', type:'Private', streams:['Science (PCM)','Science (PCB)'], annualFee:150000, hostelFee:70000, total2yr:440000, seats:600, board:'Karnataka PUE Board' },
  { id:30, name:'Government PU College, Mysuru',                  location:'Mysuru, Karnataka', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:1000, hostelFee:0, total2yr:2000, seats:400, board:'Karnataka PUE Board' },
  // ── Tamil Nadu ──
  { id:31, name:'Loyola Academy Higher Secondary, Chennai',       location:'Chennai, Tamil Nadu', type:'Private Aided', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:25000, hostelFee:0, total2yr:50000, seats:500, board:'Tamil Nadu State Board' },
  { id:32, name:'Government Higher Secondary School, Chennai',    location:'Chennai, Tamil Nadu', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:500, hostelFee:0, total2yr:1000, seats:450, board:'Tamil Nadu State Board' },
  { id:33, name:'Velammal Vidhyashram Higher Secondary, Chennai', location:'Chennai, Tamil Nadu', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:90000, hostelFee:50000, total2yr:280000, seats:400, board:'CBSE' },
  // ── Delhi / NCR ──
  { id:34, name:'Delhi Public School, R.K. Puram (Sr. Secondary)',location:'New Delhi', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:150000, hostelFee:0, total2yr:300000, seats:480, board:'CBSE' },
  { id:35, name:'Government Sarvodaya Bal Vidyalaya (Sr. Sec.), Delhi', location:'New Delhi', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:0, hostelFee:0, total2yr:0, seats:600, board:'CBSE / Delhi Govt.' },
  { id:36, name:'Ramjas School, Daryaganj (Sr. Secondary)',       location:'New Delhi', type:'Private Aided', streams:['Science (PCM)','Commerce','Humanities'], annualFee:20000, hostelFee:0, total2yr:40000, seats:350, board:'CBSE' },
  // ── Uttar Pradesh ──
  { id:37, name:'La Martiniere College, Lucknow',                 location:'Lucknow, Uttar Pradesh', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:110000, hostelFee:180000, total2yr:580000, seats:250, board:'ISC (CISCE)' },
  { id:38, name:'City Montessori School, Lucknow',                location:'Lucknow, Uttar Pradesh', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:70000, hostelFee:0, total2yr:140000, seats:600, board:'CBSE/ISC' },
  { id:39, name:'Government Inter College, Kanpur',                location:'Kanpur, Uttar Pradesh', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:1000, hostelFee:0, total2yr:2000, seats:400, board:'UP Board' },
  // ── West Bengal ──
  { id:40, name:'South Point High School (Higher Sec.), Kolkata', location:'Kolkata, West Bengal', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:60000, hostelFee:0, total2yr:120000, seats:700, board:'CBSE / WBCHSE' },
  { id:41, name:'Presidency University Junior Wing, Kolkata',     location:'Kolkata, West Bengal', type:'Government Aided', streams:['Science (PCM)','Science (PCB)','Humanities'], annualFee:5000, hostelFee:20000, total2yr:10000, seats:300, board:'WBCHSE' },
  // ── Rajasthan ──
  { id:42, name:'Maharaja Sawai Bhawani Singh School (Sr. Sec.), Jaipur', location:'Jaipur, Rajasthan', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:95000, hostelFee:0, total2yr:190000, seats:350, board:'CBSE' },
  { id:43, name:'Government Sr. Secondary School, Kota',           location:'Kota, Rajasthan', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:1500, hostelFee:0, total2yr:3000, seats:450, board:'Rajasthan State Board / CBSE' },
  { id:44, name:'Allen Career Institute Sr. Secondary, Kota',      location:'Kota, Rajasthan', type:'Private (Integrated coaching)', streams:['Science (PCM)','Science (PCB)'], annualFee:250000, hostelFee:120000, total2yr:740000, seats:1200, board:'CBSE / Rajasthan Board' },
  // ── Gujarat ──
  { id:45, name:'Sardar Patel Vidyalaya (Sr. Sec.), Ahmedabad',   location:'Ahmedabad, Gujarat', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:65000, hostelFee:0, total2yr:130000, seats:400, board:'GSEB / CBSE' },
  { id:46, name:'Government Higher Secondary School, Surat',      location:'Surat, Gujarat', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:1200, hostelFee:0, total2yr:2400, seats:380, board:'GSEB' },
  // ── Kerala ──
  { id:47, name:'Govt. Model Higher Secondary School, Thiruvananthapuram', location:'Thiruvananthapuram, Kerala', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:800, hostelFee:0, total2yr:1600, seats:400, board:'Kerala HSE Board' },
  { id:48, name:"St. Joseph's Higher Secondary School, Kochi",    location:'Kochi, Kerala', type:'Private Aided', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:15000, hostelFee:0, total2yr:30000, seats:350, board:'Kerala HSE Board' },
  // ── Bihar ──
  { id:49, name:'Patna Science College (Intermediate Wing)',       location:'Patna, Bihar', type:'Government', streams:['Science (PCM)','Science (PCB)'], annualFee:2000, hostelFee:15000, total2yr:4000, seats:500, board:'Bihar School Examination Board' },
  { id:50, name:"St. Xavier's High School (Intermediate), Patna", location:'Patna, Bihar', type:'Private', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:40000, hostelFee:0, total2yr:80000, seats:300, board:'CBSE' },
  // ── Madhya Pradesh ──
  { id:51, name:'Govt. Excellence Higher Secondary School, Bhopal', location:'Bhopal, Madhya Pradesh', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:1000, hostelFee:0, total2yr:2000, seats:420, board:'MP Board' },
  // ── Punjab / Chandigarh ──
  { id:52, name:'DAV Sr. Secondary School, Chandigarh',           location:'Chandigarh, Punjab', type:'Private Aided', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:22000, hostelFee:0, total2yr:44000, seats:450, board:'CBSE' },
  { id:53, name:'Government Model Sr. Secondary School, Chandigarh', location:'Chandigarh, Punjab', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:0, hostelFee:0, total2yr:0, seats:400, board:'CBSE' },
  // ── Odisha ──
  { id:54, name:'Government Junior College, Bhubaneswar',          location:'Bhubaneswar, Odisha', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce'], annualFee:1000, hostelFee:0, total2yr:2000, seats:380, board:'CHSE Odisha' },
  // ── Assam / Northeast ──
  { id:55, name:'Cotton Collegiate Higher Secondary School, Guwahati', location:'Guwahati, Assam', type:'Government', streams:['Science (PCM)','Science (PCB)','Commerce','Humanities'], annualFee:1200, hostelFee:0, total2yr:2400, seats:350, board:'AHSEC' }
];

const DB = {
  careers: [
    { id:1, slug:'engineering',    title:'B.Tech Engineering',       icon:'⚙️', color:'#6366f1', gradient:'linear-gradient(135deg,#6366f1,#8b5cf6)', description:'Premier technical degree covering CS, ECE, Mechanical, Civil. Gateway to software, manufacturing and research.', avgSalaryMin:600000,  avgSalaryMax:2500000,  durationYears:4, difficulty:'High',          marketDemand:'Very High', skills:['Mathematics','Physics','Programming','Problem Solving'], careers:['Software Engineer','Data Scientist','Mechanical Engineer','Robotics Engineer'] },
    { id:2, slug:'mbbs',           title:'MBBS / Doctor',            icon:'🩺', color:'#10b981', gradient:'linear-gradient(135deg,#10b981,#059669)', description:'Bachelor of Medicine & Surgery. The definitive path to becoming a licensed physician in India.', avgSalaryMin:800000,  avgSalaryMax:4000000,  durationYears:5, difficulty:'Extremely High', marketDemand:'Very High', skills:['Biology','Chemistry','Anatomy','Clinical Skills'],          careers:['General Physician','Surgeon','Specialist Doctor','Researcher'] },
    { id:3, slug:'pilot',          title:'Commercial Pilot (CPL)',    icon:'✈️', color:'#f59e0b', gradient:'linear-gradient(135deg,#f59e0b,#d97706)', description:'Commercial Pilot License training. Fly for major domestic and international airlines.', avgSalaryMin:1800000, avgSalaryMax:8000000,  durationYears:3, difficulty:'Very High',      marketDemand:'High',      skills:['Mathematics','Physics','Spatial Awareness','English'],     careers:['Airline Pilot','Charter Pilot','Cargo Pilot','Flight Instructor'] },
    { id:4, slug:'abroad-ms',      title:'MS Abroad (USA/UK/Canada)',icon:'🌍', color:'#3b82f6', gradient:'linear-gradient(135deg,#3b82f6,#1d4ed8)', description:'Masters from top global universities. Opens doors to global tech companies and research labs.', avgSalaryMin:5000000, avgSalaryMax:15000000, durationYears:2, difficulty:'Very High',      marketDemand:'Very High', skills:['Research Skills','GRE/TOEFL','Programming','Academic Writing'], careers:['ML Engineer','Research Scientist','Product Manager','Quant'] },
    { id:5, slug:'civil-services', title:'Civil Services (IAS/IPS)', icon:'🏛️', color:'#ec4899', gradient:'linear-gradient(135deg,#ec4899,#be185d)', description:'UPSC Civil Services. Join IAS, IPS, IFS — most prestigious administrative career in India.', avgSalaryMin:700000,  avgSalaryMax:2200000,  durationYears:1, difficulty:'Extremely High', marketDemand:'Moderate',  skills:['General Knowledge','Current Affairs','Essay Writing','Leadership'], careers:['IAS Officer','IPS Officer','IFS Diplomat','IRS Officer'] },
    { id:6, slug:'law',            title:'Law (LLB / BA LLB)',        icon:'⚖️', color:'#0ea5e9', gradient:'linear-gradient(135deg,#0ea5e9,#0369a1)', description:'5-year integrated or 3-year LLB. Path to litigation, corporate law, judiciary and policy roles.', avgSalaryMin:500000,  avgSalaryMax:3000000,  durationYears:5, difficulty:'High',          marketDemand:'High',      skills:['Reading Comprehension','Legal Reasoning','English','Current Affairs'], careers:['Litigator','Corporate Lawyer','Judge','Legal Advisor'] },
    { id:7, slug:'management',     title:'Management (MBA/PGDM)',     icon:'📊', color:'#a855f7', gradient:'linear-gradient(135deg,#a855f7,#7e22ce)', description:'2-year MBA/PGDM from top B-schools. Gateway to consulting, finance, product and general management roles.', avgSalaryMin:900000,  avgSalaryMax:5000000,  durationYears:2, difficulty:'High',          marketDemand:'Very High', skills:['Quant Aptitude','Verbal Ability','Data Interpretation','Leadership'], careers:['Consultant','Product Manager','Investment Banker','Business Analyst'] },
    { id:8, slug:'defence',        title:'Defence Services (Armed Forces)', icon:'🎖️', color:'#65a30d', gradient:'linear-gradient(135deg,#65a30d,#3f6212)', description:'NDA/CDS route into the Indian Army, Navy or Air Force as a commissioned officer.', avgSalaryMin:600000,  avgSalaryMax:2000000,  durationYears:4, difficulty:'Very High',      marketDemand:'Moderate',  skills:['Physical Fitness','Mathematics','General Knowledge','Leadership'],  careers:['Army Officer','Navy Officer','Air Force Officer','Defence Analyst'] },
    { id:9, slug:'fashion-design',  title:'Fashion Designing',         icon:'👗', color:'#f43f5e', gradient:'linear-gradient(135deg,#f43f5e,#be123c)', description:'4-year B.Des or diploma via NIFT/NID. Path into apparel design, styling, merchandising and textile innovation.', avgSalaryMin:400000, avgSalaryMax:1800000, durationYears:4, difficulty:'Moderate', marketDemand:'High', skills:['Creativity','Sketching','Colour Theory','Trend Awareness'], careers:['Fashion Designer','Textile Designer','Costume Designer','Fashion Merchandiser'] },
    { id:10,slug:'mtech',           title:'M.Tech / M.E. (India)',     icon:'🔧', color:'#0891b2', gradient:'linear-gradient(135deg,#0891b2,#155e75)', description:'2-year Master of Technology via GATE, taken up right after B.Tech for specialisation, teaching/R&D roles or PSU jobs.', avgSalaryMin:700000, avgSalaryMax:2800000, durationYears:2, difficulty:'High', marketDemand:'High', skills:['Mathematics','Research Skills','Technical Skills','Problem Solving'], careers:['R&D Engineer','Assistant Professor','PSU Engineer','Design Engineer'] }
  ],
  exams: [
    { id:1,  careerId:1, name:'JEE Main',      fullForm:'Joint Entrance Examination Main',    conductingBody:'NTA',         examDate:'January & April', regDate:'November & February', frequency:'Twice a year', mode:'Online',   examType:'rank',       scoreLabel:'JEE Main Rank (CRL)',     syllabus:['Physics: Mechanics, Electricity, Optics, Modern Physics','Mathematics: Algebra, Calculus, Coordinate Geometry','Chemistry: Organic, Inorganic, Physical Chemistry'], prepTips:['Practice 10+ years papers','Target 99+ percentile for top NITs','Daily 8hr study schedule','Focus on NCERT first'], url:'https://jeemain.nta.nic.in', fee:1000 },
    { id:2,  careerId:1, name:'JEE Advanced',  fullForm:'Joint Entrance Examination Advanced',conductingBody:'IIT Bombay',  examDate:'May',             regDate:'April',               frequency:'Once a year',  mode:'Online',   examType:'rank',       scoreLabel:'JEE Advanced Rank (CRL)', syllabus:['Physics: Advanced Mechanics, Electromagnetic Induction','Mathematics: Complex Numbers, Probability, Integration','Chemistry: Stereochemistry, Electrochemistry'], prepTips:['Only top 2.5 lakh JEE Main qualifiers eligible','Solve previous IIT papers','Focus on conceptual depth','Join reputed coaching institute'], url:'https://jeeadv.ac.in', fee:3400 },
    { id:3,  careerId:1, name:'BITSAT',        fullForm:'Birla Institute of Technology and Science Admission Test', conductingBody:'BITS Pilani', examDate:'May & June', regDate:'January-April', frequency:'Once a year', mode:'Online', examType:'score', maxScore:390, scoreLabel:'BITSAT Score (out of 390)', syllabus:['Physics & Chemistry: Class 11-12 NCERT+','Mathematics: Class 11-12 advanced problems','English Proficiency & Logical Reasoning'], prepTips:['Attempt all 130 questions, no major negative for guessing pattern','Speed matters — 3 hrs for 130 Qs','Practice previous year BITSAT papers'], url:'https://bitsadmission.com', fee:3400 },
    { id:4,  careerId:1, name:'VITEEE',        fullForm:'VIT Engineering Entrance Examination', conductingBody:'VIT Vellore', examDate:'April', regDate:'November-March', frequency:'Once a year', mode:'Online', examType:'rank', scoreLabel:'VITEEE Rank', syllabus:['Physics & Chemistry: Class 11-12','Mathematics/Biology: Class 11-12','English & Aptitude'], prepTips:['Focus on Class 12 board syllabus overlap','Time management across sections','Attempt mock tests on VIT portal'], url:'https://viteee.vit.ac.in', fee:1350 },
    { id:5,  careerId:1, name:'SRMJEEE',       fullForm:'SRM Joint Engineering Entrance Examination', conductingBody:'SRM Institute', examDate:'April', regDate:'December-March', frequency:'Once a year', mode:'Online', examType:'rank', scoreLabel:'SRMJEEE Rank', syllabus:['Physics, Chemistry, Mathematics: Class 11-12','English & Aptitude'], prepTips:['NCERT based prep sufficient','Practice previous year cutoff trends'], url:'https://www.srmist.edu.in', fee:1200 },
    { id:6,  careerId:2, name:'NEET UG',       fullForm:'National Eligibility cum Entrance Test',conductingBody:'NTA',     examDate:'May',             regDate:'March',               frequency:'Once a year',  mode:'Offline',  examType:'rank',       scoreLabel:'NEET UG All-India Rank', syllabus:['Biology: Zoology & Botany (50% weightage)','Physics: Mechanics, Optics, Thermodynamics','Chemistry: Organic, Inorganic, Physical'], prepTips:['720 marks, need 600+ for govt college','NCERT is the Bible for NEET','Solve 30 years NEET/AIPMT papers','Strong Biology fundamentals'], url:'https://neet.nta.nic.in', fee:1700 },
    { id:7,  careerId:3, name:'IGRUA CPL',     fullForm:'IGRUA CPL Entrance',               conductingBody:'IGRUA',       examDate:'Twice a year',    regDate:'Jun & Dec',           frequency:'Twice a year', mode:'Both',     examType:'merit',      scoreLabel:'Merit + Interview (no fixed rank)', syllabus:['Mathematics: Algebra, Trigonometry','Physics: Mechanics, Fluid Dynamics, Meteorology','English Comprehension','General Aptitude'], prepTips:['Class 12 PCM mandatory','English proficiency critical','DGCA Class 1 Medical required','Strong spatial reasoning'], url:'https://igrua.gov.in', fee:3000 },
    { id:8,  careerId:4, name:'GRE',           fullForm:'Graduate Record Examinations',      conductingBody:'ETS',         examDate:'Year-round',      regDate:'2-3 months before',   frequency:'Year-round',   mode:'Online',   examType:'score', maxScore:340, scoreLabel:'GRE Score (out of 340)', syllabus:['Verbal Reasoning: Reading Comprehension, Text Completion','Quantitative Reasoning: Algebra, Data Analysis','Analytical Writing: Issue & Argument Essays'], prepTips:['Target 320+ for top US universities','Verbal score critical','6 months dedicated preparation','Manhattan Prep & Magoosh recommended'], url:'https://ets.org/gre', fee:19000 },
    { id:9,  careerId:4, name:'TOEFL',         fullForm:'Test of English as a Foreign Language',conductingBody:'ETS',      examDate:'Year-round',      regDate:'3+ months before',    frequency:'Year-round',   mode:'Online',   examType:'score', maxScore:120, scoreLabel:'TOEFL iBT Score (out of 120)', syllabus:['Reading: Academic passages','Listening: Lectures and conversations','Speaking: Independent and integrated','Writing: Integrated and independent essays'], prepTips:['Score 100+ iBT for top universities','Practice with official TOEFL material','Focus on academic vocabulary','Record yourself speaking'], url:'https://ets.org/toefl', fee:16900 },
    { id:10, careerId:5, name:'UPSC CSE',      fullForm:'Union Public Service Commission Civil Services',conductingBody:'UPSC',examDate:'Jun (Prelims), Sep (Mains)',regDate:'February',frequency:'Once a year',  mode:'Offline',  examType:'rank', scoreLabel:'UPSC CSE Rank (determines service/cadre, not an institute)', syllabus:['Prelims: GS Paper I (History, Polity, Economy, Geography) + CSAT','Mains: 9 Papers — Essay, GS I-IV, Optional Subject','Interview: Personality Test 275 Marks'], prepTips:['Average 4-5 attempts before clearing','Newspaper reading mandatory daily','Optional subject selection crucial','Join test series for Mains'], url:'https://upsc.gov.in', fee:100, feeWaiver:'Free for Women, SC/ST & PwD candidates' },
    { id:11, careerId:6, name:'CLAT',          fullForm:'Common Law Admission Test', conductingBody:'Consortium of NLUs', examDate:'December', regDate:'July-November', frequency:'Once a year', mode:'Offline', examType:'rank', scoreLabel:'CLAT All-India Rank', syllabus:['English Language & Comprehension','Legal Reasoning & Current Affairs','Logical Reasoning','Quantitative Techniques'], prepTips:['Daily newspaper reading for legal GK','Practice comprehension-based legal reasoning','Attempt full-length mocks weekly'], url:'https://consortiumofnlus.ac.in', fee:4000 },
    { id:12, careerId:6, name:'AILET',         fullForm:'All India Law Entrance Test', conductingBody:'NLU Delhi', examDate:'December', regDate:'August-November', frequency:'Once a year', mode:'Offline', examType:'rank', scoreLabel:'AILET Rank', syllabus:['English & Comprehension','General Knowledge & Current Affairs','Legal Aptitude','Reasoning & Mathematics'], prepTips:['Focus on NLU Delhi specific pattern','Solve previous 10 years papers'], url:'https://nludelhi.ac.in', fee:3500 },
    { id:13, careerId:7, name:'CAT',           fullForm:'Common Admission Test', conductingBody:'IIMs', examDate:'November', regDate:'August-September', frequency:'Once a year', mode:'Online', examType:'percentile', maxScore:100, scoreLabel:'CAT Percentile', syllabus:['Verbal Ability & Reading Comprehension','Data Interpretation & Logical Reasoning','Quantitative Ability'], prepTips:['Target 99+ percentile for IIM A/B/C calls','Sectional time management is critical','Take at least 15-20 full mocks'], url:'https://iimcat.ac.in', fee:2400, feeWaiver:'Reduced fee for SC/ST/PwD/NC-OBC/EWS/Female candidates' },
    { id:14, careerId:7, name:'XAT',           fullForm:'Xavier Aptitude Test', conductingBody:'XLRI Jamshedpur', examDate:'January', regDate:'August-December', frequency:'Once a year', mode:'Online', examType:'percentile', maxScore:100, scoreLabel:'XAT Percentile', syllabus:['Verbal & Logical Ability','Decision Making','Quantitative Ability & Data Interpretation','General Knowledge'], prepTips:['Decision Making section is unique — practice separately','Time-bound sectional practice essential'], url:'https://xatonline.in', fee:2100, feeWaiver:'Reduced fee for SC/ST/PwD candidates' },
    { id:15, careerId:8, name:'NDA',           fullForm:'National Defence Academy Examination', conductingBody:'UPSC', examDate:'April & September', regDate:'December & June', frequency:'Twice a year', mode:'Offline', examType:'rank', scoreLabel:'NDA Merit Rank (Written + SSB)', syllabus:['Mathematics: Class 11-12 level','General Ability Test: English + General Knowledge','SSB Interview: Psychological & Physical Tests'], prepTips:['Physical fitness prep alongside academics','SSB interview prep equally important','NCERT Maths + current affairs daily'], url:'https://upsc.gov.in', fee:100, feeWaiver:'Free for SC/ST candidates' },
    { id:16, careerId:8, name:'CDS',           fullForm:'Combined Defence Services Examination', conductingBody:'UPSC', examDate:'February & November', regDate:'October & July', frequency:'Twice a year', mode:'Offline', examType:'rank', scoreLabel:'CDS Merit Rank (Written + SSB)', syllabus:['English','General Knowledge','Elementary Mathematics','SSB Interview'], prepTips:['Graduates only — check exact eligibility per academy','Mock SSB group tasks if possible'], url:'https://upsc.gov.in', fee:200, feeWaiver:'Free for SC/ST & Female candidates' },
    // State-level engineering entrance exams (careerId 1)
    { id:17, careerId:1, name:'TS EAMCET',     fullForm:'Telangana State Engineering, Agriculture & Medical Common Entrance Test', conductingBody:'TSCHE / JNTU Hyderabad', examDate:'May', regDate:'February-April', frequency:'Once a year', mode:'Online', examType:'rank', scoreLabel:'TS EAMCET Rank', syllabus:['Physics & Chemistry: Telangana Intermediate syllabus','Mathematics: Telangana Intermediate syllabus'], prepTips:['Intermediate (Class 12) board syllabus is the exact syllabus','Practice previous year TS EAMCET papers','Local/regional candidature rules affect seat allotment'], url:'https://eamcet.tsche.ac.in', fee:900 },
    { id:18, careerId:1, name:'AP EAMCET',     fullForm:'Andhra Pradesh Engineering, Agriculture & Medical Common Entrance Test', conductingBody:'APSCHE / JNTU Kakinada', examDate:'May', regDate:'February-April', frequency:'Once a year', mode:'Online', examType:'rank', scoreLabel:'AP EAMCET Rank', syllabus:['Physics & Chemistry: AP Intermediate syllabus','Mathematics: AP Intermediate syllabus'], prepTips:['Intermediate (Class 12) board syllabus is the exact syllabus','Practice previous year AP EAMCET papers','Check local-area reservation rules for seat allotment'], url:'https://cets.apsche.ap.gov.in', fee:900 },
    { id:19, careerId:1, name:'KCET',          fullForm:'Karnataka Common Entrance Test', conductingBody:'KEA (Karnataka Examinations Authority)', examDate:'April', regDate:'January-March', frequency:'Once a year', mode:'Offline', examType:'rank', scoreLabel:'KCET Rank', syllabus:['Physics, Chemistry, Mathematics: Karnataka PUC syllabus'], prepTips:['PUC (Class 12) textbooks are the primary source','Only Karnataka domicile/local candidates get state quota seats','Practice previous year KCET papers'], url:'https://kea.kar.nic.in', fee:650 },
    { id:20, careerId:1, name:'MHT CET',       fullForm:'Maharashtra Common Entrance Test', conductingBody:'State CET Cell, Maharashtra', examDate:'April-May', regDate:'February-March', frequency:'Once a year', mode:'Online', examType:'percentile', maxScore:100, scoreLabel:'MHT CET Percentile', syllabus:['Physics, Chemistry, Mathematics: Maharashtra HSC syllabus'], prepTips:['HSC board syllabus overlaps heavily','Practice previous year CET papers','Home-university/regional quota affects allotment'], url:'https://cetcell.mahacet.org', fee:1000 },
    { id:21, careerId:1, name:'WBJEE',         fullForm:'West Bengal Joint Entrance Examination', conductingBody:'WBJEEB', examDate:'April', regDate:'December-February', frequency:'Once a year', mode:'Offline', examType:'rank', scoreLabel:'WBJEE Rank', syllabus:['Physics, Chemistry, Mathematics: WB Higher Secondary syllabus'], prepTips:['WB Higher Secondary textbooks are the core source','Practice previous year WBJEE papers'], url:'https://wbjeeb.nic.in', fee:500 },
    { id:22, careerId:1, name:'COMEDK UGET',   fullForm:'Consortium of Medical, Engineering and Dental Colleges of Karnataka - Undergraduate Entrance Test', conductingBody:'COMEDK', examDate:'May', regDate:'March-April', frequency:'Once a year', mode:'Online', examType:'rank', scoreLabel:'COMEDK Rank', syllabus:['Physics, Chemistry, Mathematics: Class 11-12 (CBSE/State Board level)'], prepTips:['Covers private engineering colleges in Karnataka','Practice previous year COMEDK papers'], url:'https://comedk.org', fee:2000 },
    { id:23, careerId:9, name:'NIFT Entrance Exam', fullForm:'National Institute of Fashion Technology Entrance Examination', conductingBody:'NIFT', examDate:'January (GAT/CAT)', regDate:'October-December', frequency:'Once a year', mode:'Offline', examType:'rank', scoreLabel:'NIFT All-India Rank', syllabus:['General Ability Test (GAT): English, Quantitative, GK, Communication','Creative Ability Test (CAT): Sketching, Design Aptitude, Colour Sense','Situation Test (for B.Des shortlisted candidates): Model-making, Material Handling'], prepTips:['Practice sketching daily — hand control and proportion matter','Stay updated on fashion trends & pop culture for GK section','Build a portfolio ahead of the Situation Test round'], url:'https://nift.ac.in', fee:2000 },
    { id:24, careerId:10, name:'GATE', fullForm:'Graduate Aptitude Test in Engineering', conductingBody:'IITs (rotating basis)', examDate:'February', regDate:'August-October', frequency:'Once a year', mode:'Online', examType:'score', maxScore:100, scoreLabel:'GATE Score / All-India Rank', syllabus:['Engineering Mathematics','Core subject paper (CS/ECE/Mech/Civil/EEE etc.)','General Aptitude'], prepTips:['Target top 2000 AIR for IIT/NIT M.Tech admission or PSU shortlists','Solve previous 10-15 years GATE papers','Standard reference: Made Easy / GATE Academy material','GATE score is also used directly by many PSUs for recruitment'], url:'https://gate.iitk.ac.in', fee:1900, feeWaiver:'Reduced fee for Women/SC/ST/PwD candidates' }
  ],
  colleges: [
    // Engineering (careerId 1)
    { id:1,  careerId:1, name:'IIT Bombay',          location:'Mumbai, Maharashtra',        rank:1,    tuition:220000,  hostel:120000, exam:2000,  other:30000,  total4yr:1488000,  seats:880,  acceptance:0.5,  cutoffs:[{examId:2, value:250,  label:'JEE Advanced Rank (Gen, CRL)'}] },
    { id:2,  careerId:1, name:'IIT Delhi',            location:'New Delhi',                  rank:2,    tuition:210000,  hostel:115000, exam:2000,  other:28000,  total4yr:1420000,  seats:850,  acceptance:0.6,  cutoffs:[{examId:2, value:400,  label:'JEE Advanced Rank (Gen, CRL)'}] },
    { id:3,  careerId:1, name:'IIT Madras',           location:'Chennai, Tamil Nadu',        rank:3,    tuition:215000,  hostel:110000, exam:2000,  other:28000,  total4yr:1452000,  seats:900,  acceptance:0.6,  cutoffs:[{examId:2, value:600,  label:'JEE Advanced Rank (Gen, CRL)'}] },
    { id:4,  careerId:1, name:'IIT Kanpur',           location:'Kanpur, Uttar Pradesh',      rank:4,    tuition:215000,  hostel:110000, exam:2000,  other:28000,  total4yr:1452000,  seats:900,  acceptance:0.7,  cutoffs:[{examId:2, value:900,  label:'JEE Advanced Rank (Gen, CRL)'}] },
    { id:5,  careerId:1, name:'IIT Kharagpur',        location:'Kharagpur, West Bengal',     rank:5,    tuition:210000,  hostel:105000, exam:2000,  other:28000,  total4yr:1412000,  seats:1900, acceptance:0.9,  cutoffs:[{examId:2, value:1500, label:'JEE Advanced Rank (Gen, CRL)'}] },
    { id:6,  careerId:1, name:'NIT Trichy',           location:'Tiruchirappalli, Tamil Nadu', rank:8,    tuition:150000,  hostel:90000,  exam:1500,  other:20000,  total4yr:1046000,  seats:1200, acceptance:2.1,  cutoffs:[{examId:1, value:6000,  label:'JEE Main Rank (Gen, Home State)'}] },
    { id:7,  careerId:1, name:'NIT Surathkal',        location:'Surathkal, Karnataka',       rank:11,   tuition:145000,  hostel:85000,  exam:1500,  other:20000,  total4yr:1006000,  seats:1100, acceptance:2.4,  cutoffs:[{examId:1, value:9000,  label:'JEE Main Rank (Gen, Home State)'}] },
    { id:8,  careerId:1, name:'NIT Warangal',         location:'Warangal, Telangana',        rank:9,    tuition:145000,  hostel:85000,  exam:1500,  other:20000,  total4yr:1006000,  seats:1150, acceptance:2.2,  cutoffs:[{examId:1, value:8000,  label:'JEE Main Rank (Gen, Home State)'}] },
    { id:9,  careerId:1, name:'BITS Pilani',          location:'Pilani, Rajasthan',          rank:26,   tuition:450000,  hostel:180000, exam:3000,  other:50000,  total4yr:2732000,  seats:600,  acceptance:3.0,  branches:['CSE','AI','ECE','EEE','Mechanical'], cutoffs:[{examId:3, value:320,  label:'BITSAT Score (CSE cutoff, approx)'}] },
    { id:10, careerId:1, name:'VIT Vellore',          location:'Vellore, Tamil Nadu',        rank:14,   tuition:220000,  hostel:120000, exam:1500,  other:30000,  total4yr:1420000,  seats:2000, acceptance:8.0,  cutoffs:[{examId:4, value:15000, label:'VITEEE Rank (CSE cutoff, approx)'}] },
    { id:11, careerId:1, name:'SRM Institute Chennai',location:'Chennai, Tamil Nadu',        rank:29,   tuition:245000,  hostel:110000, exam:1200,  other:25000,  total4yr:1505000,  seats:1800, acceptance:12.0, cutoffs:[{examId:5, value:20000, label:'SRMJEEE Rank (CSE cutoff, approx)'}] },
    // Medical (careerId 2)
    { id:12, careerId:2, name:'AIIMS New Delhi',      location:'New Delhi',                  rank:1,    tuition:5000,    hostel:24000,  exam:1700,  other:15000,  total4yr:227000,   seats:100,  acceptance:0.03, cutoffs:[{examId:6, value:60,   label:'NEET UG AIR (Gen, approx)'}] },
    { id:13, careerId:2, name:'JIPMER Puducherry',    location:'Puducherry',                 rank:4,    tuition:25000,   hostel:20000,  exam:1500,  other:15000,  total4yr:220000,   seats:150,  acceptance:0.2,  cutoffs:[{examId:6, value:400,  label:'NEET UG AIR (Gen, approx)'}] },
    { id:14, careerId:2, name:'Maulana Azad Medical College', location:'New Delhi',           rank:6,    tuition:15000,   hostel:20000,  exam:1500,  other:15000,  total4yr:210000,   seats:250,  acceptance:0.3,  cutoffs:[{examId:6, value:800,  label:'NEET UG AIR (Gen, approx)'}] },
    { id:15, careerId:2, name:'CMC Vellore',          location:'Vellore, Tamil Nadu',        rank:2,    tuition:120000,  hostel:60000,  exam:2000,  other:25000,  total4yr:935000,   seats:60,   acceptance:0.2,  cutoffs:[{examId:6, value:1500, label:'NEET UG AIR (merit + interview, approx)'}] },
    { id:16, careerId:2, name:'Grant Government Medical College Mumbai', location:'Mumbai, Maharashtra', rank:12, tuition:20000, hostel:25000, exam:1500, other:15000, total4yr:220000, seats:200,  acceptance:1.0,  cutoffs:[{examId:6, value:4000,  label:'NEET UG AIR (Gen, Home State, approx)'}] },
    { id:17, careerId:2, name:'Kasturba Medical Manipal', location:'Manipal, Karnataka',      rank:10,   tuition:1200000, hostel:180000, exam:3000,  other:40000,  total4yr:7115000,  seats:250,  acceptance:6.0,  cutoffs:[{examId:6, value:30000, label:'NEET UG AIR (management quota, approx)'}] },
    // Pilot (careerId 3) — merit/interview based, no fixed rank cutoff
    { id:18, careerId:3, name:'IGRUA',                location:'Rae Bareli, UP',             rank:null, tuition:3500000, hostel:200000, exam:5000,  other:80000,  total4yr:14340000, seats:50,   acceptance:5.0,  cutoffs:[] },
    { id:19, careerId:3, name:'Indigo Cadet Program', location:'Pan India',                  rank:null, tuition:6000000, hostel:300000, exam:10000, other:100000, total4yr:24440000, seats:30,   acceptance:2.0,  cutoffs:[] },
    // Abroad MS (careerId 4) — score/GPA based
    { id:20, careerId:4, name:'MIT',                  location:'Cambridge, USA',             rank:1,    tuition:4900000, hostel:0,      exam:0,     other:0,      total4yr:9800000,  seats:150,  acceptance:3.9,  cutoffs:[{examId:8, value:325, label:'GRE Score (typical admit, approx)'}] },
    { id:21, careerId:4, name:'Stanford University',  location:'California, USA',            rank:2,    tuition:4700000, hostel:0,      exam:0,     other:0,      total4yr:9400000,  seats:120,  acceptance:4.3,  cutoffs:[{examId:8, value:322, label:'GRE Score (typical admit, approx)'}] },
    { id:22, careerId:4, name:'Univ of Toronto',      location:'Ontario, Canada',            rank:21,   tuition:3200000, hostel:0,      exam:0,     other:0,      total4yr:6400000,  seats:200,  acceptance:35.0, cutoffs:[{examId:8, value:310, label:'GRE Score (typical admit, approx)'}] },
    // Civil Services (careerId 5) — rank determines cadre, not institute choice
    { id:23, careerId:5, name:'LBSNAA',               location:'Mussoorie, Uttarakhand',     rank:null, tuition:0,       hostel:0,      exam:0,     other:0,      total4yr:0,        seats:180,  acceptance:0.1,  cutoffs:[] },
    // Law (careerId 6)
    { id:24, careerId:6, name:'NLSIU Bangalore',      location:'Bengaluru, Karnataka',       rank:1,    tuition:290000,  hostel:110000, exam:2000,  other:25000,  total4yr:2135000,  seats:80,   acceptance:0.5,  cutoffs:[{examId:11, value:60,   label:'CLAT AIR (approx)'}] },
    { id:25, careerId:6, name:'NALSAR Hyderabad',     location:'Hyderabad, Telangana',       rank:2,    tuition:260000,  hostel:100000, exam:2000,  other:25000,  total4yr:1940000,  seats:80,   acceptance:0.6,  cutoffs:[{examId:11, value:150,  label:'CLAT AIR (approx)'}] },
    { id:26, careerId:6, name:'NLU Delhi',            location:'New Delhi',                  rank:3,    tuition:250000,  hostel:95000,  exam:2000,  other:25000,  total4yr:1860000,  seats:80,   acceptance:0.6,  cutoffs:[{examId:12, value:100,  label:'AILET Rank (approx)'}] },
    { id:27, careerId:6, name:'NLU Jodhpur',          location:'Jodhpur, Rajasthan',        rank:4,    tuition:240000,  hostel:90000,  exam:2000,  other:25000,  total4yr:1780000,  seats:80,   acceptance:0.8,  cutoffs:[{examId:11, value:400,  label:'CLAT AIR (approx)'}] },
    { id:28, careerId:6, name:'Symbiosis Law School Pune', location:'Pune, Maharashtra',      rank:9,    tuition:350000,  hostel:150000, exam:2500,  other:30000,  total4yr:2620000,  seats:180,  acceptance:5.0,  cutoffs:[{examId:11, value:2500, label:'CLAT AIR (approx, illustrative only — SLS Pune primarily uses SLAT)'}] },
    // Management (careerId 7)
    { id:29, careerId:7, name:'IIM Ahmedabad',        location:'Ahmedabad, Gujarat',         rank:1,    tuition:2500000, hostel:150000, exam:2000,  other:30000,  total4yr:2680000,  seats:400,  acceptance:0.3,  cutoffs:[{examId:13, value:99.5, label:'CAT Percentile (approx)'}] },
    { id:30, careerId:7, name:'IIM Bangalore',        location:'Bengaluru, Karnataka',       rank:2,    tuition:2400000, hostel:140000, exam:2000,  other:30000,  total4yr:2570000,  seats:480,  acceptance:0.4,  cutoffs:[{examId:13, value:99.3, label:'CAT Percentile (approx)'}] },
    { id:31, careerId:7, name:'IIM Calcutta',         location:'Kolkata, West Bengal',       rank:3,    tuition:2450000, hostel:145000, exam:2000,  other:30000,  total4yr:2625000,  seats:480,  acceptance:0.4,  cutoffs:[{examId:13, value:99.3, label:'CAT Percentile (approx)'}] },
    { id:32, careerId:7, name:'FMS Delhi',            location:'New Delhi',                  rank:6,    tuition:25000,   hostel:40000,  exam:1500,  other:20000,  total4yr:130000,   seats:220,  acceptance:0.1,  cutoffs:[{examId:13, value:98.5, label:'CAT Percentile (approx)'}] },
    { id:33, careerId:7, name:'XLRI Jamshedpur',      location:'Jamshedpur, Jharkhand',      rank:8,    tuition:2400000, hostel:120000, exam:2000,  other:25000,  total4yr:2545000,  seats:360,  acceptance:1.0,  cutoffs:[{examId:14, value:96,   label:'XAT Percentile (approx)'}] },
    { id:34, careerId:7, name:'SPJIMR Mumbai',        location:'Mumbai, Maharashtra',        rank:11,   tuition:2350000, hostel:100000, exam:2000,  other:25000,  total4yr:2475000,  seats:240,  acceptance:1.5,  cutoffs:[{examId:13, value:90,   label:'CAT Percentile (approx)'}] },
    // Defence (careerId 8) — merit list (written + SSB), not fixed cutoff rank
    { id:35, careerId:8, name:'National Defence Academy, Khadakwasla', location:'Pune, Maharashtra', rank:null, tuition:0, hostel:0, exam:0, other:15000, total4yr:60000, seats:370, acceptance:1.0, cutoffs:[{examId:15, value:300, label:'NDA Merit Rank (Written+SSB, approx)'}] },
    { id:36, careerId:8, name:'Indian Military Academy, Dehradun',     location:'Dehradun, Uttarakhand', rank:null, tuition:0, hostel:0, exam:0, other:15000, total4yr:60000, seats:250, acceptance:1.5, cutoffs:[{examId:16, value:250, label:'CDS Merit Rank (Written+SSB, approx)'}] },
    // State-level engineering colleges (careerId 1)
    { id:37, careerId:1, name:'JNTU Hyderabad (JNTUH College of Engineering)', location:'Hyderabad, Telangana', rank:32,  tuition:60000,  hostel:45000, exam:1200, other:15000, total4yr:361000,  seats:540,  acceptance:8.0,  cutoffs:[{examId:17, value:3000,  label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:38, careerId:1, name:'Osmania University College of Engineering', location:'Hyderabad, Telangana', rank:45,  tuition:55000,  hostel:40000, exam:1200, other:15000, total4yr:336000,  seats:480,  acceptance:9.0,  cutoffs:[{examId:17, value:6000,  label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:39, careerId:1, name:'CBIT Hyderabad',           location:'Hyderabad, Telangana',       rank:null, tuition:110000, hostel:80000, exam:1200, other:20000, total4yr:596000,  seats:600,  acceptance:15.0, cutoffs:[{examId:17, value:12000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:40, careerId:1, name:'JNTU Kakinada',            location:'Kakinada, Andhra Pradesh',   rank:60,  tuition:55000,  hostel:40000, exam:1200, other:15000, total4yr:336000,  seats:480,  acceptance:9.0,  cutoffs:[{examId:18, value:5000,  label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:41, careerId:1, name:'Andhra University College of Engineering', location:'Visakhapatnam, Andhra Pradesh', rank:52, tuition:50000, hostel:35000, exam:1200, other:15000, total4yr:306000, seats:420, acceptance:8.5, cutoffs:[{examId:18, value:4000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:42, careerId:1, name:'RV College of Engineering', location:'Bengaluru, Karnataka',       rank:22,  tuition:230000, hostel:120000, exam:1500, other:25000, total4yr:1460000, seats:400,  acceptance:6.0,  cutoffs:[{examId:19, value:1500, label:'KCET Rank (Gen, CSE, approx)'},{examId:22, value:3000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    { id:43, careerId:1, name:'BMS College of Engineering', location:'Bengaluru, Karnataka',      rank:35,  tuition:220000, hostel:110000, exam:1500, other:25000, total4yr:1400000, seats:400,  acceptance:7.0,  cutoffs:[{examId:19, value:2500, label:'KCET Rank (Gen, CSE, approx)'},{examId:22, value:5000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    { id:44, careerId:1, name:'PES University',           location:'Bengaluru, Karnataka',       rank:66,  tuition:400000, hostel:150000, exam:1500, other:30000, total4yr:2420000, seats:360,  acceptance:12.0, cutoffs:[{examId:22, value:8000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    { id:45, careerId:1, name:'College of Engineering Pune (COEP)', location:'Pune, Maharashtra', rank:88,  tuition:90000,  hostel:50000, exam:1200, other:15000, total4yr:466000,  seats:400,  acceptance:5.0,  cutoffs:[{examId:20, value:99.5, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:46, careerId:1, name:'VJTI Mumbai',              location:'Mumbai, Maharashtra',        rank:70,  tuition:95000,  hostel:55000, exam:1200, other:15000, total4yr:496000,  seats:400,  acceptance:5.5,  cutoffs:[{examId:20, value:99.4, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:47, careerId:1, name:'Jadavpur University',      location:'Kolkata, West Bengal',       rank:18,  tuition:15000,  hostel:20000, exam:1000, other:10000, total4yr:180000,  seats:500,  acceptance:3.0,  cutoffs:[{examId:21, value:500,  label:'WBJEE Rank (Gen, CSE, approx)'}] },
    { id:48, careerId:1, name:'IIEST Shibpur',            location:'Howrah, West Bengal',        rank:55,  tuition:100000, hostel:60000, exam:1200, other:15000, total4yr:640000,  seats:450,  acceptance:5.0,  cutoffs:[{examId:21, value:1200, label:'WBJEE Rank (Gen, CSE, approx)'}] },
    // Local / regional engineering colleges — Warangal, Telangana (TS EAMCET)
    { id:49, careerId:1, name:'Kakatiya Institute of Technology & Science (KITS), Warangal', location:'Warangal, Telangana', rank:null, tuition:75000, hostel:45000, exam:1000, other:12000, total4yr:428000, seats:360, acceptance:35.0, cutoffs:[{examId:17, value:25000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:50, careerId:1, name:'Kakatiya University College of Engineering & Technology, Warangal', location:'Warangal, Telangana', rank:null, tuition:20000, hostel:25000, exam:800, other:10000, total4yr:143000, seats:240, acceptance:30.0, cutoffs:[{examId:17, value:30000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:51, careerId:1, name:'SR University (SRU), Warangal', location:'Warangal, Telangana', rank:null, tuition:85000, hostel:50000, exam:1000, other:12000, total4yr:468000, seats:600, acceptance:45.0, cutoffs:[{examId:17, value:60000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:52, careerId:1, name:'SVS Group of Institutions, Warangal', location:'Warangal, Telangana', rank:null, tuition:65000, hostel:40000, exam:1000, other:10000, total4yr:340000, seats:480, acceptance:60.0, branches:['CSE','ECE','Mechanical'], cutoffs:[{examId:17, value:90000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:53, careerId:1, name:'Sumathi Reddy Institute of Technology for Women (SRITW), Warangal', location:'Warangal, Telangana', rank:null, tuition:60000, hostel:38000, exam:1000, other:10000, total4yr:316000, seats:300, acceptance:65.0, branches:['CSE','IT','ECE'], womenOnly:true, cutoffs:[{examId:17, value:100000, label:'TS EAMCET Rank (Gen, CSE, approx), Women only college'}] },
    { id:54, careerId:1, name:'Vaagdevi College of Engineering, Warangal', location:'Warangal, Telangana', rank:null, tuition:65000, hostel:38000, exam:1000, other:10000, total4yr:340000, seats:420, acceptance:60.0, branches:['CSE','AI','ECE','EEE','Mechanical'], cutoffs:[{examId:17, value:95000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:55, careerId:1, name:'Balaji Institute of Technology & Science, Warangal', location:'Warangal, Telangana', rank:null, tuition:60000, hostel:35000, exam:1000, other:10000, total4yr:314000, seats:300, acceptance:70.0, branches:['CSE','ECE','Mechanical'], cutoffs:[{examId:17, value:110000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:56, careerId:1, name:'Warangal Institute of Technology & Science (WITS), Warangal', location:'Warangal, Telangana', rank:null, tuition:65000, hostel:38000, exam:1000, other:10000, total4yr:340000, seats:360, acceptance:65.0, branches:['CSE','ECE','EEE'], cutoffs:[{examId:17, value:105000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    // More Telangana engineering colleges (TS EAMCET) — Hyderabad region
    { id:57, careerId:1, name:'Vasavi College of Engineering, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:70000, hostel:45000, exam:1000, other:12000, total4yr:400000, seats:360, acceptance:20.0, cutoffs:[{examId:17, value:8000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:58, careerId:1, name:'VNR Vignana Jyothi Institute of Engineering & Technology, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:75000, hostel:45000, exam:1000, other:12000, total4yr:428000, seats:420, acceptance:22.0, cutoffs:[{examId:17, value:10000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:59, careerId:1, name:'Gokaraju Rangaraju Institute of Engineering & Technology (GRIET), Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:75000, hostel:45000, exam:1000, other:12000, total4yr:428000, seats:360, acceptance:25.0, cutoffs:[{examId:17, value:15000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:60, careerId:1, name:'Mahatma Gandhi Institute of Technology (MGIT), Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:75000, hostel:45000, exam:1000, other:12000, total4yr:428000, seats:360, acceptance:28.0, cutoffs:[{examId:17, value:18000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:61, careerId:1, name:'Sreenidhi Institute of Science & Technology (SNIST), Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:70000, hostel:42000, exam:1000, other:12000, total4yr:400000, seats:360, acceptance:30.0, cutoffs:[{examId:17, value:20000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:62, careerId:1, name:'MVSR Engineering College, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:65000, hostel:40000, exam:1000, other:10000, total4yr:352000, seats:300, acceptance:38.0, cutoffs:[{examId:17, value:22000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:63, careerId:1, name:'Anurag University (Anurag Group), Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:80000, hostel:48000, exam:1000, other:12000, total4yr:452000, seats:420, acceptance:40.0, cutoffs:[{examId:17, value:25000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:64, careerId:1, name:'Vardhaman College of Engineering, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:70000, hostel:42000, exam:1000, other:10000, total4yr:392000, seats:360, acceptance:45.0, branches:['CSE','IT','ECE','EEE','Mechanical'], cutoffs:[{examId:17, value:35000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:65, careerId:1, name:'Geethanjali College of Engineering & Technology, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:70000, hostel:42000, exam:1000, other:10000, total4yr:392000, seats:360, acceptance:48.0, branches:['CSE','IT','ECE','Mechanical'], cutoffs:[{examId:17, value:30000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:66, careerId:1, name:"St. Martin's Engineering College, Secunderabad", location:'Secunderabad, Telangana', rank:null, tuition:65000, hostel:40000, exam:1000, other:10000, total4yr:352000, seats:360, acceptance:55.0, branches:['CSE','AI','ECE','EEE','Mechanical'], cutoffs:[{examId:17, value:40000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    { id:67, careerId:1, name:'Malla Reddy Engineering College, Hyderabad', location:'Hyderabad, Telangana', rank:null, tuition:60000, hostel:38000, exam:1000, other:10000, total4yr:324000, seats:480, acceptance:58.0, cutoffs:[{examId:17, value:45000, label:'TS EAMCET Rank (Gen, CSE, approx)'}] },
    // Andhra Pradesh engineering colleges (AP EAMCET)
    { id:68, careerId:1, name:'V R Siddhartha Engineering College, Vijayawada', location:'Vijayawada, Andhra Pradesh', rank:null, tuition:60000, hostel:40000, exam:1000, other:10000, total4yr:324000, seats:420, acceptance:20.0, cutoffs:[{examId:18, value:12000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:69, careerId:1, name:'Gayatri Vidya Parishad College of Engineering (GVPCE), Visakhapatnam', location:'Visakhapatnam, Andhra Pradesh', rank:null, tuition:60000, hostel:38000, exam:1000, other:10000, total4yr:316000, seats:360, acceptance:22.0, cutoffs:[{examId:18, value:15000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:70, careerId:1, name:'Prasad V Potluri Siddhartha Institute of Technology (PVPSIT), Vijayawada', location:'Vijayawada, Andhra Pradesh', rank:null, tuition:60000, hostel:38000, exam:1000, other:10000, total4yr:316000, seats:300, acceptance:25.0, cutoffs:[{examId:18, value:16000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:71, careerId:1, name:'Sagi Rama Krishnam Raju Engineering College (SRKR), Bhimavaram', location:'Bhimavaram, Andhra Pradesh', rank:null, tuition:55000, hostel:35000, exam:1000, other:10000, total4yr:300000, seats:300, acceptance:28.0, cutoffs:[{examId:18, value:18000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:72, careerId:1, name:'Vishnu Institute of Technology, Bhimavaram', location:'Bhimavaram, Andhra Pradesh', rank:null, tuition:55000, hostel:35000, exam:1000, other:10000, total4yr:300000, seats:300, acceptance:30.0, cutoffs:[{examId:18, value:20000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:73, careerId:1, name:'Vasireddy Venkatadri Institute of Technology (VVIT), Guntur', location:'Guntur, Andhra Pradesh', rank:null, tuition:55000, hostel:35000, exam:1000, other:10000, total4yr:300000, seats:300, acceptance:35.0, cutoffs:[{examId:18, value:30000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:74, careerId:1, name:'Lakireddy Bali Reddy College of Engineering (LBRCE), Mylavaram', location:'Mylavaram, Andhra Pradesh', rank:null, tuition:55000, hostel:35000, exam:1000, other:10000, total4yr:300000, seats:300, acceptance:38.0, cutoffs:[{examId:18, value:22000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    { id:75, careerId:1, name:'Aditya Engineering College, Surampalem', location:'Surampalem, Andhra Pradesh', rank:null, tuition:50000, hostel:32000, exam:1000, other:10000, total4yr:282000, seats:300, acceptance:42.0, cutoffs:[{examId:18, value:25000, label:'AP EAMCET Rank (Gen, CSE, approx)'}] },
    // Karnataka engineering colleges (KCET / COMEDK)
    { id:76, careerId:1, name:'M S Ramaiah Institute of Technology (MSRIT), Bengaluru', location:'Bengaluru, Karnataka', rank:26, tuition:220000, hostel:110000, exam:1500, other:25000, total4yr:1400000, seats:420, acceptance:8.0, cutoffs:[{examId:19, value:3500, label:'KCET Rank (Gen, CSE, approx)'},{examId:22, value:6000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    { id:77, careerId:1, name:'Dayananda Sagar College of Engineering (DSCE), Bengaluru', location:'Bengaluru, Karnataka', rank:44, tuition:210000, hostel:100000, exam:1500, other:25000, total4yr:1340000, seats:420, acceptance:12.0, cutoffs:[{examId:19, value:6000, label:'KCET Rank (Gen, CSE, approx)'},{examId:22, value:10000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    { id:78, careerId:1, name:'BMS Institute of Technology, Bengaluru', location:'Bengaluru, Karnataka', rank:null, tuition:190000, hostel:95000, exam:1500, other:20000, total4yr:1220000, seats:360, acceptance:18.0, cutoffs:[{examId:19, value:9000, label:'KCET Rank (Gen, CSE, approx)'}] },
    { id:79, careerId:1, name:'Bangalore Institute of Technology (BIT), Bengaluru', location:'Bengaluru, Karnataka', rank:null, tuition:190000, hostel:95000, exam:1500, other:20000, total4yr:1220000, seats:360, acceptance:22.0, cutoffs:[{examId:19, value:12000, label:'KCET Rank (Gen, CSE, approx)'}] },
    { id:80, careerId:1, name:'Nitte Meenakshi Institute of Technology (NMIT), Bengaluru', location:'Bengaluru, Karnataka', rank:null, tuition:200000, hostel:100000, exam:1500, other:20000, total4yr:1280000, seats:360, acceptance:20.0, cutoffs:[{examId:19, value:10000, label:'KCET Rank (Gen, CSE, approx)'}] },
    { id:81, careerId:1, name:'Sir M Visvesvaraya Institute of Technology (SMVIT), Bengaluru', location:'Bengaluru, Karnataka', rank:null, tuition:190000, hostel:90000, exam:1500, other:20000, total4yr:1200000, seats:300, acceptance:25.0, cutoffs:[{examId:19, value:15000, label:'KCET Rank (Gen, CSE, approx)'}] },
    { id:82, careerId:1, name:'New Horizon College of Engineering, Bengaluru', location:'Bengaluru, Karnataka', rank:null, tuition:180000, hostel:90000, exam:1500, other:20000, total4yr:1160000, seats:420, acceptance:35.0, cutoffs:[{examId:19, value:25000, label:'KCET Rank (Gen, CSE, approx)'},{examId:22, value:30000, label:'COMEDK Rank (Gen, CSE, approx)'}] },
    // Maharashtra engineering colleges (MHT CET)
    { id:83, careerId:1, name:'Pune Institute of Computer Technology (PICT), Pune', location:'Pune, Maharashtra', rank:null, tuition:100000, hostel:55000, exam:1200, other:15000, total4yr:540000, seats:360, acceptance:8.0, cutoffs:[{examId:20, value:99.1, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:84, careerId:1, name:'Vishwakarma Institute of Technology (VIT Pune), Pune', location:'Pune, Maharashtra', rank:null, tuition:95000, hostel:50000, exam:1200, other:15000, total4yr:510000, seats:360, acceptance:12.0, cutoffs:[{examId:20, value:98.5, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:85, careerId:1, name:'Sardar Patel College of Engineering (SPCE), Mumbai', location:'Mumbai, Maharashtra', rank:null, tuition:90000, hostel:50000, exam:1200, other:15000, total4yr:490000, seats:240, acceptance:10.0, cutoffs:[{examId:20, value:98.8, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:86, careerId:1, name:'K J Somaiya College of Engineering, Mumbai', location:'Mumbai, Maharashtra', rank:null, tuition:150000, hostel:60000, exam:1200, other:20000, total4yr:860000, seats:360, acceptance:15.0, cutoffs:[{examId:20, value:98.6, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:87, careerId:1, name:'Walchand College of Engineering, Sangli', location:'Sangli, Maharashtra', rank:null, tuition:80000, hostel:42000, exam:1000, other:12000, total4yr:456000, seats:300, acceptance:20.0, cutoffs:[{examId:20, value:97.5, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    { id:88, careerId:1, name:'Government College of Engineering, Aurangabad', location:'Aurangabad (Chhatrapati Sambhajinagar), Maharashtra', rank:null, tuition:30000, hostel:25000, exam:1000, other:10000, total4yr:200000, seats:300, acceptance:25.0, cutoffs:[{examId:20, value:96.5, label:'MHT CET Percentile (Gen, CSE, approx)'}] },
    // West Bengal engineering colleges (WBJEE)
    { id:89, careerId:1, name:'Kalyani Government Engineering College', location:'Kalyani, West Bengal', rank:null, tuition:20000, hostel:20000, exam:1000, other:10000, total4yr:180000, seats:300, acceptance:20.0, cutoffs:[{examId:21, value:5000, label:'WBJEE Rank (Gen, CSE, approx)'}] },
    { id:90, careerId:1, name:'Heritage Institute of Technology, Kolkata', location:'Kolkata, West Bengal', rank:null, tuition:110000, hostel:60000, exam:1200, other:15000, total4yr:640000, seats:360, acceptance:35.0, cutoffs:[{examId:21, value:15000, label:'WBJEE Rank (Gen, CSE, approx)'}] },
    { id:91, careerId:1, name:'Techno India, Kolkata', location:'Kolkata, West Bengal', rank:null, tuition:95000, hostel:50000, exam:1200, other:12000, total4yr:552000, seats:420, acceptance:45.0, cutoffs:[{examId:21, value:20000, label:'WBJEE Rank (Gen, CSE, approx)'}] },
    { id:92, careerId:1, name:'MCKV Institute of Engineering, Howrah', location:'Howrah, West Bengal', rank:null, tuition:85000, hostel:45000, exam:1200, other:12000, total4yr:492000, seats:300, acceptance:50.0, branches:['CSE','IT','ECE','Mechanical'], cutoffs:[{examId:21, value:12000, label:'WBJEE Rank (Gen, CSE, approx)'}] },
    // Fashion Designing (careerId 9) — NIFT campuses
    { id:93, careerId:9, name:'NIFT Delhi',      location:'New Delhi',               rank:1,  tuition:280000, hostel:90000, exam:2000, other:20000, total4yr:1568000, seats:100, acceptance:2.0, cutoffs:[{examId:23, value:200,  label:'NIFT AIR (Gen, approx)'}] },
    { id:94, careerId:9, name:'NIFT Mumbai',     location:'Mumbai, Maharashtra',      rank:2,  tuition:280000, hostel:95000, exam:2000, other:20000, total4yr:1588000, seats:100, acceptance:2.2, cutoffs:[{examId:23, value:400,  label:'NIFT AIR (Gen, approx)'}] },
    { id:95, careerId:9, name:'NIFT Hyderabad',  location:'Hyderabad, Telangana',     rank:4,  tuition:260000, hostel:85000, exam:2000, other:20000, total4yr:1460000, seats:100, acceptance:3.0, cutoffs:[{examId:23, value:900,  label:'NIFT AIR (Gen, approx)'}] },
    { id:96, careerId:9, name:'NIFT Bengaluru',  location:'Bengaluru, Karnataka',     rank:5,  tuition:260000, hostel:85000, exam:2000, other:20000, total4yr:1460000, seats:100, acceptance:3.2, cutoffs:[{examId:23, value:1000, label:'NIFT AIR (Gen, approx)'}] },
    { id:97, careerId:9, name:'Pearl Academy, Delhi', location:'New Delhi', rank:null, tuition:400000, hostel:120000, exam:1500, other:25000, total4yr:2180000, seats:180, acceptance:20.0, cutoffs:[] },
    // M.Tech (careerId 10) — GATE score/AIR based
    { id:98, careerId:10, name:'IIT Bombay (M.Tech)',    location:'Mumbai, Maharashtra', rank:1, tuition:100000, hostel:60000, exam:1800, other:15000, total4yr:352000, seats:900,  acceptance:3.0, cutoffs:[{examId:24, value:200,  label:'GATE AIR (approx, CSE/core branches)'}] },
    { id:99, careerId:10, name:'IIT Madras (M.Tech)',    location:'Chennai, Tamil Nadu', rank:2, tuition:100000, hostel:60000, exam:1800, other:15000, total4yr:352000, seats:900,  acceptance:3.2, cutoffs:[{examId:24, value:300,  label:'GATE AIR (approx, CSE/core branches)'}] },
    { id:100,careerId:10, name:'NIT Warangal (M.Tech)',  location:'Warangal, Telangana', rank:9,  tuition:75000,  hostel:40000, exam:1200, other:12000, total4yr:254000, seats:600,  acceptance:12.0, cutoffs:[{examId:24, value:1500, label:'GATE AIR (approx, Home State quota)'}] },
    { id:101,careerId:10, name:'NIT Trichy (M.Tech)',    location:'Tiruchirappalli, Tamil Nadu', rank:8, tuition:75000, hostel:40000, exam:1200, other:12000, total4yr:254000, seats:600, acceptance:10.0, cutoffs:[{examId:24, value:1200, label:'GATE AIR (approx)'}] },
    { id:102,careerId:10, name:'JNTU Hyderabad (M.Tech)',location:'Hyderabad, Telangana', rank:null, tuition:40000, hostel:30000, exam:1000, other:10000, total4yr:150000, seats:360, acceptance:25.0, cutoffs:[{examId:24, value:5000, label:'GATE AIR (approx, PGECET also accepted)'}] },
    { id:103,careerId:10, name:'Osmania University (M.Tech)', location:'Hyderabad, Telangana', rank:null, tuition:35000, hostel:25000, exam:1000, other:10000, total4yr:130000, seats:240, acceptance:28.0, cutoffs:[{examId:24, value:6000, label:'GATE AIR (approx, PGECET also accepted)'}] }
  ],
  loans: [
    { id:1, bank:'SBI',          scheme:'SBI Scholar Loan',           logo:'SBI',  minAmount:500000,  maxAmount:4000000,  rate:8.15, rateType:'Floating', moratorium:'Course + 1 year',    tenure:15, collateralReq:true,  collateralLimit:750000, processingFee:0.5,  eligibility:{minMarks:60,maxIncome:null,ageMin:16,ageMax:35,coApplicant:'Parent/Guardian mandatory'},         documents:['Marksheets (10th & 12th)','Admission Letter','Fee Structure','Income Proof (ITR)','Aadhaar/PAN','Passport Photos','Bank Statements (6 months)','Collateral Documents'], special:'0.5% concession for girl students; No processing fee for premier institutions' },
    { id:2, bank:'HDFC Credila', scheme:'HDFC Credila Education Loan',logo:'HDFC', minAmount:100000,  maxAmount:15000000, rate:9.55, rateType:'Floating', moratorium:'Course + 6 months',  tenure:14, collateralReq:false, collateralLimit:750000, processingFee:1.0,  eligibility:{minMarks:50,maxIncome:null,coApplicant:'Co-borrower mandatory'},                              documents:['KYC Documents','Admission Confirmation','Fee Receipt','Income Proof','Bank Statements','Academic Records'], special:'Covers 100% tuition; No collateral up to ₹7.5L; Pre-admission sanction available' },
    { id:3, bank:'Axis Bank',    scheme:'Axis Bank Education Loan',   logo:'AXIS', minAmount:500000,  maxAmount:7500000,  rate:8.70, rateType:'Floating', moratorium:'Course + 12 months', tenure:15, collateralReq:true,  collateralLimit:400000, processingFee:0.75, eligibility:{minMarks:55,maxIncome:null,ageMin:18,ageMax:35,citizenship:'Indian Nationals only'},           documents:['Academic Marksheets','Admission Letter','Fee Schedule','Income Certificate','Property Documents','Aadhaar & PAN'], special:'0.5% discount online; Tax benefit Section 80E; Flexible repayment' }
  ],
  scholarships: [
    { id:1,  name:'National Scholarship Portal (NSP)',       provider:'Ministry of Education, GoI',  type:'Government', tags:['Central Government','Merit','Financial Assistance'], amountPerYear:25000,   totalAmount:100000,  eligibility:{minMarks:80, maxIncome:800000, category:'All categories'},                          careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August',    applicationEnd:'October',   url:'https://scholarships.gov.in', fee:null,              color:'#10b981' },
    { id:2,  name:'Jagananna Vidya Deevena',                 provider:'Andhra Pradesh Government',   type:'Government', tags:['State Government','Financial Assistance'], amountPerYear:60000,   totalAmount:240000,  eligibility:{minMarks:0,  maxIncome:250000, domicile:'Andhra Pradesh'},                          careerIds:[1,2,5],     applicationStart:'September', applicationEnd:'November',  url:'https://navasakam.ap.gov.in', fee:null,              color:'#f59e0b' },
    { id:3,  name:'AICTE Pragati Scholarship',               provider:'AICTE, Ministry of Education',type:'Government', tags:['Central Government','Girl Student'],      amountPerYear:50000,   totalAmount:200000,  eligibility:{minMarks:60, maxIncome:800000, gender:'Female', institution:'AICTE approved'},     careerIds:[1],         applicationStart:'October',   applicationEnd:'December',  url:'https://www.aicte-pragati-saksham-gov.in', fee:null, color:'#6366f1' },
    { id:4,  name:'HDFC Educational Crisis Scholarship',     provider:'HDFC Bank Parivartan',        type:'Private',    tags:['Private','Financial Assistance'],          amountPerYear:75000,   totalAmount:300000,  eligibility:{minMarks:55, maxIncome:500000, condition:'Family financial crisis'},                careerIds:[1,2,3,4,5], applicationStart:'July',      applicationEnd:'September', url:'https://www.hdfcbank.com/scholarships', fee:null,    color:'#ec4899' },
    { id:5,  name:'Inlaks Shivdasani Scholarship',           provider:'Inlaks Foundation',           type:'Private',    tags:['Private','Merit'],                         amountPerYear:3500000, totalAmount:7000000, eligibility:{minMarks:85, maxIncome:null, condition:'Top universities abroad', age:'Below 30'},  careerIds:[4],         applicationStart:'January',   applicationEnd:'March',     url:'https://www.inlaksfoundation.org', fee:null,         color:'#3b82f6' },
    { id:6,  name:'KVPY Fellowship',                         provider:'IISc Bangalore / DST',        type:'Government', tags:['Central Government','Merit'],              amountPerYear:80000,   totalAmount:320000,  eligibility:{minMarks:75, maxIncome:null, exam:'KVPY aptitude test required', stream:'Science'}, careerIds:[1,4,10],       applicationStart:'July',      applicationEnd:'August',    url:'https://kvpy.iisc.ac.in', fee:null,                  color:'#8b5cf6' },
    { id:7,  name:'Post-Matric Scholarship for SC Students', provider:'Ministry of Social Justice & Empowerment, GoI', type:'Government', tags:['Central Government','SC/ST/OBC','Financial Assistance'], amountPerYear:35000, totalAmount:140000, eligibility:{minMarks:0, maxIncome:250000, category:'SC'},   careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#0ea5e9' },
    { id:8,  name:'Post-Matric Scholarship for OBC Students',provider:'Ministry of Social Justice & Empowerment, GoI', type:'Government', tags:['Central Government','SC/ST/OBC','Financial Assistance'], amountPerYear:25000, totalAmount:100000, eligibility:{minMarks:0, maxIncome:250000, category:'OBC'},  careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#0ea5e9' },
    { id:9,  name:'Post-Matric Scholarship for ST Students', provider:'Ministry of Tribal Affairs, GoI', type:'Government', tags:['Central Government','SC/ST/OBC','Financial Assistance'], amountPerYear:35000, totalAmount:140000, eligibility:{minMarks:0, maxIncome:250000, category:'ST'},  careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#0ea5e9' },
    { id:10, name:'National Means-cum-Merit Scholarship (NMMS)', provider:'Ministry of Education, GoI', type:'Government', tags:['Central Government','Merit','Financial Assistance'], amountPerYear:12000, totalAmount:48000, eligibility:{minMarks:55, maxIncome:350000}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#22c55e' },
    { id:11, name:'Pre/Post-Matric Scholarship for Minorities', provider:'Ministry of Minority Affairs, GoI', type:'Government', tags:['Central Government','Minority','Financial Assistance'], amountPerYear:20000, totalAmount:80000, eligibility:{minMarks:50, maxIncome:200000, community:'Muslim, Christian, Sikh, Buddhist, Jain, Parsi'}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#14b8a6' },
    { id:12, name:'Maulana Azad National Fellowship',       provider:'Ministry of Minority Affairs, GoI', type:'Government', tags:['Central Government','Minority','Merit'], amountPerYear:200000, totalAmount:1000000, eligibility:{minMarks:55, maxIncome:null, community:'Minority', level:'M.Phil/Ph.D'}, careerIds:[4], applicationStart:'March', applicationEnd:'May', url:'https://scholarships.gov.in', fee:null, color:'#14b8a6' },
    { id:13, name:'TS ePASS Post-Matric Scholarship',       provider:'Telangana Social Welfare Dept.', type:'Government', tags:['State Government','SC/ST/OBC','Financial Assistance'], amountPerYear:20000, totalAmount:80000, eligibility:{minMarks:0, maxIncome:200000, domicile:'Telangana'}, careerIds:[1,2,5,6,7], applicationStart:'August', applicationEnd:'October', url:'https://telanganaepass.cgg.gov.in', fee:null, color:'#f59e0b' },
    { id:14, name:'TS ePASS Fee Reimbursement Scheme',      provider:'Telangana Govt.', type:'Government', tags:['State Government','Financial Assistance'], amountPerYear:100000, totalAmount:400000, eligibility:{minMarks:0, maxIncome:200000, domicile:'Telangana'}, careerIds:[1,2,6,7], applicationStart:'August', applicationEnd:'October', url:'https://telanganaepass.cgg.gov.in', fee:null, color:'#f59e0b' },
    { id:15, name:'Begum Hazrat Mahal National Scholarship',provider:'Maulana Azad Education Foundation', type:'Government', tags:['Central Government','Minority','Girl Student'], amountPerYear:12000, totalAmount:48000, eligibility:{minMarks:50, maxIncome:200000, gender:'Female', community:'Minority'}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'September', applicationEnd:'November', url:'https://scholarships.gov.in', fee:null, color:'#ec4899' },
    { id:16, name:'Priyadarshini Scholarship for Girl Students', provider:'State Women & Child Welfare Depts.', type:'Government', tags:['State Government','Girl Student'], amountPerYear:15000, totalAmount:60000, eligibility:{minMarks:60, maxIncome:400000, gender:'Female'}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'October', url:'https://scholarships.gov.in', fee:null, color:'#ec4899' },
    { id:17, name:'Tata Trusts Scholarship',                provider:'Tata Trusts',  type:'Private', tags:['Private','Merit','Financial Assistance'], amountPerYear:100000, totalAmount:400000, eligibility:{minMarks:70, maxIncome:600000}, careerIds:[1,2,4,7], applicationStart:'June', applicationEnd:'August', url:'https://www.tatatrusts.org', fee:null, color:'#a855f7' },
    { id:18, name:'Reliance Foundation Undergraduate Scholarship', provider:'Reliance Foundation', type:'Private', tags:['Private','Merit','Financial Assistance'], amountPerYear:60000, totalAmount:240000, eligibility:{minMarks:60, maxIncome:1500000}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'August', applicationEnd:'September', url:'https://www.reliancefoundation.org', fee:null, color:'#a855f7' },
    { id:19, name:'Institute Merit-cum-Means Scholarship',  provider:'Individual Colleges / Universities', type:'College', tags:['College','Merit','Financial Assistance'], amountPerYear:30000, totalAmount:120000, eligibility:{minMarks:75, maxIncome:600000}, careerIds:[1,2,3,4,5,6,7,8,9,10], applicationStart:'Varies by college', applicationEnd:'Varies by college', url:null, fee:null, color:'#64748b' },
    { id:20, name:'AICTE Saksham Scholarship for Specially-Abled', provider:'AICTE, Ministry of Education', type:'Government', tags:['Central Government','Financial Assistance'], amountPerYear:50000, totalAmount:200000, eligibility:{minMarks:0, maxIncome:800000, condition:'Persons with Disability (40%+)'}, careerIds:[1], applicationStart:'October', applicationEnd:'December', url:'https://www.aicte-pragati-saksham-gov.in', fee:null, color:'#6366f1' }
  ],
  docTypes: [
    { key:'Marksheet_10',       label:'10th Marksheet',           required:true  },
    { key:'Marksheet_12',       label:'12th Marksheet',           required:true  },
    { key:'Income_Certificate', label:'Income Certificate',       required:true  },
    { key:'Aadhaar',            label:'Aadhaar Card',             required:true  },
    { key:'PAN',                label:'PAN Card',                 required:true  },
    { key:'Passport_Photo',     label:'Passport Photographs',     required:true  },
    { key:'Bank_Statement',     label:'Bank Statements (6 mths)', required:true  },
    { key:'Admission_Letter',   label:'Admission Letter',         required:true  },
    { key:'Caste_Certificate',  label:'Caste Certificate',        required:false },
    { key:'Domicile',           label:'Domicile Certificate',     required:false },
    { key:'Scholarship_Form',   label:'Scholarship Application',  required:false }
  ]
};

// ── Year-wise cutoff trend for rank exams whose cutoffs move noticeably
// year to year (TS EAMCET examId 17, AP EAMCET examId 18). Colleges only
// store one "current" cutoff rank in DB.colleges — this multiplier is
// applied on top of it so the College Predictor can show a genuinely
// different (illustrative) cutoff per selected year, tightest in the most
// recent year and looser two years back, mirroring the real-world pattern
// of rising competition. 1.0 = the value stored in DB.colleges.
const EAMCET_YEAR_TRENDS = {
  17: { 2024: 1.12, 2025: 1.05, 2026: 1.00 }, // TS EAMCET
  18: { 2024: 1.10, 2025: 1.04, 2026: 1.00 }  // AP EAMCET
};
const EAMCET_YEARS = [2026, 2025, 2024];

// Colleges flagged `womenOnly:true` (see DB.colleges / JUNIOR_COLLEGES)
// should never be shown to a candidate who registered as Male.
function isCollegeVisibleForGender(college, gender) {
  if (!college.womenOnly) return true;
  return gender === 'Female';
}

// ── Dashboard motivational quotes — one is shown per dashboard visit. ──
const MOTIVATIONAL_QUOTES = [
  { text:'Success is the sum of small efforts, repeated day in and day out.', author:'Robert Collier' },
  { text:'The future belongs to those who believe in the beauty of their dreams.', author:'Eleanor Roosevelt' },
  { text:"Don't watch the clock; do what it does. Keep going.", author:'Sam Levenson' },
  { text:'Believe you can and you\'re halfway there.', author:'Theodore Roosevelt' },
  { text:'It always seems impossible until it\'s done.', author:'Nelson Mandela' },
  { text:'Hard work beats talent when talent doesn\'t work hard.', author:'Tim Notke' },
  { text:'The expert in anything was once a beginner.', author:'Helen Hayes' },
  { text:'Discipline is choosing between what you want now and what you want most.', author:'Abraham Lincoln' },
  { text:'Your only limit is your mind.', author:'Unknown' },
  { text:'Dream big. Start small. Act now.', author:'Robin Sharma' },
  { text:'Focus on being productive instead of busy.', author:'Tim Ferriss' },
  { text:'Every accomplishment starts with the decision to try.', author:'Unknown' },
  { text:'Push yourself, because no one else is going to do it for you.', author:'Unknown' },
  { text:'Great things never come from comfort zones.', author:'Unknown' },
  { text:'The only way to do great work is to love what you do.', author:'Steve Jobs' }
];
function quoteOfTheDay() {
  return MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
}

// ── All India states & union territories with their districts, used to
// power the coaching-class State/District filters below (independent of
// which states/districts actually have a coaching centre in COACHING_CLASSES,
// so every state's students can browse — even if it just surfaces the
// Online/Pan-India options for now). ──
const INDIA_STATES_DISTRICTS = {
  "Andaman and Nicobar Islands": [
    "Nicobar",
    "North and Middle Andaman",
    "South Andaman"
  ],
  "Andhra Pradesh": [
    "Anantapur",
    "Chittoor",
    "East Godavari",
    "Guntur",
    "Krishna",
    "Kurnool",
    "Nellore (Sri Potti Sriramulu)",
    "Prakasam",
    "Srikakulam",
    "Visakhapatnam",
    "Vizianagaram",
    "West Godavari",
    "YSR Kadapa",
    "Anakapalli",
    "Alluri Sitharama Raju",
    "Annamayya",
    "Bapatla",
    "Eluru",
    "Kakinada",
    "Konaseema",
    "Nandyal",
    "NTR",
    "Palnadu",
    "Parvathipuram Manyam",
    "Sri Sathya Sai",
    "Tirupati"
  ],
  "Arunachal Pradesh": [
    "Anjaw",
    "Changlang",
    "Dibang Valley",
    "East Kameng",
    "East Siang",
    "Kamle",
    "Kra Daadi",
    "Kurung Kumey",
    "Lepa Rada",
    "Lohit",
    "Longding",
    "Lower Dibang Valley",
    "Lower Siang",
    "Lower Subansiri",
    "Namsai",
    "Pakke Kessang",
    "Papum Pare",
    "Shi Yomi",
    "Siang",
    "Tawang",
    "Tirap",
    "Upper Siang",
    "Upper Subansiri",
    "West Kameng",
    "West Siang"
  ],
  "Assam": [
    "Baksa",
    "Barpeta",
    "Biswanath",
    "Bongaigaon",
    "Cachar",
    "Charaideo",
    "Chirang",
    "Darrang",
    "Dhemaji",
    "Dhubri",
    "Dibrugarh",
    "Dima Hasao",
    "Goalpara",
    "Golaghat",
    "Hailakandi",
    "Hojai",
    "Jorhat",
    "Kamrup",
    "Kamrup Metropolitan",
    "Karbi Anglong",
    "Karimganj",
    "Kokrajhar",
    "Lakhimpur",
    "Majuli",
    "Morigaon",
    "Nagaon",
    "Nalbari",
    "Sivasagar",
    "Sonitpur",
    "South Salmara-Mankachar",
    "Tinsukia",
    "Udalguri",
    "West Karbi Anglong"
  ],
  "Bihar": [
    "Araria",
    "Arwal",
    "Aurangabad",
    "Banka",
    "Begusarai",
    "Bhagalpur",
    "Bhojpur",
    "Buxar",
    "Darbhanga",
    "East Champaran",
    "Gaya",
    "Gopalganj",
    "Jamui",
    "Jehanabad",
    "Kaimur",
    "Katihar",
    "Khagaria",
    "Kishanganj",
    "Lakhisarai",
    "Madhepura",
    "Madhubani",
    "Munger",
    "Muzaffarpur",
    "Nalanda",
    "Nawada",
    "Patna",
    "Purnia",
    "Rohtas",
    "Saharsa",
    "Samastipur",
    "Saran",
    "Sheikhpura",
    "Sheohar",
    "Sitamarhi",
    "Siwan",
    "Supaul",
    "Vaishali",
    "West Champaran"
  ],
  "Chandigarh": [
    "Chandigarh"
  ],
  "Chhattisgarh": [
    "Balod",
    "Baloda Bazar",
    "Balrampur",
    "Bastar",
    "Bemetara",
    "Bijapur",
    "Bilaspur",
    "Dantewada",
    "Dhamtari",
    "Durg",
    "Gariaband",
    "Gaurela-Pendra-Marwahi",
    "Janjgir-Champa",
    "Jashpur",
    "Kabirdham",
    "Kanker",
    "Kondagaon",
    "Korba",
    "Koriya",
    "Mahasamund",
    "Mungeli",
    "Narayanpur",
    "Raigarh",
    "Raipur",
    "Rajnandgaon",
    "Sukma",
    "Surajpur",
    "Surguja"
  ],
  "Dadra and Nagar Haveli and Daman and Diu": [
    "Dadra and Nagar Haveli",
    "Daman",
    "Diu"
  ],
  "Delhi": [
    "Central Delhi",
    "East Delhi",
    "New Delhi",
    "North Delhi",
    "North East Delhi",
    "North West Delhi",
    "Shahdara",
    "South Delhi",
    "South East Delhi",
    "South West Delhi",
    "West Delhi"
  ],
  "Goa": [
    "North Goa",
    "South Goa"
  ],
  "Gujarat": [
    "Ahmedabad",
    "Amreli",
    "Anand",
    "Aravalli",
    "Banaskantha",
    "Bharuch",
    "Bhavnagar",
    "Botad",
    "Chhota Udaipur",
    "Dahod",
    "Dang",
    "Devbhoomi Dwarka",
    "Gandhinagar",
    "Gir Somnath",
    "Jamnagar",
    "Junagadh",
    "Kheda",
    "Kutch",
    "Mahisagar",
    "Mehsana",
    "Morbi",
    "Narmada",
    "Navsari",
    "Panchmahal",
    "Patan",
    "Porbandar",
    "Rajkot",
    "Sabarkantha",
    "Surat",
    "Surendranagar",
    "Tapi",
    "Vadodara",
    "Valsad"
  ],
  "Haryana": [
    "Ambala",
    "Bhiwani",
    "Charkhi Dadri",
    "Faridabad",
    "Fatehabad",
    "Gurugram",
    "Hisar",
    "Jhajjar",
    "Jind",
    "Kaithal",
    "Karnal",
    "Kurukshetra",
    "Mahendragarh",
    "Nuh",
    "Palwal",
    "Panchkula",
    "Panipat",
    "Rewari",
    "Rohtak",
    "Sirsa",
    "Sonipat",
    "Yamunanagar"
  ],
  "Himachal Pradesh": [
    "Bilaspur",
    "Chamba",
    "Hamirpur",
    "Kangra",
    "Kinnaur",
    "Kullu",
    "Lahaul and Spiti",
    "Mandi",
    "Shimla",
    "Sirmaur",
    "Solan",
    "Una"
  ],
  "Jammu and Kashmir": [
    "Anantnag",
    "Bandipora",
    "Baramulla",
    "Budgam",
    "Doda",
    "Ganderbal",
    "Jammu",
    "Kathua",
    "Kishtwar",
    "Kulgam",
    "Kupwara",
    "Poonch",
    "Pulwama",
    "Rajouri",
    "Ramban",
    "Reasi",
    "Samba",
    "Shopian",
    "Srinagar",
    "Udhampur"
  ],
  "Jharkhand": [
    "Bokaro",
    "Chatra",
    "Deoghar",
    "Dhanbad",
    "Dumka",
    "East Singhbhum",
    "Garhwa",
    "Giridih",
    "Godda",
    "Gumla",
    "Hazaribagh",
    "Jamtara",
    "Khunti",
    "Koderma",
    "Latehar",
    "Lohardaga",
    "Pakur",
    "Palamu",
    "Ramgarh",
    "Ranchi",
    "Sahibganj",
    "Seraikela Kharsawan",
    "Simdega",
    "West Singhbhum"
  ],
  "Karnataka": [
    "Bagalkot",
    "Ballari",
    "Belagavi",
    "Bengaluru Rural",
    "Bengaluru Urban",
    "Bidar",
    "Chamarajanagar",
    "Chikkaballapur",
    "Chikkamagaluru",
    "Chitradurga",
    "Dakshina Kannada",
    "Davanagere",
    "Dharwad",
    "Gadag",
    "Hassan",
    "Haveri",
    "Kalaburagi",
    "Kodagu",
    "Kolar",
    "Koppal",
    "Mandya",
    "Mysuru",
    "Raichur",
    "Ramanagara",
    "Shivamogga",
    "Tumakuru",
    "Udupi",
    "Uttara Kannada",
    "Vijayapura",
    "Vijayanagara",
    "Yadgir"
  ],
  "Kerala": [
    "Alappuzha",
    "Ernakulam",
    "Idukki",
    "Kannur",
    "Kasaragod",
    "Kollam",
    "Kottayam",
    "Kozhikode",
    "Malappuram",
    "Palakkad",
    "Pathanamthitta",
    "Thiruvananthapuram",
    "Thrissur",
    "Wayanad"
  ],
  "Ladakh": [
    "Kargil",
    "Leh"
  ],
  "Lakshadweep": [
    "Lakshadweep"
  ],
  "Madhya Pradesh": [
    "Agar Malwa",
    "Alirajpur",
    "Anuppur",
    "Ashoknagar",
    "Balaghat",
    "Barwani",
    "Betul",
    "Bhind",
    "Bhopal",
    "Burhanpur",
    "Chhatarpur",
    "Chhindwara",
    "Damoh",
    "Datia",
    "Dewas",
    "Dhar",
    "Dindori",
    "Guna",
    "Gwalior",
    "Harda",
    "Hoshangabad (Narmadapuram)",
    "Indore",
    "Jabalpur",
    "Jhabua",
    "Katni",
    "Khandwa",
    "Khargone",
    "Mandla",
    "Mandsaur",
    "Morena",
    "Narsinghpur",
    "Neemuch",
    "Niwari",
    "Panna",
    "Raisen",
    "Rajgarh",
    "Ratlam",
    "Rewa",
    "Sagar",
    "Satna",
    "Sehore",
    "Seoni",
    "Shahdol",
    "Shajapur",
    "Sheopur",
    "Shivpuri",
    "Sidhi",
    "Singrauli",
    "Tikamgarh",
    "Ujjain",
    "Umaria",
    "Vidisha"
  ],
  "Maharashtra": [
    "Ahmednagar",
    "Akola",
    "Amravati",
    "Aurangabad (Chhatrapati Sambhajinagar)",
    "Beed",
    "Bhandara",
    "Buldhana",
    "Chandrapur",
    "Dhule",
    "Gadchiroli",
    "Gondia",
    "Hingoli",
    "Jalgaon",
    "Jalna",
    "Kolhapur",
    "Latur",
    "Mumbai City",
    "Mumbai Suburban",
    "Nagpur",
    "Nanded",
    "Nandurbar",
    "Nashik",
    "Osmanabad (Dharashiv)",
    "Palghar",
    "Parbhani",
    "Pune",
    "Raigad",
    "Ratnagiri",
    "Sangli",
    "Satara",
    "Sindhudurg",
    "Solapur",
    "Thane",
    "Wardha",
    "Washim",
    "Yavatmal"
  ],
  "Manipur": [
    "Bishnupur",
    "Chandel",
    "Churachandpur",
    "Imphal East",
    "Imphal West",
    "Jiribam",
    "Kakching",
    "Kamjong",
    "Kangpokpi",
    "Noney",
    "Pherzawl",
    "Senapati",
    "Tamenglong",
    "Tengnoupal",
    "Thoubal",
    "Ukhrul"
  ],
  "Meghalaya": [
    "East Garo Hills",
    "East Jaintia Hills",
    "East Khasi Hills",
    "North Garo Hills",
    "Ri Bhoi",
    "South Garo Hills",
    "South West Garo Hills",
    "South West Khasi Hills",
    "West Garo Hills",
    "West Jaintia Hills",
    "West Khasi Hills"
  ],
  "Mizoram": [
    "Aizawl",
    "Champhai",
    "Hnahthial",
    "Khawzawl",
    "Kolasib",
    "Lawngtlai",
    "Lunglei",
    "Mamit",
    "Saiha",
    "Saitual",
    "Serchhip"
  ],
  "Nagaland": [
    "Chumoukedima",
    "Dimapur",
    "Kiphire",
    "Kohima",
    "Longleng",
    "Mokokchung",
    "Mon",
    "Niuland",
    "Noklak",
    "Peren",
    "Phek",
    "Shamator",
    "Tuensang",
    "Wokha",
    "Zunheboto"
  ],
  "Odisha": [
    "Angul",
    "Balangir",
    "Balasore",
    "Bargarh",
    "Bhadrak",
    "Boudh",
    "Cuttack",
    "Deogarh",
    "Dhenkanal",
    "Gajapati",
    "Ganjam",
    "Jagatsinghpur",
    "Jajpur",
    "Jharsuguda",
    "Kalahandi",
    "Kandhamal",
    "Kendrapara",
    "Kendujhar",
    "Khordha",
    "Koraput",
    "Malkangiri",
    "Mayurbhanj",
    "Nabarangpur",
    "Nayagarh",
    "Nuapada",
    "Puri",
    "Rayagada",
    "Sambalpur",
    "Subarnapur",
    "Sundargarh"
  ],
  "Puducherry": [
    "Karaikal",
    "Mahe",
    "Puducherry",
    "Yanam"
  ],
  "Punjab": [
    "Amritsar",
    "Barnala",
    "Bathinda",
    "Faridkot",
    "Fatehgarh Sahib",
    "Fazilka",
    "Ferozepur",
    "Gurdaspur",
    "Hoshiarpur",
    "Jalandhar",
    "Kapurthala",
    "Ludhiana",
    "Malerkotla",
    "Mansa",
    "Moga",
    "Muktsar",
    "Pathankot",
    "Patiala",
    "Rupnagar",
    "Sahibzada Ajit Singh Nagar (Mohali)",
    "Sangrur",
    "Shaheed Bhagat Singh Nagar",
    "Tarn Taran"
  ],
  "Rajasthan": [
    "Ajmer",
    "Alwar",
    "Banswara",
    "Baran",
    "Barmer",
    "Bharatpur",
    "Bhilwara",
    "Bikaner",
    "Bundi",
    "Chittorgarh",
    "Churu",
    "Dausa",
    "Dholpur",
    "Dungarpur",
    "Hanumangarh",
    "Jaipur",
    "Jaisalmer",
    "Jalore",
    "Jhalawar",
    "Jhunjhunu",
    "Jodhpur",
    "Karauli",
    "Kota",
    "Nagaur",
    "Pali",
    "Pratapgarh",
    "Rajsamand",
    "Sawai Madhopur",
    "Sikar",
    "Sirohi",
    "Sri Ganganagar",
    "Tonk",
    "Udaipur"
  ],
  "Sikkim": [
    "East Sikkim",
    "North Sikkim",
    "South Sikkim",
    "West Sikkim",
    "Pakyong",
    "Soreng"
  ],
  "Tamil Nadu": [
    "Ariyalur",
    "Chengalpattu",
    "Chennai",
    "Coimbatore",
    "Cuddalore",
    "Dharmapuri",
    "Dindigul",
    "Erode",
    "Kallakurichi",
    "Kancheepuram",
    "Kanyakumari",
    "Karur",
    "Krishnagiri",
    "Madurai",
    "Mayiladuthurai",
    "Nagapattinam",
    "Namakkal",
    "Nilgiris",
    "Perambalur",
    "Pudukkottai",
    "Ramanathapuram",
    "Ranipet",
    "Salem",
    "Sivaganga",
    "Tenkasi",
    "Thanjavur",
    "Theni",
    "Thoothukudi",
    "Tiruchirappalli",
    "Tirunelveli",
    "Tirupathur",
    "Tiruppur",
    "Tiruvallur",
    "Tiruvannamalai",
    "Tiruvarur",
    "Vellore",
    "Viluppuram",
    "Virudhunagar"
  ],
  "Telangana": [
    "Adilabad",
    "Bhadradri Kothagudem",
    "Hyderabad",
    "Jagtial",
    "Jangaon",
    "Jayashankar Bhupalpally",
    "Jogulamba Gadwal",
    "Kamareddy",
    "Karimnagar",
    "Khammam",
    "Komaram Bheem Asifabad",
    "Mahabubabad",
    "Mahabubnagar",
    "Mancherial",
    "Medak",
    "Medchal-Malkajgiri",
    "Mulugu",
    "Nagarkurnool",
    "Nalgonda",
    "Narayanpet",
    "Nirmal",
    "Nizamabad",
    "Peddapalli",
    "Rajanna Sircilla",
    "Rangareddy",
    "Sangareddy",
    "Siddipet",
    "Suryapet",
    "Vikarabad",
    "Wanaparthy",
    "Warangal",
    "Hanumakonda",
    "Yadadri Bhuvanagiri"
  ],
  "Tripura": [
    "Dhalai",
    "Gomati",
    "Khowai",
    "North Tripura",
    "Sepahijala",
    "South Tripura",
    "Unakoti",
    "West Tripura"
  ],
  "Uttar Pradesh": [
    "Agra",
    "Aligarh",
    "Ambedkar Nagar",
    "Amethi",
    "Amroha",
    "Auraiya",
    "Ayodhya",
    "Azamgarh",
    "Baghpat",
    "Bahraich",
    "Ballia",
    "Balrampur",
    "Banda",
    "Barabanki",
    "Bareilly",
    "Basti",
    "Bhadohi",
    "Bijnor",
    "Budaun",
    "Bulandshahr",
    "Chandauli",
    "Chitrakoot",
    "Deoria",
    "Etah",
    "Etawah",
    "Farrukhabad",
    "Fatehpur",
    "Firozabad",
    "Gautam Buddha Nagar",
    "Ghaziabad",
    "Ghazipur",
    "Gonda",
    "Gorakhpur",
    "Hamirpur",
    "Hapur",
    "Hardoi",
    "Hathras",
    "Jalaun",
    "Jaunpur",
    "Jhansi",
    "Kannauj",
    "Kanpur Dehat",
    "Kanpur Nagar",
    "Kasganj",
    "Kaushambi",
    "Kheri (Lakhimpur Kheri)",
    "Kushinagar",
    "Lalitpur",
    "Lucknow",
    "Maharajganj",
    "Mahoba",
    "Mainpuri",
    "Mathura",
    "Mau",
    "Meerut",
    "Mirzapur",
    "Moradabad",
    "Muzaffarnagar",
    "Pilibhit",
    "Pratapgarh",
    "Prayagraj",
    "Raebareli",
    "Rampur",
    "Saharanpur",
    "Sambhal",
    "Sant Kabir Nagar",
    "Shahjahanpur",
    "Shamli",
    "Shravasti",
    "Siddharthnagar",
    "Sitapur",
    "Sonbhadra",
    "Sultanpur",
    "Unnao",
    "Varanasi"
  ],
  "Uttarakhand": [
    "Almora",
    "Bageshwar",
    "Chamoli",
    "Champawat",
    "Dehradun",
    "Haridwar",
    "Nainital",
    "Pauri Garhwal",
    "Pithoragarh",
    "Rudraprayag",
    "Tehri Garhwal",
    "Udham Singh Nagar",
    "Uttarkashi"
  ],
  "West Bengal": [
    "Alipurduar",
    "Bankura",
    "Birbhum",
    "Cooch Behar",
    "Dakshin Dinajpur",
    "Darjeeling",
    "Hooghly",
    "Howrah",
    "Jalpaiguri",
    "Jhargram",
    "Kalimpong",
    "Kolkata",
    "Malda",
    "Murshidabad",
    "Nadia",
    "North 24 Parganas",
    "Paschim Bardhaman",
    "Paschim Medinipur",
    "Purba Bardhaman",
    "Purba Medinipur",
    "Purulia",
    "South 24 Parganas",
    "Uttar Dinajpur"
  ]
};

// ── Coaching classes (offline centres + online programs) per exam. ──
// mode: 'Online' | 'Offline'. Offline entries carry state/district so the
// dashboard can filter by location; Online entries are PAN-India (no
// state/district restriction) and carry a link instead.
const COACHING_CLASSES = [
  // TS EAMCET / AP EAMCET / JEE / NEET-style large integrated coaching chains
  { id:1,  examIds:[17,1],   name:'Sri Chaitanya Educational Institutions', mode:'Offline', state:'Telangana', district:'Warangal', city:'Warangal', fees:'₹1.1L – 1.5L /yr', phone:'1800-123-4567' },
  { id:2,  examIds:[17,1],   name:'Narayana IIT/EAMCET Academy',            mode:'Offline', state:'Telangana', district:'Hyderabad', city:'Kukatpally, Hyderabad', fees:'₹1.0L – 1.4L /yr', phone:'1800-200-1000' },
  { id:3,  examIds:[18,1],   name:'Sri Chaitanya (Vijayawada)',             mode:'Offline', state:'Andhra Pradesh', district:'Krishna', city:'Vijayawada', fees:'₹1.1L – 1.5L /yr', phone:'1800-123-4567' },
  { id:4,  examIds:[18,1],   name:'Narayana (Guntur)',                      mode:'Offline', state:'Andhra Pradesh', district:'Guntur', city:'Guntur', fees:'₹1.0L – 1.4L /yr', phone:'1800-200-1000' },
  { id:5,  examIds:[1,2],    name:'Aakash Institute',                       mode:'Offline', state:'Telangana', district:'Hyderabad', city:'Ameerpet, Hyderabad', fees:'₹90K – 1.3L /yr', phone:'1800-102-2727' },
  { id:6,  examIds:[1,2],    name:'Aakash Institute',                       mode:'Offline', state:'Delhi', district:'New Delhi', city:'New Delhi', fees:'₹95K – 1.3L /yr', phone:'1800-102-2727' },
  { id:7,  examIds:[1,2],    name:'Allen Career Institute',                 mode:'Offline', state:'Rajasthan', district:'Kota', city:'Kota', fees:'₹1.2L – 1.9L /yr', phone:'1800-102-5535' },
  { id:8,  examIds:[1,2],    name:'FIITJEE',                                mode:'Offline', state:'Delhi', district:'New Delhi', city:'New Delhi', fees:'₹1.3L – 2.0L /yr', phone:'1800-11-4242' },
  { id:9,  examIds:[1,2],    name:'Bansal Classes',                         mode:'Offline', state:'Rajasthan', district:'Kota', city:'Kota', fees:'₹1.1L – 1.7L /yr', phone:'0744-2436001' },
  { id:10, examIds:[1,2,9,10,17,18,24], name:'Physics Wallah (PW)',         mode:'Online',  link:'https://www.pw.live', fees:'₹4K – 25K /yr' },
  { id:11, examIds:[1,2,6,7,9,10,17,18], name:"Unacademy",                  mode:'Online',  link:'https://unacademy.com', fees:'₹5K – 30K /yr' },
  { id:12, examIds:[1,2,6,7], name:"BYJU'S",                                mode:'Online',  link:'https://byjus.com', fees:'₹8K – 45K /yr' },
  { id:13, examIds:[1,2,10], name:'Vedantu',                                mode:'Online',  link:'https://www.vedantu.com', fees:'₹6K – 35K /yr' },
  // NEET
  { id:14, examIds:[2],  name:'Aakash Institute (NEET wing)',               mode:'Offline', state:'Telangana', district:'Hyderabad', city:'Hyderabad', fees:'₹95K – 1.3L /yr', phone:'1800-102-2727' },
  { id:15, examIds:[2],  name:'Narayana Medical Academy',                   mode:'Offline', state:'Andhra Pradesh', district:'Guntur', city:'Guntur', fees:'₹1.0L – 1.4L /yr', phone:'1800-200-1000' },
  // CAT / Management
  { id:16, examIds:[13,14], name:"T.I.M.E. (Triumphant Institute)",         mode:'Offline', state:'Telangana', district:'Hyderabad', city:'Ameerpet, Hyderabad', fees:'₹35K – 60K', phone:'1800-419-1100' },
  { id:17, examIds:[13,14], name:'IMS Learning Resources',                  mode:'Offline', state:'Maharashtra', district:'Mumbai', city:'Mumbai', fees:'₹40K – 65K', phone:'1800-266-8000' },
  { id:18, examIds:[13,14], name:'CareerLauncher',                         mode:'Online',  link:'https://www.careerlauncher.com', fees:'₹20K – 45K' },
  // CLAT / Law
  { id:19, examIds:[11,12], name:'CLATapult',                              mode:'Online',  link:'https://clatapult.com', fees:'₹15K – 30K' },
  { id:20, examIds:[11,12], name:'Career Launcher CLAT',                    mode:'Offline', state:'Delhi', district:'New Delhi', city:'New Delhi', fees:'₹35K – 55K', phone:'1800-266-8000' },
  // UPSC CSE
  { id:21, examIds:[10], name:"Vajiram & Ravi",                            mode:'Offline', state:'Delhi', district:'New Delhi', city:'Old Rajinder Nagar, Delhi', fees:'₹1.5L – 2.2L', phone:'011-2875-2545' },
  { id:22, examIds:[10], name:'Vision IAS',                                mode:'Offline', state:'Delhi', district:'New Delhi', city:'Karol Bagh, Delhi', fees:'₹1.4L – 2.0L', phone:'011-4517-0303' },
  { id:23, examIds:[10], name:'Drishti IAS',                               mode:'Offline', state:'Uttar Pradesh', district:'Prayagraj', city:'Prayagraj', fees:'₹1.2L – 1.8L', phone:'0532-2440642' },
  { id:24, examIds:[10], name:'Drishti IAS Online',                        mode:'Online',  link:'https://www.drishtiias.com', fees:'₹10K – 40K' },
  { id:25, examIds:[10], name:"StudyIQ IAS",                               mode:'Online',  link:'https://www.studyiq.com', fees:'₹8K – 35K' },
  // GATE
  { id:26, examIds:[24], name:'Made Easy',                                 mode:'Offline', state:'Delhi', district:'New Delhi', city:'Kalu Sarai, Delhi', fees:'₹80K – 1.3L', phone:'011-4507-6500' },
  { id:27, examIds:[24], name:'GATE Academy',                              mode:'Offline', state:'Madhya Pradesh', district:'Bhopal', city:'Bhopal', fees:'₹70K – 1.1L', phone:'0755-4092020' },
  { id:28, examIds:[24], name:'Made Easy Online',                          mode:'Online',  link:'https://made-easy.in', fees:'₹15K – 40K' },
  // NDA / CDS / Defence
  { id:29, examIds:[15,16], name:'Major Kalshi Classes',                   mode:'Offline', state:'Delhi', district:'New Delhi', city:'New Delhi', fees:'₹40K – 70K', phone:'011-4909-5453' },
  { id:30, examIds:[15,16], name:'SSBCrackC',                              mode:'Online',  link:'https://ssbcrackexams.com', fees:'₹5K – 20K' },
  // NIFT / Fashion
  { id:31, examIds:[23], name:'Pearl Academy Prep',                        mode:'Offline', state:'Delhi', district:'New Delhi', city:'New Delhi', fees:'₹50K – 90K', phone:'1800-102-6499' },
  { id:32, examIds:[23], name:'NIFT/NID Foundation (Online)',              mode:'Online',  link:'https://www.niftnidcoaching.com', fees:'₹15K – 35K' },
  // GRE / TOEFL (abroad MS)
  { id:33, examIds:[8,9], name:'Manhattan Prep',                           mode:'Online',  link:'https://www.manhattanprep.com', fees:'$300 – $1200' },
  { id:34, examIds:[8,9], name:'Magoosh',                                  mode:'Online',  link:'https://magoosh.com', fees:'$100 – $250' },
  { id:35, examIds:[8,9], name:'Jamboree Education',                       mode:'Offline', state:'Telangana', district:'Hyderabad', city:'Banjara Hills, Hyderabad', fees:'₹40K – 80K', phone:'1800-3000-2929' },
];

function coachingForExam(examId) {
  return COACHING_CLASSES.filter(c => c.examIds.includes(examId));
}

// ── Recommended books per exam. ──
const BOOKS_BY_EXAM = {
  1:  ['NCERT Physics, Chemistry & Maths (Class 11 & 12)', "H.C. Verma — Concepts of Physics (Vol 1 & 2)", 'R.D. Sharma — Objective Mathematics', 'O.P. Tandon — Physical & Organic Chemistry', "Arihant — 41 Years' JEE Main & Advanced Chapterwise"],
  2:  ['NCERT Biology, Physics & Chemistry (Class 11 & 12)', 'Trueman\'s Elementary Biology (Vol 1 & 2)', 'MTG NCERT at your Fingertips', 'Dinesh Objective Biology', 'O.P. Tandon — Physical & Organic Chemistry'],
  3:  ['DGCA CAR Section on ATPL/CPL Ground Subjects', 'Oxford Aviation Training Manuals — Air Navigation & Meteorology', 'Aviation English proficiency guides'],
  8:  ['Manhattan Prep — GRE 5lb Book of Practice Problems', 'ETS Official Guide to the GRE', 'Barron\'s TOEFL iBT', 'Word Power Made Easy — Norman Lewis'],
  9:  ['ETS Official Guide to the GRE', 'Barron\'s TOEFL iBT Superpack'],
  10: ['M. Laxmikanth — Indian Polity', 'Bipan Chandra — India\'s Struggle for Independence', 'Ramesh Singh — Indian Economy', 'NCERT History/Geography/Polity (Class 6-12)', 'Vision IAS / Vajiram Current Affairs Compilations'],
  11: ['Universal\'s CLAT Guide', 'RS Aggarwal — Quantitative Aptitude', 'Legal Reasoning by A.P. Bhardwaj', "Word Power Made Easy — Norman Lewis"],
  12: ['Universal\'s CLAT/AILET Guide', 'General Knowledge & Current Affairs — Manorama Yearbook'],
  13: ['Arun Sharma — Quantitative Aptitude for CAT', 'Nishit Sinha — Data Interpretation & Logical Reasoning', 'Arun Sharma — Verbal Ability & Reading Comprehension'],
  14: ['Arun Sharma — Quantitative Aptitude for CAT', 'XAT Decision Making by Gautam Puri'],
  15: ['NCERT Mathematics (Class 11 & 12)', 'Pathfinder for NDA & NA Entrance Examination', 'General Knowledge Manual — Pearson'],
  16: ['Pathfinder CDS Entrance Examination', 'NCERT Mathematics (Class 11 & 12)', 'Objective General English by S.P. Bakshi'],
  17: ['TS EAMCET Telangana Intermediate Board Textbooks (Class 11 & 12)', 'Sakshi/Sri Chaitanya EAMCET Study Material', 'Previous 15 Years TS EAMCET Solved Papers'],
  18: ['AP EAMCET Andhra Pradesh Intermediate Board Textbooks (Class 11 & 12)', 'Sri Chaitanya/Narayana AP EAMCET Study Material', 'Previous 15 Years AP EAMCET Solved Papers'],
  23: ['NIFT Entrance Exam Guide — Arihant', 'General Ability Test & Creative Ability Test workbooks'],
  24: ['Made Easy / GATE Academy subject-wise books', 'Previous 15 Years GATE Solved Papers', 'Standard undergraduate textbook for your GATE branch (e.g. Cormen for CS, Rajput for EEE)'],
};

// ── Study plan template per exam — combines the exam's own syllabus with
// a simple week-by-week phased plan built from its prepTips. ──
function studyPlanForExam(exam) {
  const weeks = [
    { phase:'Foundation (Weeks 1-4)', focus:'Cover NCERT/board fundamentals for every subject in the syllabus. No shortcuts — build the base first.' },
    { phase:'Concept Building (Weeks 5-10)', focus:'Move to advanced reference books/coaching material. Solve chapter-wise problems after every topic.' },
    { phase:'Practice & Mocks (Weeks 11-16)', focus:'Full-length mock tests weekly. Analyse mistakes, revise weak chapters, track score trend.' },
    { phase:'Revision & Final Sprint (last 2-3 weeks)', focus:'Only revision — formula sheets, previous years\' papers, timed sectional tests. Avoid new topics.' }
  ];
  return { syllabus: exam.syllabus, prepTips: exam.prepTips, weeks };
}

function copySyllabusText(examId) {
  const exam = DB.exams.find(e => e.id === examId);
  if (!exam) return '';
  return `${exam.name} — ${exam.fullForm}\nSyllabus:\n` + exam.syllabus.map((s,i)=>`${i+1}. ${s}`).join('\n');
}

const AIEngine = {
  calcEMI(P, annualRate, n) {
    const r = annualRate / 12 / 100;
    if (r === 0) return P / n;
    return P * r * Math.pow(1+r,n) / (Math.pow(1+r,n) - 1);
  },
  calcLoanProbability(marks12, familyIncome, loanAmount) {
    let s = 10;
    s += marks12 >= 90 ? 35 : marks12 >= 75 ? 25 : marks12 >= 60 ? 15 : 5;
    s += familyIncome <= 300000 ? 30 : familyIncome <= 600000 ? 20 : familyIncome <= 1200000 ? 10 : 5;
    s += loanAmount <= 750000 ? 25 : loanAmount <= 2000000 ? 15 : 8;
    return Math.min(s, 97);
  },
  calcScholarshipProbability(marks12, familyIncome, careerId, gender, state) {
    let p = 0;
    p += marks12 >= 90 ? 40 : marks12 >= 80 ? 28 : marks12 >= 70 ? 15 : 5;
    p += familyIncome <= 250000 ? 30 : familyIncome <= 500000 ? 20 : familyIncome <= 800000 ? 10 : 0;
    if (gender === 'Female') p += 10;
    if (state === 'Andhra Pradesh') p += 8;
    return Math.min(p, 95);
  },
  matchScholarships(profile) {
    return DB.scholarships.filter(s => {
      if (!s.careerIds.includes(profile.careerId)) return false;
      if (profile.marks12 < s.eligibility.minMarks) return false;
      if (s.eligibility.maxIncome && profile.familyIncome > s.eligibility.maxIncome) return false;
      if (s.eligibility.gender && s.eligibility.gender !== profile.gender) return false;
      if (s.eligibility.domicile && s.eligibility.domicile !== profile.state) return false;
      return true;
    }).map(s => ({ ...s, matchScore: Math.round(70 + Math.random()*25) }));
  },
  generateActionPlan(profile, loanProb, scholProb) {
    const plan = [];
    if (profile.marks12 < 75) plan.push({step:1, action:'Improve Academic Profile', detail:'Consider bridge courses or entrance coaching to strengthen academic credentials.'});
    if (loanProb > 70) plan.push({step:plan.length+1, action:'Apply for Education Loan Early', detail:`Your loan approval probability is ${loanProb}%. Apply 3-6 months before admission.`});
    if (scholProb > 50) plan.push({step:plan.length+1, action:'Apply for Scholarships', detail:`You qualify for ${AIEngine.matchScholarships(profile).length} scholarships. Apply before deadlines.`});
    plan.push({step:plan.length+1, action:'Prepare Document Checklist', detail:'Upload all required documents in the Document Vault to speed up loan processing.'});
    plan.push({step:plan.length+1, action:'Open Education Loan Account', detail:'Visit the nearest SBI/HDFC branch or apply online with pre-sanction for your institution.'});
    return plan;
  },
  calcCareerSuitability(profile, careerId) {
    let score = 50;
    if (careerId===1) { if(profile.mathScore>=80)score+=20; if(profile.scienceScore>=75)score+=15; if(profile.techSkills>=4)score+=10; if(profile.marks12>=85)score+=5; }
    else if(careerId===2){ if(profile.scienceScore>=85)score+=20; if(profile.biologyScore>=85)score+=15; if(profile.marks12>=90)score+=10; if(profile.researchInterest>=4)score+=5; }
    else if(careerId===3){ if(profile.mathScore>=75)score+=15; if(profile.communication>=4)score+=15; if(profile.marks12>=70)score+=10; score+=10; }
    else if(careerId===4){ if(profile.marks12>=90)score+=20; if(profile.researchInterest>=4)score+=15; if(profile.mathScore>=85)score+=10; }
    else if(careerId===5){ if(profile.communication>=4)score+=20; if(profile.leadership>=4)score+=15; if(profile.englishScore>=75)score+=10; }
    else if(careerId===6){ if(profile.communication>=4)score+=20; if(profile.englishScore>=75)score+=15; if(profile.marks12>=70)score+=10; }
    else if(careerId===7){ if(profile.mathScore>=75)score+=15; if(profile.leadership>=4)score+=15; if(profile.communication>=4)score+=10; if(profile.marks12>=75)score+=5; }
    else if(careerId===8){ if(profile.leadership>=4)score+=20; if(profile.mathScore>=65)score+=10; if(profile.communication>=4)score+=10; score+=5; }
    else if(careerId===9){ if(profile.communication>=4)score+=15; if(profile.marks12>=60)score+=10; score+=20; }
    else if(careerId===10){ if(profile.mathScore>=80)score+=20; if(profile.researchInterest>=4)score+=15; if(profile.techSkills>=4)score+=10; if(profile.marks12>=75)score+=5; }
    return Math.min(Math.round(score), 99);
  },

  // Builds a simple generic career roadmap when a career doesn't have a
  // dedicated roadmap object (like PILOT_ROADMAP) of its own.
  buildGenericRoadmap(career) {
    return [
      `Complete your current education level and meet ${career.title}'s eligibility requirements.`,
      `Prepare for and clear the relevant entrance exam(s) for ${career.title}.`,
      `Complete the ${career.durationYears}-year ${career.title} program.`,
      `Build practical skills (${career.skills.slice(0,3).join(', ')}) through internships/projects.`,
      `Enter the workforce as a ${career.careers[0]} or pursue further specialisation.`
    ];
  },

  // ── Career Recommendation Engine ────────────────────────────
  // Combines education level, academics, family income, multi-select
  // skills, research interest, the student's own preferred career choice,
  // and government/higher-education interest into one recommendation:
  // best-matching careers, required courses/skills, entrance exams,
  // a roadmap, estimated salary, top + local colleges, scholarships and
  // (if relevant) government job opportunities.
  generateRecommendation(profile) {
    const ranked = DB.careers
      .map(c => ({ career: c, score: AIEngine.calcCareerSuitability(profile, c.id) }))
      .sort((a, b) => b.score - a.score);

    const preferred = DB.careers.find(c => c.id === profile.careerId) || ranked[0].career;
    const exams = DB.exams.filter(e => e.careerId === preferred.id);
    const allColleges = DB.colleges.filter(c => c.careerId === preferred.id);
    const topColleges = [...allColleges].sort((a, b) => (a.rank || 999) - (b.rank || 999)).slice(0, 6);
    const localColleges = allColleges.filter(c => /Warangal|Telangana/i.test(c.location));
    const scholarships = AIEngine.matchScholarships({ ...profile, careerId: preferred.id });
    const govtOpportunities = profile.govtInterest ? GOVT_JOBS : [];
    const roadmap = preferred.slug === 'pilot'
      ? PILOT_ROADMAP.steps.map(s => `${s.stage}: ${s.detail}`)
      : AIEngine.buildGenericRoadmap(preferred);

    return {
      ranked, preferred, exams, topColleges, localColleges, scholarships, govtOpportunities, roadmap,
      salaryRange: { min: preferred.avgSalaryMin, max: preferred.avgSalaryMax },
      requiredSkills: preferred.skills,
      suitableCourses: preferred.careers
    };
  },

  // ── College Predictor ──────────────────────────────────────
  // Given an exam id and the student's score/rank/percentile, builds the list
  // of candidate colleges with a `relativeStrength` figure for each — how the
  // student compares to that college's (year- and branch-adjusted) cutoff,
  // unified so >1 always means "beat the cutoff" whether the exam is rank-
  // based (lower is better) or score/percentile-based (higher is better).
  // This function does NOT decide Safe/Moderate/Dream itself any more — that
  // decision is made by the trained ML classifier on the backend (see
  // api.predictCollegeChances() in app.js / POST /api/colleges/predict-chance),
  // which is why this only returns the numeric relativeStrength per college.
  // `branchKey` (optional) narrows Engineering/Management results to a
  // specific branch/specialization. `year` (optional) applies the TS/AP
  // EAMCET year-on-year cutoff trend. `gender` filters out women-only
  // colleges for candidates who aren't registered as Female.
  BRANCH_GROUPS: { 1: 'ENGINEERING_BRANCHES', 7: 'MANAGEMENT_SPECIALIZATIONS' },

  buildCollegeCandidates(examId, value, branchKey, year, gender) {
    const exam = DB.exams.find(e => e.id === examId);
    if (!exam || !value || value <= 0) return { exam, candidates: [] };

    const branchList = AIEngine.BRANCH_GROUPS[exam.careerId] === 'MANAGEMENT_SPECIALIZATIONS' ? MANAGEMENT_SPECIALIZATIONS : ENGINEERING_BRANCHES;
    const branch = branchKey ? branchList.find(b => b.key === branchKey) : null;
    const gatedCareerId = exam.careerId; // only apply branch logic to colleges in the same career as the exam (Engineering or Management)
    const yearTrend = (year && EAMCET_YEAR_TRENDS[examId]) ? EAMCET_YEAR_TRENDS[examId][year] : null;

    const candidates = [];
    DB.colleges.forEach(col => {
      if (!isCollegeVisibleForGender(col, gender)) return; // never show women-only colleges to non-Female candidates
      const cutoff = (col.cutoffs || []).find(c => c.examId === examId);
      if (!cutoff) return;
      const career = DB.careers.find(c => c.id === col.careerId);

      // Skip colleges that don't offer the chosen branch/specialization at all.
      if (branch && col.careerId === gatedCareerId) {
        const offered = col.branches || branchList.map(b => b.key); // default: assume all offered
        if (!offered.includes(branch.key)) return;
      }

      // Apply branch/specialization multiplier only within the matching career.
      let effectiveCutoff = cutoff.value;
      let branchLabel = null;
      if (branch && col.careerId === gatedCareerId) {
        branchLabel = branch.label;
        if (exam.examType === 'rank') {
          effectiveCutoff = cutoff.value * branch.multiplier; // easier branch = looser (higher) rank cutoff
        } else {
          // percentile-type: easier branch = lower percentile requirement, floor at 50
          effectiveCutoff = Math.max(50, cutoff.value - (branch.multiplier - 1) * 8);
        }
      }

      // Apply the TS/AP EAMCET year-on-year cutoff trend, if selected.
      if (yearTrend) effectiveCutoff = effectiveCutoff * yearTrend;

      // relativeStrength: >1 always means "did better than the cutoff".
      let relativeStrength;
      let examTypeForModel;
      if (exam.examType === 'rank') {
        relativeStrength = effectiveCutoff / value; // lower rank number = better
        examTypeForModel = 'rank';
      } else if (exam.examType === 'merit') {
        relativeStrength = 1.0; // no fixed rank/score published — let the model fall back to its 'merit' prior
        examTypeForModel = 'merit';
      } else {
        relativeStrength = value / effectiveCutoff; // score/percentile — higher = better
        examTypeForModel = exam.examType === 'percentile' ? 'percentile' : 'score';
      }

      candidates.push({
        clientId: `c${col.id}`,
        college: col, career,
        cutoff: { ...cutoff, value: Math.round(effectiveCutoff * 100) / 100 },
        relativeStrength: Math.round(relativeStrength * 10000) / 10000,
        examType: examTypeForModel,
        branchLabel
      });
    });

    return { exam, candidates };
  }
};
