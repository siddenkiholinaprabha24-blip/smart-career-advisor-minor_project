"""
app.py — Smart Career Advisor backend entry point.

Serves:
  * REST API under /api/*  (auth, assessments (ML), financial hub, documents, notifications)
  * The existing static frontend (index.html, css/, js/) unchanged, so you can
    run everything from a single `python app.py` and open http://localhost:5000

See README.md for full setup/run instructions.
"""

import os

from flask import Flask, jsonify, send_from_directory

from db import init_db
import ml_engine
import college_ml_engine

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.environ.get(
    "SCA_FRONTEND_DIR",
    os.path.join(BASE_DIR, "..", "smart-career-advisor"),
)


def create_app():
    app = Flask(__name__, static_folder=None)

    # --- CORS (manual, no external dependency required) ---
    @app.after_request
    def add_cors_headers(resp):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        return resp

    @app.route("/api/<path:_any>", methods=["OPTIONS"])
    def cors_preflight(_any):
        return "", 204

    # --- API blueprints ---
    from routes.auth_routes import bp as auth_bp
    from routes.user_routes import bp as user_bp
    from routes.assessment_routes import bp as assessment_bp
    from routes.financial_routes import bp as financial_bp
    from routes.document_routes import bp as document_bp
    from routes.notification_routes import bp as notification_bp
    from routes.college_routes import bp as college_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(assessment_bp)
    app.register_blueprint(financial_bp)
    app.register_blueprint(document_bp)
    app.register_blueprint(notification_bp)
    app.register_blueprint(college_bp)

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "service": "smart-career-advisor-api"})

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"error": "Internal server error"}), 500

    # --- Serve the existing (unchanged) frontend ---
    if os.path.isdir(FRONTEND_DIR):
        @app.route("/")
        def index():
            return send_from_directory(FRONTEND_DIR, "index.html")

        @app.route("/<path:filename>")
        def frontend_files(filename):
            full_path = os.path.join(FRONTEND_DIR, filename)
            if os.path.isfile(full_path):
                return send_from_directory(FRONTEND_DIR, filename)
            return send_from_directory(FRONTEND_DIR, "index.html")

    return app


app = create_app()

with app.app_context():
    init_db()
    # Train the model on first boot if artifacts don't exist yet.
    try:
        ml_engine._ensure_loaded()
        print("[startup] ML model loaded OK.")
    except Exception as exc:  # pragma: no cover
        print(f"[startup] Failed to load/train ML model: {exc}")
    try:
        college_ml_engine._ensure_loaded()
        print("[startup] Admission-chance ML model loaded OK.")
    except Exception as exc:  # pragma: no cover
        print(f"[startup] Failed to load/train admission-chance ML model: {exc}")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)
