"""
db.py — thin database layer for Smart Career Advisor.

Uses Python's built-in sqlite3 module against a local SQLite file by
default (zero setup). The schema mirrors sql/schema.sql from the original
project. To move to MySQL, see the "Switching to MySQL" section in
README.md — swap get_conn() for a PyMySQL connection using the same SQL
(minor dialect tweaks noted there) since all queries here use plain
parameterized SQL with '?' placeholders.
"""

import json
import os
import sqlite3
from contextlib import contextmanager

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "instance", "career_advisor.db")

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_cursor(commit=False):
    conn = get_conn()
    try:
        cur = conn.cursor()
        yield cur
        if commit:
            conn.commit()
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    education_level TEXT DEFAULT '',
    family_income REAL DEFAULT 0,
    career_choice TEXT,
    readiness_score INTEGER DEFAULT 0,
    gender TEXT DEFAULT '',
    selected_exam_id INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    edu_level TEXT, edu_path TEXT, stream TEXT,
    marks12 REAL, marks10 REAL, family_income REAL,
    math_score REAL, science_score REAL, english_score REAL,
    tech_skills INTEGER, communication INTEGER, leadership INTEGER,
    research_interest INTEGER, gender TEXT, skills TEXT,
    govt_interest INTEGER DEFAULT 0, govt_category TEXT, higher_ed_interest INTEGER DEFAULT 0,
    career_id INTEGER, career_title TEXT,
    suitability_score REAL, readiness_score REAL,
    skill_gaps TEXT, probabilities TEXT, model_version TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS financial_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    career_id INTEGER, marks12 REAL, family_income REAL,
    loan_amount REAL, loan_probability REAL, scholarship_prob REAL,
    action_plan TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    doc_key TEXT NOT NULL,
    file_name TEXT, file_size INTEGER,
    status TEXT DEFAULT 'pending',
    uploaded_at TEXT,
    UNIQUE(user_id, doc_key)
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT, msg TEXT, type TEXT DEFAULT 'info', icon TEXT DEFAULT '🔔',
    exam_id INTEGER,
    is_read INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_assessments_user ON assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_financial_user ON financial_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
"""

DEFAULT_NOTIFICATIONS = [
    dict(title="Scholarship Deadline Alert", msg="NSP Scholarship closes in 12 days!", type="warning", icon="🔔"),
    dict(title="JEE Main Registration", msg="JEE Main April session registration opens next week.", type="info", icon="📋"),
    dict(title="Loan Pre-Sanction Ready", msg="Your SBI pre-sanction application is ready to submit.", type="success", icon="✅"),
]


# (table, column, ddl) additions introduced after the initial release —
# applied with ALTER TABLE so existing SQLite files (created before these
# columns existed) get upgraded in place instead of failing silently.
MIGRATIONS = [
    ("users", "gender", "ALTER TABLE users ADD COLUMN gender TEXT DEFAULT ''"),
    ("users", "selected_exam_id", "ALTER TABLE users ADD COLUMN selected_exam_id INTEGER"),
    ("notifications", "exam_id", "ALTER TABLE notifications ADD COLUMN exam_id INTEGER"),
]


def _run_migrations(cur):
    for table, column, ddl in MIGRATIONS:
        cur.execute(f"PRAGMA table_info({table})")
        existing_cols = {row[1] for row in cur.fetchall()}
        if column not in existing_cols:
            cur.execute(ddl)


def init_db():
    with db_cursor(commit=True) as cur:
        cur.executescript(SCHEMA)
        _run_migrations(cur)


def seed_default_notifications(user_id):
    with db_cursor(commit=True) as cur:
        for n in DEFAULT_NOTIFICATIONS:
            cur.execute(
                "INSERT INTO notifications (user_id, title, msg, type, icon, is_read) VALUES (?,?,?,?,?,?)",
                (user_id, n["title"], n["msg"], n["type"], n["icon"], 0),
            )


def row_to_dict(row):
    if row is None:
        return None
    return dict(row)


def jloads(text, default=None):
    if text is None:
        return default
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return default
