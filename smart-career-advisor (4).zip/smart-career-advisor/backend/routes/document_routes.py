from flask import Blueprint, g, jsonify, request

from auth import login_required
from db import db_cursor

bp = Blueprint("document_routes", __name__, url_prefix="/api/documents")


@bp.get("")
@login_required
def list_documents():
    with db_cursor() as cur:
        cur.execute("SELECT doc_key, status FROM documents WHERE user_id = ?", (g.user_id,))
        rows = cur.fetchall()
    return jsonify({"documents": {r["doc_key"]: r["status"] for r in rows}})


@bp.post("/upload")
@login_required
def upload_document():
    body = request.get_json(force=True) or {}
    doc_key = body.get("docKey")
    file_name = body.get("fileName", "")
    file_size = int(body.get("fileSize") or 0)
    if not doc_key:
        return jsonify({"error": "docKey is required"}), 400

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO documents (user_id, doc_key, file_name, file_size, status, uploaded_at)
               VALUES (?,?,?,?, 'uploaded', datetime('now'))
               ON CONFLICT(user_id, doc_key) DO UPDATE SET
                 file_name=excluded.file_name, file_size=excluded.file_size,
                 status='uploaded', uploaded_at=datetime('now')""",
            (g.user_id, doc_key, file_name, file_size),
        )
    return jsonify({"docKey": doc_key, "status": "uploaded"}), 201
