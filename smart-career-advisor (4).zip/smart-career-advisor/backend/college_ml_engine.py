"""
college_ml_engine.py — loads the trained admission-chance classifier and
exposes predict_chance(), used by /api/colleges/predict-chance.

This is the ML replacement for the old hard-coded Safe/Moderate/Dream
threshold ladder in the frontend's AIEngine.predictColleges(). The frontend
still owns the (static, illustrative) college/cutoff catalogue — this
endpoint only takes over the final "what's my chance" *decision*, which is
where a learned model genuinely adds value over fixed multipliers.

If the model artifacts are missing, this module trains them on the fly
(same on-first-boot convenience pattern as ml_engine.py).
"""

import os

import joblib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ML_DIR = os.path.join(HERE, "ml")

MODEL_PATH = os.path.join(ML_DIR, "admission_model.pkl")
PREPROC_PATH = os.path.join(ML_DIR, "admission_preprocessor.pkl")

VALID_EXAM_TYPES = {"rank", "score", "percentile", "merit"}

_model = None
_encoder = None
MODEL_VERSION = "admission-rf-v1"


def _ensure_loaded():
    global _model, _encoder
    if _model is not None:
        return
    if not (os.path.exists(MODEL_PATH) and os.path.exists(PREPROC_PATH)):
        from ml.train_admission_model import main as train_main
        train_main()
    _model = joblib.load(MODEL_PATH)
    _encoder = joblib.load(PREPROC_PATH)


def predict_chance(relative_strength: float, exam_type: str) -> dict:
    """
    relative_strength: >1 means the candidate beat the (year/branch-adjusted)
    cutoff — computed by the caller as:
      rank exams:              effective_cutoff / candidate_value
      score/percentile exams:  candidate_value / effective_cutoff
      merit exams:             candidate_value / effective_cutoff (or 1.0 if N/A)

    Returns: { chance, confidence, probabilities: {Safe, Moderate, Dream, Unlikely} }
    """
    _ensure_loaded()

    exam_type = exam_type if exam_type in VALID_EXAM_TYPES else "rank"
    exam_enc = int(_encoder.transform([exam_type])[0])
    X = np.array([[float(relative_strength), exam_enc]])

    proba = _model.predict_proba(X)[0]
    classes = _model.classes_
    probabilities = {str(c): round(float(p) * 100, 2) for c, p in zip(classes, proba)}
    chance = str(classes[int(np.argmax(proba))])

    return {
        "chance": chance,
        "confidence": probabilities[chance],
        "probabilities": probabilities,
        "modelVersion": MODEL_VERSION,
    }


def predict_batch(items: list) -> list:
    """items: [{relativeStrength, examType}, ...] -> [predict_chance(...), ...]"""
    return [predict_chance(it.get("relativeStrength", 0), it.get("examType", "rank")) for it in items]
