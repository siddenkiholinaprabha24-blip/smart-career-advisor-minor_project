from flask import Blueprint, g, jsonify, request

from auth import login_required
from db import db_cursor
from routes.auth_routes import serialize_user

bp = Blueprint("user_routes", __name__, url_prefix="/api/users")

ALLOWED_FIELDS = {
    "familyIncome": "family_income",
    "careerChoice": "career_choice",
    "readinessScore": "readiness_score",
    "educationLevel": "education_level",
    "gender": "gender",
    "selectedExamId": "selected_exam_id",
}


@bp.put("/me")
@login_required
def update_me():
    body = request.get_json(force=True) or {}
    updates = {ALLOWED_FIELDS[k]: v for k, v in body.items() if k in ALLOWED_FIELDS}
    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    set_clause = ", ".join(f"{col} = ?" for col in updates)
    with db_cursor(commit=True) as cur:
        cur.execute(
            f"UPDATE users SET {set_clause} WHERE id = ?",
            (*updates.values(), g.user_id),
        )
        cur.execute("SELECT * FROM users WHERE id = ?", (g.user_id,))
        user_row = cur.fetchone()

    return jsonify({"user": serialize_user(user_row)})
