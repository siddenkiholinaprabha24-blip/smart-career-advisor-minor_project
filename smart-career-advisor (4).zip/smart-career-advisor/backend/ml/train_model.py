"""
train_model.py
================
Generates a realistic synthetic student-aptitude dataset and trains a genuine
scikit-learn classifier (RandomForestClassifier) to recommend the best-fit
career from a student profile.

This is the ML core that replaces the old hand-coded if/else rule engine
(AIEngine.calcCareerSuitability in the original js/data.js) with an actual
trained, evaluable, versioned model.

Feature schema mirrors buildDerivedProfile() in the frontend's js/app.js:
the evaluator no longer collects per-subject marks directly — it derives
mathScore/scienceScore/englishScore from marks12 + the student's multi-select
skill tags, and captures education stage (school/inter/poly/grad) instead of
school board.

Run:
    python train_model.py

Produces (in this directory):
    career_dataset.csv        the generated training dataset
    model.pkl                 trained RandomForestClassifier
    preprocessor.pkl          fitted encoders/scaler used at inference time
    training_report.txt       accuracy / classification report / feature importances
"""

import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

RANDOM_STATE = 42
N_SAMPLES = 7000
HERE = os.path.dirname(os.path.abspath(__file__))

rng = np.random.default_rng(RANDOM_STATE)

# ---------------------------------------------------------------------------
# 1. Career catalogue (must stay in sync with careerId used across the app,
#    see js/data.js DB.careers).
# ---------------------------------------------------------------------------
CAREERS = {
    1: "engineering",
    2: "mbbs",
    3: "pilot",
    4: "abroad-ms",
    5: "civil-services",
    6: "law",
    7: "management",
    8: "defence",
    9: "fashion-design",
    10: "mtech",
}

EDU_GROUPS = ["school", "inter", "poly", "grad"]
GENDERS = ["Male", "Female", "Other"]

# ---------------------------------------------------------------------------
# 2. Archetype profiles: the "typical" aptitude/skill mean (and spread) of a
#    student who genuinely thrives in each career. Sampling from these with
#    Gaussian noise + occasional label noise produces a dataset that is
#    learnable but not trivially separable -- i.e. a genuine classification
#    problem, not a lookup table.
#
#    Each tuple is (mean, std) for: marks12, marks10, math, science, english,
#    techSkills(1-5), communication(1-5), leadership(1-5), researchInterest(1-5),
#    familyIncome(in lakhs)
# ---------------------------------------------------------------------------
ARCHETYPES = {
    1:  dict(marks12=(85, 8), marks10=(87, 7), math=(90, 7), science=(85, 8), english=(70, 12),
             tech=(4.4, 0.7), comm=(3.0, 0.9), lead=(2.8, 0.9), research=(3.2, 1.0), income=(9, 6),
             edu_p=[0.12, 0.68, 0.13, 0.07]),
    2:  dict(marks12=(90, 6), marks10=(90, 6), math=(65, 14), science=(90, 6), english=(75, 10),
             tech=(2.2, 0.8), comm=(3.4, 0.9), lead=(3.0, 0.9), research=(3.8, 0.9), income=(10, 7),
             edu_p=[0.10, 0.80, 0.03, 0.07]),
    3:  dict(marks12=(72, 10), marks10=(75, 9), math=(75, 10), science=(72, 9), english=(78, 9),
             tech=(2.6, 0.9), comm=(4.2, 0.8), lead=(3.6, 0.9), research=(2.0, 0.9), income=(18, 10),
             edu_p=[0.10, 0.75, 0.05, 0.10]),
    4:  dict(marks12=(91, 6), marks10=(90, 6), math=(88, 7), science=(82, 8), english=(85, 8),
             tech=(4.2, 0.8), comm=(3.6, 0.8), lead=(3.2, 0.9), research=(4.5, 0.6), income=(14, 9),
             edu_p=[0.05, 0.55, 0.05, 0.35]),
    5:  dict(marks12=(78, 10), marks10=(80, 9), math=(58, 15), science=(58, 15), english=(82, 9),
             tech=(2.0, 0.8), comm=(4.5, 0.6), lead=(4.4, 0.6), research=(3.0, 1.0), income=(7, 5),
             edu_p=[0.08, 0.60, 0.07, 0.25]),
    6:  dict(marks12=(76, 9), marks10=(78, 9), math=(52, 15), science=(52, 15), english=(86, 8),
             tech=(2.0, 0.8), comm=(4.4, 0.7), lead=(3.6, 0.9), research=(2.8, 1.0), income=(9, 6),
             edu_p=[0.10, 0.65, 0.05, 0.20]),
    7:  dict(marks12=(80, 9), marks10=(80, 9), math=(78, 10), science=(58, 14), english=(80, 9),
             tech=(2.6, 0.9), comm=(4.3, 0.7), lead=(4.3, 0.7), research=(2.5, 0.9), income=(15, 9),
             edu_p=[0.05, 0.45, 0.05, 0.45]),
    8:  dict(marks12=(68, 11), marks10=(70, 10), math=(62, 14), science=(58, 14), english=(65, 12),
             tech=(1.8, 0.7), comm=(3.7, 0.9), lead=(4.5, 0.6), research=(1.7, 0.8), income=(6, 4),
             edu_p=[0.20, 0.65, 0.08, 0.07]),
    9:  dict(marks12=(66, 12), marks10=(68, 11), math=(45, 15), science=(45, 15), english=(68, 12),
             tech=(2.0, 0.9), comm=(3.9, 0.9), lead=(2.8, 0.9), research=(1.5, 0.7), income=(11, 8),
             edu_p=[0.12, 0.68, 0.10, 0.10]),
    10: dict(marks12=(84, 7), marks10=(86, 7), math=(88, 7), science=(82, 8), english=(68, 11),
             tech=(4.4, 0.7), comm=(2.8, 0.9), lead=(2.8, 0.9), research=(4.6, 0.6), income=(8, 6),
             edu_p=[0.0, 0.15, 0.0, 0.85]),
}

LABEL_NOISE_RATE = 0.06  # fraction of samples deliberately mislabeled to
                          # a plausible neighbouring career (models real-world
                          # ambiguity in student aptitude data)

NEIGHBOURS = {
    1: [4, 7, 10], 2: [4], 3: [1, 8], 4: [1, 2, 10], 5: [6, 8],
    6: [5, 7], 7: [6, 1], 8: [3, 5], 9: [7, 6], 10: [1, 4],
}


def clip(v, lo=0, hi=100):
    return float(np.clip(v, lo, hi))


def generate_dataset(n_samples=N_SAMPLES):
    rows = []
    career_ids = list(CAREERS.keys())
    for _ in range(n_samples):
        career_id = int(rng.choice(career_ids))
        a = ARCHETYPES[career_id]

        marks12 = clip(rng.normal(*a["marks12"]))
        marks10 = clip(rng.normal(*a["marks10"]))
        math_s = clip(rng.normal(*a["math"]))
        science_s = clip(rng.normal(*a["science"]))
        eng_s = clip(rng.normal(*a["english"]))
        tech = int(np.clip(round(rng.normal(*a["tech"])), 1, 5))
        comm = int(np.clip(round(rng.normal(*a["comm"])), 1, 5))
        lead = int(np.clip(round(rng.normal(*a["lead"])), 1, 5))
        research = int(np.clip(round(rng.normal(*a["research"])), 1, 5))
        income = max(0.5, rng.normal(*a["income"])) * 100000  # back to rupees

        edu_group = str(rng.choice(EDU_GROUPS, p=a["edu_p"]))
        gender = str(rng.choice(GENDERS, p=[0.52, 0.46, 0.02]))

        label = career_id
        if rng.random() < LABEL_NOISE_RATE:
            options = NEIGHBOURS.get(career_id, career_ids)
            label = int(rng.choice(options))

        rows.append(dict(
            marks12=round(marks12, 2), marks10=round(marks10, 2),
            mathScore=round(math_s, 2), scienceScore=round(science_s, 2),
            englishScore=round(eng_s, 2),
            techSkills=tech, communication=comm, leadership=lead,
            researchInterest=research,
            familyIncome=round(income, 2), eduGroup=edu_group, gender=gender,
            careerId=label,
        ))

    return pd.DataFrame(rows)


FEATURE_COLUMNS_NUMERIC = [
    "marks12", "marks10", "mathScore", "scienceScore", "englishScore",
    "techSkills", "communication", "leadership", "researchInterest", "familyIncome",
]
FEATURE_COLUMNS_CATEGORICAL = ["eduGroup", "gender"]


def build_feature_matrix(df, encoders=None, fit=False):
    """Turns a raw dataframe into the numeric matrix the model expects.
    If fit=True, fits new LabelEncoders/StandardScaler and returns them.
    Otherwise uses the encoders passed in (inference time)."""
    if fit:
        encoders = {
            "eduGroup": LabelEncoder().fit(df["eduGroup"]),
            "gender": LabelEncoder().fit(df["gender"]),
            "scaler": StandardScaler(),
        }

    edu_enc = encoders["eduGroup"].transform(df["eduGroup"])
    gender_enc = encoders["gender"].transform(df["gender"])

    numeric = df[FEATURE_COLUMNS_NUMERIC].to_numpy(dtype=float)
    if fit:
        numeric = encoders["scaler"].fit_transform(numeric)
    else:
        numeric = encoders["scaler"].transform(numeric)

    X = np.hstack([numeric, edu_enc.reshape(-1, 1), gender_enc.reshape(-1, 1)])
    return X, encoders


def main():
    print(f"Generating {N_SAMPLES} synthetic student profiles...")
    df = generate_dataset()
    csv_path = os.path.join(HERE, "career_dataset.csv")
    df.to_csv(csv_path, index=False)
    print(f"Saved dataset -> {csv_path}  ({len(df)} rows)")

    X, encoders = build_feature_matrix(df, fit=True)
    y = df["careerId"].to_numpy()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=150,
        max_depth=10,
        min_samples_split=6,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    cv_scores = cross_val_score(model, X, y, cv=5)
    report = classification_report(
        y_test, y_pred, target_names=[CAREERS[i] for i in sorted(CAREERS)]
    )
    cm = confusion_matrix(y_test, y_pred)

    feature_names = FEATURE_COLUMNS_NUMERIC + ["eduGroup", "gender"]
    importances = sorted(
        zip(feature_names, model.feature_importances_), key=lambda t: -t[1]
    )

    report_path = os.path.join(HERE, "training_report.txt")
    with open(report_path, "w") as f:
        f.write("Smart Career Advisor — Model Training Report\n")
        f.write("=" * 55 + "\n\n")
        f.write(f"Samples: {len(df)}  (train={len(X_train)}, test={len(X_test)})\n")
        f.write(f"Test accuracy: {acc:.4f}\n")
        f.write(f"5-fold CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})\n\n")
        f.write("Classification report:\n")
        f.write(report + "\n\n")
        f.write("Confusion matrix (rows=true, cols=pred), career order = "
                 f"{[CAREERS[i] for i in sorted(CAREERS)]}\n")
        f.write(np.array2string(cm) + "\n\n")
        f.write("Feature importances:\n")
        for name, imp in importances:
            f.write(f"  {name:16s} {imp:.4f}\n")

    print(f"Test accuracy: {acc:.4f}")
    print(f"5-fold CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    print(f"Full report -> {report_path}")

    joblib.dump(model, os.path.join(HERE, "model.pkl"))
    joblib.dump(encoders, os.path.join(HERE, "preprocessor.pkl"))
    with open(os.path.join(HERE, "careers_map.json"), "w") as f:
        json.dump(CAREERS, f, indent=2)

    print("Saved model.pkl, preprocessor.pkl, careers_map.json")


if __name__ == "__main__":
    main()
