# 🎓 Smart Career Advisor — EdTech Counseling System

A premium single-page application for AI-powered career counseling, financial planning, exam guidance, and scholarship matching for Indian students.

---

## 📁 Project Structure

```
smart-career-advisor/
├── index.html              # Main SPA shell
├── css/
│   └── style.css           # Premium glassmorphic dark/light theme
├── js/
│   ├── data.js             # Static data store + AI Engine
│   └── app.js              # Full SPA logic (router, views, calculators)
├── sql/
│   └── schema.sql          # MySQL database schema with seed data
└── README.md
```

---

## 🗄️ MySQL Database Setup

### Prerequisites
- MySQL 8.0+ or MariaDB 10.6+

### Steps

```bash
# 1. Login to MySQL
mysql -u root -p

# 2. Run the schema (creates DB, tables, and seeds all data)
SOURCE /path/to/smart-career-advisor/sql/schema.sql;

# 3. Verify
USE smart_career_advisor;
SHOW TABLES;
SELECT title FROM careers;
```

### Tables Created

| Table | Description |
|---|---|
| `users` | Student accounts with academic & income details |
| `careers` | 5 career paths (Engineering, MBBS, Pilot, MS Abroad, Civil Services) |
| `exams` | 7 entrance exams (JEE Main, JEE Advanced, NEET, GRE, TOEFL, IGRUA, UPSC) |
| `colleges` | 13 top colleges with full fee breakdowns |
| `loans` | 3 bank loan schemes (SBI, HDFC Credila, Axis Bank) |
| `scholarships` | 6 scholarship schemes (NSP, Jagananna, AICTE Pragati, etc.) |
| `assessments` | Career suitability scores and skill gap analysis |
| `financial_plans` | EMI calculations and financial planning data |
| `documents` | Document checklist and upload status |
| `notifications` | In-app notification system |

---

## 🚀 Running the Frontend

Since this is a static SPA with localStorage (no backend needed to run), just serve the folder:

### Option 1: Python (recommended)
```bash
cd smart-career-advisor
python3 -m http.server 8080
# Open: http://localhost:8080
```

### Option 2: Node.js
```bash
npx serve .
# or
npx live-server
```

### Option 3: VS Code Live Server
Install the "Live Server" extension, right-click `index.html` → "Open with Live Server"

---

## ✨ Features

### 🏠 Dashboard
- Career readiness score with circular gauge
- Career path selection (5 paths)
- Skill breakdown visual bars
- Upcoming exam deadlines
- Quick action shortcuts

### 🧠 Career Evaluator (4-Step AI Assessment)
1. **Profile** — Board, marks, family income
2. **Academics** — Subject-wise scores (Maths, Physics, Chemistry, Biology, English)
3. **Skills** — Technical, communication, leadership, problem-solving (1–5 scale)
4. **Interests** — Research aptitude, career preference, gender
- Generates Career Readiness Score (0–100%)
- Identifies skill gaps with action recommendations
- Calculates career suitability for selected path

### 📚 Exam Guidance
- Timeline view of all major entrance exams
- Filter by career path
- Syllabus highlights + preparation tips
- Official website links

### 🏫 College & Fee Finder
- Fee breakdown table: Tuition + Hostel + Exam + Other
- NIRF rankings and acceptance rates
- Career-wise min/max cost summary cards

### 💰 Financial Guidance Hub

#### 🤖 AI Financial Predictor
- Loan approval probability (custom formula based on marks, income, loan amount)
- Scholarship eligibility score
- Personalised 5-step action plan

#### 🏆 Scholarship Matcher
- Auto-matches 6+ scholarships to student profile
- Eligibility criteria display
- Match percentage badge

#### 🏦 Loan Comparison
- Side-by-side comparison of SBI, HDFC Credila, Axis Bank
- Interest rates, max amounts, tenure, collateral details
- Full eligibility and document requirements

#### 🧮 EMI Calculator
- Interactive sliders for principal (₹1L–₹1.5Cr), rate (6–15%), tenure (1–15yr)
- Formula: `EMI = P × r × (1+r)^n / ((1+r)^n - 1)`
- Animated donut chart (Principal vs Interest)
- Year-wise amortization table

#### 📁 Document Vault
- 11-document checklist (required + optional)
- File upload simulation
- Auto-verification status banner
- Loan approval gate (all required docs must be uploaded)

---

## 🎨 Design System

| Feature | Details |
|---|---|
| **Dark Mode** | `#080d1a` base, indigo/emerald accents, glassmorphism cards |
| **Light Mode** | `#f1f4fb` base, soft violet shadows, clean white cards |
| **Typography** | Syne (display/headings) + DM Sans (body) |
| **Glassmorphism** | `backdrop-filter: blur(16px) saturate(1.4)` on all cards |
| **Animations** | CSS keyframe fadeSlideUp, circular progress stroke-dashoffset, slider hover scale |
| **Responsive** | Full support from 320px mobile to 4K displays |

---

## 🧮 Financial Formula Validation

```javascript
// EMI Formula (verified)
EMI = P × r × (1+r)^n / ((1+r)^n - 1)
// where r = annualRate / 12 / 100, n = tenureMonths

// Loan Probability Engine
loanProb = marks_score(0-35) + income_score(0-30) + amount_score(0-25) + base(10)

// Scholarship Probability
scholProb = marks_score(0-40) + income_score(0-30) + gender_bonus + state_bonus
```

---

## 📋 Career Paths Covered

| Career | Duration | Key Exam | Avg Starting Salary |
|---|---|---|---|
| B.Tech Engineering | 4 years | JEE Main/Advanced | ₹6L–₹25L |
| MBBS / Doctor | 5 years | NEET UG | ₹8L–₹40L |
| Commercial Pilot (CPL) | 3 years | IGRUA/DGCA | ₹18L–₹80L |
| MS Abroad (USA/UK/Canada) | 2 years | GRE + TOEFL | ₹50L–₹1.5Cr |
| Civil Services (IAS/IPS) | ~1 year prep | UPSC CSE | ₹7L–₹22L |

---

## 🛡️ Tech Stack

- **Frontend**: Vanilla HTML5, CSS3, JavaScript (ES6+)
- **Database**: MySQL 8.0 (schema + seed in `/sql/schema.sql`)
- **Fonts**: Google Fonts (Syne + DM Sans)
- **Storage**: localStorage for client-side state persistence
- **AI Engine**: Custom JavaScript scoring algorithms

---

## 📄 License

MIT License — Free for educational and personal use.
