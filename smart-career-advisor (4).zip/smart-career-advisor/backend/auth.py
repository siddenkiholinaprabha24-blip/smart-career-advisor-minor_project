"""
auth.py — JWT-based auth helpers.

The original app kept the whole "users" table in localStorage and compared
base64'd passwords in the browser. Here the backend owns the users table,
hashes passwords with werkzeug's PBKDF2 implementation, and issues short
signed JWTs the frontend stores (localStorage, just the token) and sends
back as `Authorization: Bearer <token>`.
"""

import datetime
import os
from functools import wraps

import jwt
from flask import g, jsonify, request

SECRET_KEY = os.environ.get("SCA_SECRET_KEY", "dev-secret-change-me-in-production")
TOKEN_TTL_HOURS = 24 * 7


def create_token(user_id: int) -> str:
    payload = {
        "sub": user_id,
        "iat": datetime.datetime.utcnow(),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=TOKEN_TTL_HOURS),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")


def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["sub"]
    except jwt.PyJWTError:
        return None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        token = auth_header.split(" ", 1)[1] if auth_header.startswith("Bearer ") else None
        if not token:
            return jsonify({"error": "Missing auth token"}), 401
        user_id = decode_token(token)
        if not user_id:
            return jsonify({"error": "Invalid or expired token"}), 401
        g.user_id = user_id
        return fn(*args, **kwargs)
    return wrapper
