"""
train_admission_model.py
=========================
Trains a genuine scikit-learn classifier that predicts a student's college
admission "chance" bucket (Safe / Moderate / Dream / Unlikely) from how their
rank/score compares to a college's cutoff — replacing the old hard-coded
if/else ladder in the frontend's AIEngine.predictColleges().

Why a model instead of fixed thresholds:
  Different exam types behave very differently in "cutoff units". A rank-based
  exam (JEE Advanced, TS/AP EAMCET) can swing by thousands of ranks year to
  year, while a percentile exam (CAT) barely moves more than a point or two.
  A single fixed multiplier can't represent that well — a classifier that
  sees (relative_strength, exam_type) can learn a *different, non-linear*
  decision boundary per exam type instead of one-size-fits-all cutoffs, and
  also gives a genuine confidence score instead of a binary in/out cutoff.

Feature schema (see college_ml_engine.py for the inference-time mirror):
  relative_strength : float — how the candidate compares to the (year- and
                       branch-adjusted) cutoff, unified so that >1 always
                       means "did better than the cutoff" regardless of
                       whether the underlying exam is rank-based (lower is
                       better) or score/percentile-based (higher is better).
                         rank exams:               cutoff / candidate_value
                         score/percentile exams:    candidate_value / cutoff
  examType           : categorical — 'rank' | 'score' | 'percentile' | 'merit'

Run:
    python train_admission_model.py

Produces (in this directory):
    admission_dataset.csv        the generated training dataset
    admission_model.pkl          trained RandomForestClassifier
    admission_preprocessor.pkl   fitted LabelEncoder for examType
    admission_training_report.txt
"""

import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder

RANDOM_STATE = 42
N_SAMPLES = 9000
HERE = os.path.dirname(os.path.abspath(__file__))

rng = np.random.default_rng(RANDOM_STATE)

EXAM_TYPES = ["rank", "score", "percentile", "merit"]
CLASSES = ["Unlikely", "Dream", "Moderate", "Safe"]

# Per-exam-type decision boundaries expressed in relative_strength units
# (>1 = beat the cutoff). Rank-based exams get much wider bands because
# rank cutoffs swing by thousands year-to-year; score/percentile exams are
# compressed onto a 0-100-ish scale so their bands are much tighter; merit
# (interview-based, e.g. NDA/CDS/pilot) sits in between since there's no
# hard published cutoff at all.
BOUNDARIES = {
    "rank":       dict(safe=1.43, moderate=1.00, dream=0.77),
    "score":      dict(safe=1.03, moderate=0.97, dream=0.90),
    "percentile": dict(safe=1.03, moderate=0.97, dream=0.90),
    "merit":      dict(safe=1.15, moderate=1.00, dream=0.85),
}

LABEL_NOISE_RATE = 0.05  # occasional relabel to a neighbouring bucket —
                          # models the real-world uncertainty that a fixed
                          # cutoff ladder pretends doesn't exist.


def classify(relative_strength: float, exam_type: str) -> str:
    b = BOUNDARIES[exam_type]
    if relative_strength >= b["safe"]:
        return "Safe"
    if relative_strength >= b["moderate"]:
        return "Moderate"
    if relative_strength >= b["dream"]:
        return "Dream"
    return "Unlikely"


def generate_dataset(n_samples=N_SAMPLES) -> pd.DataFrame:
    rows = []
    for _ in range(n_samples):
        exam_type = str(rng.choice(EXAM_TYPES, p=[0.45, 0.20, 0.20, 0.15]))

        # Relative strength centred around 1.0 (right at the cutoff) with a
        # log-normal spread so most candidates cluster near their realistic
        # target colleges but a long tail reaches for dream/safe schools.
        raw = float(rng.lognormal(mean=0.0, sigma=0.30))
        raw = float(np.clip(raw, 0.15, 3.5))

        true_label = classify(raw, exam_type)

        # Add measurement-style noise to the *feature* too (mirrors the fact
        # that published "cutoffs" are themselves only approximate/illustrative)
        noisy_strength = raw * float(rng.normal(1.0, 0.04))

        label = true_label
        if rng.random() < LABEL_NOISE_RATE:
            idx = CLASSES.index(true_label)
            shift = int(rng.choice([-1, 1]))
            label = CLASSES[int(np.clip(idx + shift, 0, len(CLASSES) - 1))]

        rows.append(dict(
            relativeStrength=round(noisy_strength, 4),
            examType=exam_type,
            chance=label,
        ))
    return pd.DataFrame(rows)


def build_feature_matrix(df, encoder=None, fit=False):
    if fit:
        encoder = LabelEncoder().fit(df["examType"])
    exam_enc = encoder.transform(df["examType"])
    X = np.column_stack([df["relativeStrength"].to_numpy(dtype=float), exam_enc])
    return X, encoder


def main():
    print(f"Generating {N_SAMPLES} synthetic admission-chance samples...")
    df = generate_dataset()
    csv_path = os.path.join(HERE, "admission_dataset.csv")
    df.to_csv(csv_path, index=False)
    print(f"Saved dataset -> {csv_path} ({len(df)} rows)")

    X, encoder = build_feature_matrix(df, fit=True)
    y = df["chance"].to_numpy()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=8,
        min_samples_split=8,
        min_samples_leaf=4,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    cv_scores = cross_val_score(model, X, y, cv=5)
    report = classification_report(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred, labels=model.classes_)

    report_path = os.path.join(HERE, "admission_training_report.txt")
    with open(report_path, "w") as f:
        f.write("Smart Career Advisor — Admission Chance Model Training Report\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Samples: {len(df)} (train={len(X_train)}, test={len(X_test)})\n")
        f.write(f"Test accuracy: {acc:.4f}\n")
        f.write(f"5-fold CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})\n\n")
        f.write("Classification report:\n")
        f.write(report + "\n\n")
        f.write(f"Confusion matrix (rows=true, cols=pred), class order = {list(model.classes_)}\n")
        f.write(np.array2string(cm) + "\n")

    print(f"Test accuracy: {acc:.4f}")
    print(f"5-fold CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    print(f"Full report -> {report_path}")

    joblib.dump(model, os.path.join(HERE, "admission_model.pkl"))
    joblib.dump(encoder, os.path.join(HERE, "admission_preprocessor.pkl"))
    print("Saved admission_model.pkl, admission_preprocessor.pkl")


if __name__ == "__main__":
    main()
