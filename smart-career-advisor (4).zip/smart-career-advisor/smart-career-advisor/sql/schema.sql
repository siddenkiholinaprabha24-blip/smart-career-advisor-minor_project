-- Smart Career Advisor — MySQL Schema & Seed Data
CREATE DATABASE IF NOT EXISTS smart_career_advisor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_career_advisor;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(150) NOT NULL, email VARCHAR(200) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL, phone VARCHAR(20), board ENUM('CBSE','ICSE','State','IB','Other') DEFAULT 'CBSE',
  class12_marks DECIMAL(5,2), class10_marks DECIMAL(5,2), family_income DECIMAL(12,2), city VARCHAR(100), state VARCHAR(100),
  gender ENUM('Male','Female','Other') DEFAULT NULL, selected_exam_id INT DEFAULT NULL,
  career_choice VARCHAR(100), readiness_score INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS careers (
  id INT AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(80) NOT NULL UNIQUE, title VARCHAR(150) NOT NULL, icon VARCHAR(10),
  description TEXT, avg_salary_min DECIMAL(10,2), avg_salary_max DECIMAL(10,2), duration_years TINYINT,
  difficulty ENUM('Moderate','High','Very High','Extremely High') DEFAULT 'High',
  market_demand ENUM('Moderate','High','Very High') DEFAULT 'High', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS exams (
  id INT AUTO_INCREMENT PRIMARY KEY, career_id INT, name VARCHAR(150) NOT NULL, full_form VARCHAR(255),
  conducting_body VARCHAR(200), exam_date VARCHAR(100), registration_date VARCHAR(100), frequency VARCHAR(80),
  mode ENUM('Online','Offline','Both') DEFAULT 'Online', syllabus JSON, prep_tips JSON, official_url VARCHAR(300),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS colleges (
  id INT AUTO_INCREMENT PRIMARY KEY, career_id INT, name VARCHAR(200) NOT NULL, location VARCHAR(200),
  rank_nirf INT, tuition_fee DECIMAL(10,2), hostel_fee DECIMAL(10,2), exam_fee DECIMAL(10,2), other_fee DECIMAL(10,2),
  total_fee_4yr DECIMAL(12,2), seats INT, acceptance_rate DECIMAL(5,2), website VARCHAR(300),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS loans (
  id INT AUTO_INCREMENT PRIMARY KEY, bank_name VARCHAR(150) NOT NULL, scheme_name VARCHAR(200),
  min_amount DECIMAL(12,2), max_amount DECIMAL(12,2), interest_rate DECIMAL(5,2),
  rate_type ENUM('Fixed','Floating','Both') DEFAULT 'Floating', moratorium VARCHAR(100), max_tenure TINYINT,
  collateral_req BOOLEAN DEFAULT FALSE, collateral_limit DECIMAL(12,2), processing_fee DECIMAL(6,4),
  eligibility JSON, documents JSON, special_features TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS scholarships (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200) NOT NULL, provider VARCHAR(200),
  type ENUM('Government','Private','International','University') DEFAULT 'Government',
  amount_per_year DECIMAL(10,2), total_amount DECIMAL(12,2), eligibility JSON, career_ids JSON,
  application_start VARCHAR(100), application_end VARCHAR(100), portal_url VARCHAR(300),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assessments (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, career_id INT,
  math_score DECIMAL(5,2), science_score DECIMAL(5,2), english_score DECIMAL(5,2), aptitude_score DECIMAL(5,2),
  tech_skills INT, communication INT, research_interest INT, leadership INT,
  suitability_score DECIMAL(5,2), readiness_score DECIMAL(5,2), skill_gaps JSON, recommendation TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS financial_plans (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, career_id INT,
  total_cost DECIMAL(12,2), loan_amount DECIMAL(12,2), loan_bank_id INT, interest_rate DECIMAL(5,2),
  tenure_months INT, emi_amount DECIMAL(10,2), total_interest DECIMAL(12,2),
  scholarship_ids JSON, scholarship_total DECIMAL(12,2), loan_probability DECIMAL(5,2),
  scholarship_prob DECIMAL(5,2), savings_required DECIMAL(12,2), action_plan JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE SET NULL,
  FOREIGN KEY (loan_bank_id) REFERENCES loans(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS documents (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
  doc_type ENUM('Marksheet_10','Marksheet_12','Income_Certificate','Caste_Certificate','Aadhaar','PAN','Passport_Photo','Bank_Statement','Admission_Letter','Fee_Receipt','Domicile','Scholarship_Form') NOT NULL,
  file_name VARCHAR(255), file_size INT, status ENUM('Pending','Uploaded','Verified','Rejected') DEFAULT 'Pending',
  uploaded_at TIMESTAMP NULL, verified_at TIMESTAMP NULL, remarks TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, title VARCHAR(255) NOT NULL, message TEXT,
  type ENUM('info','success','warning','error') DEFAULT 'info', is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- SEED: Careers
INSERT INTO careers (slug,title,icon,description,avg_salary_min,avg_salary_max,duration_years,difficulty,market_demand) VALUES
('engineering','B.Tech Engineering','⚙️','Premier technical degree covering CS, ECE, Mechanical, Civil. Gateway to software, manufacturing and research.',600000,2500000,4,'High','Very High'),
('mbbs','MBBS / Doctor','🩺','Bachelor of Medicine & Surgery. The definitive path to becoming a licensed physician in India.',800000,4000000,5,'Extremely High','Very High'),
('pilot','Commercial Pilot (CPL)','✈️','Commercial Pilot License training. Fly for major domestic and international airlines.',1800000,8000000,3,'Very High','High'),
('abroad-ms','MS Abroad (USA/UK/Canada)','🌍','Masters from top global universities. Opens doors to global tech companies and research labs.',5000000,15000000,2,'Very High','Very High'),
('civil-services','Civil Services (IAS/IPS)','🏛️','UPSC Civil Services. Join IAS, IPS, IFS — most prestigious administrative career in India.',700000,2200000,1,'Extremely High','Moderate');

-- SEED: Exams
INSERT INTO exams (career_id,name,full_form,conducting_body,exam_date,registration_date,frequency,mode,syllabus,prep_tips,official_url) VALUES
(1,'JEE Main','Joint Entrance Examination Main','NTA','Jan & Apr','Nov & Feb','Twice a year','Online','["Physics: Mechanics, Electricity, Optics","Mathematics: Algebra, Calculus, Coordinate Geometry","Chemistry: Organic, Inorganic, Physical"]','["Practice 10+ years papers","Target 99+ percentile for top NITs","Daily 8hr study schedule","Focus on NCERT first"]','https://jeemain.nta.nic.in'),
(1,'JEE Advanced','Joint Entrance Examination Advanced','IIT Bombay','May','April','Once a year','Online','["Physics: Advanced Mechanics, EM Induction","Mathematics: Complex Numbers, Integration","Chemistry: Stereochemistry, Electrochemistry"]','["Only top 2.5L JEE Main qualifiers eligible","Solve previous IIT papers","Focus on conceptual depth"]','https://jeeadv.ac.in'),
(2,'NEET UG','National Eligibility cum Entrance Test','NTA','May','March','Once a year','Offline','["Biology: Zoology & Botany (50% weightage)","Physics: Mechanics, Optics","Chemistry: Organic, Inorganic, Physical"]','["Need 600+ for govt college","NCERT is the Bible","Solve 30 years NEET/AIPMT papers"]','https://neet.nta.nic.in'),
(3,'IGRUA CPL','IGRUA CPL Entrance','IGRUA','Twice a year','Jun & Dec','Twice a year','Both','["Mathematics: Algebra, Trigonometry","Physics: Mechanics, Fluid Dynamics","English Comprehension","General Aptitude"]','["Class 12 PCM mandatory","English critical for ATC","DGCA Class 1 Medical required"]','https://igrua.gov.in'),
(4,'GRE','Graduate Record Examinations','ETS','Year-round','2-3 months before','Year-round','Online','["Verbal Reasoning: Reading Comprehension","Quantitative Reasoning: Algebra, Data Analysis","Analytical Writing: Issue & Argument"]','["Target 320+ for top US universities","6 months prep","Manhattan Prep recommended"]','https://ets.org/gre'),
(4,'TOEFL','Test of English as a Foreign Language','ETS','Year-round','3+ months before','Year-round','Online','["Reading: Academic passages","Listening: Lectures","Speaking: Independent and integrated","Writing: Essays"]','["Score 100+ iBT for top universities","Practice with official material"]','https://ets.org/toefl'),
(5,'UPSC CSE','Union Public Service Commission Civil Services','UPSC','Jun (Prelims), Sep (Mains)','February','Once a year','Offline','["Prelims: GS Paper I + CSAT","Mains: 9 Papers — Essay, GS I-IV, Optional","Interview: Personality Test 275 Marks"]','["Average 4-5 attempts","Newspaper daily mandatory","Optional subject selection crucial"]','https://upsc.gov.in');

-- SEED: Colleges
INSERT INTO colleges (career_id,name,location,rank_nirf,tuition_fee,hostel_fee,exam_fee,other_fee,total_fee_4yr,seats,acceptance_rate,website) VALUES
(1,'IIT Bombay','Mumbai, Maharashtra',1,220000,120000,2000,30000,1488000,880,0.5,'https://iitb.ac.in'),
(1,'IIT Delhi','New Delhi',2,210000,115000,2000,28000,1420000,850,0.6,'https://iitd.ac.in'),
(1,'NIT Trichy','Tiruchirappalli, Tamil Nadu',8,150000,90000,1500,20000,1046000,1200,2.1,'https://nitt.edu'),
(1,'BITS Pilani','Pilani, Rajasthan',26,450000,180000,3000,50000,2732000,600,3.0,'https://bits-pilani.ac.in'),
(2,'AIIMS New Delhi','New Delhi',1,5000,24000,1700,15000,227000,100,0.03,'https://aiims.edu'),
(2,'CMC Vellore','Vellore, Tamil Nadu',2,120000,60000,2000,25000,935000,60,0.2,'https://cmch-vellore.edu'),
(2,'Kasturba Medical','Manipal, Karnataka',10,1200000,180000,3000,40000,7115000,150,1.5,'https://manipal.edu'),
(3,'IGRUA','Rae Bareli, UP',NULL,3500000,200000,5000,80000,14340000,50,5.0,'https://igrua.gov.in'),
(3,'Indigo Cadet Program','Pan India',NULL,6000000,300000,10000,100000,24440000,30,2.0,'https://goindigo.in'),
(4,'MIT','Cambridge, USA',1,4900000,0,0,0,9800000,150,3.9,'https://mit.edu'),
(4,'Stanford University','California, USA',2,4700000,0,0,0,9400000,120,4.3,'https://stanford.edu'),
(4,'Univ of Toronto','Ontario, Canada',21,3200000,0,0,0,6400000,200,35.0,'https://utoronto.ca'),
(5,'LBSNAA','Mussoorie, Uttarakhand',NULL,0,0,0,0,0,180,0.1,'https://lbsnaa.gov.in');

-- SEED: Loans
INSERT INTO loans (bank_name,scheme_name,min_amount,max_amount,interest_rate,rate_type,moratorium,max_tenure,collateral_req,collateral_limit,processing_fee,eligibility,documents,special_features) VALUES
('SBI','SBI Scholar Loan',500000,4000000,8.15,'Floating','Course + 1 year',15,TRUE,750000,0.0050,'{"min_marks":"60%","age":"16-35","co_applicant":"Parent/Guardian mandatory"}','["Marksheets","Admission Letter","Fee Structure","Income Proof","Aadhaar/PAN","Photos","Bank Statements","Collateral Docs"]','0.5% concession for girl students; No processing fee for premier institutions'),
('HDFC Credila','HDFC Credila Education Loan',100000,15000000,9.55,'Floating','Course + 6 months',14,FALSE,750000,0.0100,'{"min_marks":"50%","co_borrower":"Mandatory"}','["KYC Documents","Admission Confirmation","Fee Receipt","Income Proof","Bank Statements","Academic Records"]','Covers 100% tuition; No collateral up to 7.5L; Pre-admission sanction available'),
('Axis Bank','Axis Bank Education Loan',500000,7500000,8.70,'Floating','Course + 12 months',15,TRUE,400000,0.0075,'{"min_marks":"55%","age":"18-35","citizenship":"Indian Nationals only"}','["Marksheets","Admission Letter","Fee Schedule","Income Certificate","Property Docs","Aadhaar & PAN"]','0.5% discount online; Tax benefit Section 80E; Flexible repayment options');

-- SEED: Scholarships
INSERT INTO scholarships (name,provider,type,amount_per_year,total_amount,eligibility,career_ids,application_start,application_end,portal_url) VALUES
('National Scholarship Portal (NSP)','Ministry of Education, GoI','Government',25000,100000,'{"min_marks":80,"max_income":800000,"category":"All categories"}','[1,2,3,4,5]','August','October','https://scholarships.gov.in'),
('Jagananna Vidya Deevena','Andhra Pradesh Government','Government',60000,240000,'{"min_marks":0,"max_income":250000,"domicile":"Andhra Pradesh"}','[1,2,5]','September','November','https://navasakam.ap.gov.in'),
('AICTE Pragati Scholarship','AICTE, Ministry of Education','Government',50000,200000,'{"min_marks":60,"max_income":800000,"gender":"Female","institution":"AICTE approved"}','[1]','October','December','https://www.aicte-pragati-saksham-gov.in'),
('HDFC Educational Crisis Scholarship','HDFC Bank Parivartan','Private',75000,300000,'{"min_marks":55,"max_income":500000,"condition":"Family financial crisis"}','[1,2,3,4,5]','July','September','https://www.hdfcbank.com/scholarships'),
('Inlaks Shivdasani Scholarship','Inlaks Foundation','Private',3500000,7000000,'{"min_marks":85,"condition":"Top universities abroad","age":"Below 30"}','[4]','January','March','https://www.inlaksfoundation.org'),
('KVPY Fellowship','IISc Bangalore / DST','Government',80000,320000,'{"min_marks":75,"exam":"KVPY aptitude test","stream":"Science stream"}','[1,4]','July','August','https://kvpy.iisc.ac.in');

CREATE INDEX IF NOT EXISTS idx_assessments_user ON assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_financial_user ON financial_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_exams_career ON exams(career_id);
CREATE INDEX IF NOT EXISTS idx_colleges_career ON colleges(career_id);
