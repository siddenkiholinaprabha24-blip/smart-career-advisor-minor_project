"""
ml_engine.py — loads the trained scikit-learn model + preprocessor and
exposes predict_profile(), used by the /api/assessments endpoint.

This is the real ML replacement for the old rule-based AIEngine.calcCareerSuitability
JS function. If model.pkl is missing, run `python ml/train_model.py` first
(app.py also auto-trains on first boot if artifacts are absent).
"""

import json
import os

import joblib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ML_DIR = os.path.join(HERE, "ml")

MODEL_PATH = os.path.join(ML_DIR, "model.pkl")
PREPROC_PATH = os.path.join(ML_DIR, "preprocessor.pkl")
CAREERS_MAP_PATH = os.path.join(ML_DIR, "careers_map.json")

FEATURE_COLUMNS_NUMERIC = [
    "marks12", "marks10", "mathScore", "scienceScore", "englishScore",
    "techSkills", "communication", "leadership", "researchInterest", "familyIncome",
]

EDU_LEVEL_TO_GROUP = {
    "10th": "school",
    "inter_mpc": "inter", "inter_bipc": "inter", "inter_mec": "inter",
    "inter_cec": "inter", "inter_hec": "inter", "inter_other": "inter",
    "polytechnic": "poly", "diploma": "poly",
    "degree": "grad", "btech": "grad", "mbbs": "grad",
    "postgraduate": "grad", "other": "grad",
}

_model = None
_encoders = None
_careers_map = None
MODEL_VERSION = "rf-v2"


def _ensure_loaded():
    global _model, _encoders, _careers_map
    if _model is not None:
        return
    if not (os.path.exists(MODEL_PATH) and os.path.exists(PREPROC_PATH)):
        # Train on the fly if artifacts don't exist yet (first-run convenience).
        from ml.train_model import main as train_main
        train_main()
    _model = joblib.load(MODEL_PATH)
    _encoders = joblib.load(PREPROC_PATH)
    with open(CAREERS_MAP_PATH) as f:
        _careers_map = {int(k): v for k, v in json.load(f).items()}


def _safe_encode(encoder, value, fallback_index=0):
    try:
        return int(encoder.transform([value])[0])
    except ValueError:
        return fallback_index


def edu_group_from_level(edu_level: str) -> str:
    return EDU_LEVEL_TO_GROUP.get(edu_level, "inter")


def predict_profile(profile: dict):
    """
    profile keys expected (matches buildDerivedProfile() in the frontend):
      marks12, marks10, mathScore, scienceScore, englishScore,
      techSkills, communication, leadership, researchInterest,
      familyIncome, eduGroup (or eduLevel), gender

    Returns:
      {
        predictedCareerId, predictedCareerSlug, confidence,
        probabilities: {careerId: probabilityPercent, ...},
        modelVersion
      }
    """
    _ensure_loaded()

    numeric = [float(profile.get(col, 0) or 0) for col in FEATURE_COLUMNS_NUMERIC]

    edu_group = profile.get("eduGroup") or edu_group_from_level(profile.get("eduLevel", ""))
    edu_enc = _safe_encode(_encoders["eduGroup"], edu_group)
    gender_enc = _safe_encode(_encoders["gender"], profile.get("gender", "Male"))

    X_numeric = _encoders["scaler"].transform([numeric])
    X = np.hstack([X_numeric, [[edu_enc, gender_enc]]])

    proba = _model.predict_proba(X)[0]
    classes = _model.classes_  # career ids in model's class order

    probabilities = {int(c): round(float(p) * 100, 2) for c, p in zip(classes, proba)}
    predicted_id = int(classes[int(np.argmax(proba))])

    return {
        "predictedCareerId": predicted_id,
        "predictedCareerSlug": _careers_map.get(predicted_id),
        "confidence": probabilities[predicted_id],
        "probabilities": probabilities,
        "modelVersion": MODEL_VERSION,
    }


def suitability_for(profile: dict, career_id: int) -> float:
    """Probability (0-100) the model assigns to a *specific* requested
    career for this profile — this is what the UI shows as
    'Career Suitability' for the student's chosen path."""
    result = predict_profile(profile)
    return result["probabilities"].get(int(career_id), 0.0)
