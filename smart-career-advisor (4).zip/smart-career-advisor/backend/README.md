# Smart Career Advisor — Flask + ML Backend

A genuine machine-learning backend for the existing Smart Career Advisor
frontend. Career-fit prediction is done by a **trained scikit-learn
`RandomForestClassifier`**, not hand-coded if/else rules. All user data,
assessments, financial plans, documents and notifications are persisted in
a **SQLite database** (swappable to MySQL — see below).

---

## 1. What changed vs. what stayed the same

| Area | Status |
|---|---|
| `index.html`, `css/style.css`, `js/data.js`, `sql/schema.sql` | **Untouched** — byte-identical to your latest upload |
| `js/app.js` | **Edited** — every `localStorage` read/write for auth, assessments, financial plans, documents, and notifications was replaced with a `fetch()` call to the new Flask API. No HTML markup, CSS classes, layout, or navigation logic changed. |
| Career-fit prediction (`AIEngine.calcCareerSuitability`) | **Replaced** with a real trained ML model served by `/api/assessments`, retrained on the new 10-career catalogue (added M.Tech) and the new education-level / multi-select-skills data model |
| Loan probability / scholarship probability / EMI / college cutoff lookups | Kept as deterministic formulas (ported 1:1 to Python in `business_logic.py`) — these are closed-form calculations and static-data lookups, not classification problems. Scholarship/college/exam/government-job **reference data** stays in `js/data.js` on the frontend since it's static catalogue content, not user data. |

## 1a. Data model (matches the current evaluator)

The evaluator no longer collects per-subject marks (Math/Physics/Chemistry/Biology) directly. Instead it collects:
- **Education level** (10th / Intermediate stream / Polytechnic / Degree / etc.) → grouped into `school`/`inter`/`poly`/`grad` for the model
- **Marks12 / Marks10**, family income, gender
- **Multi-select skill tags** (Coding, Communication, Leadership, Mathematics, etc.) — the frontend derives `mathScore`/`scienceScore`/`englishScore`/`techSkills`/`communication`/`leadership` from these tags + marks (see `buildDerivedProfile()` in `js/app.js`), and that derived profile is what's sent to the ML endpoint
- **Research interest** (1–5), preferred career (now 10 options including M.Tech), government-job interest, higher-studies interest


## 2. Project structure

```
smart-career-advisor/          # frontend — unchanged except js/app.js
  index.html
  css/style.css
  js/data.js                   # untouched
  js/app.js                    # edited: localStorage -> fetch() calls
  sql/schema.sql                # original reference schema (unchanged)

backend/
  app.py                       # Flask app entrypoint, registers routes, serves frontend
  db.py                        # SQLite schema + connection helper
  auth.py                      # JWT issue/verify, @login_required decorator
  ml_engine.py                 # loads model.pkl, runs inference
  business_logic.py            # loan/scholarship/EMI/readiness/skill-gap formulas
  reference_data.py            # career titles + scholarship eligibility rules
  routes/
    auth_routes.py             # /api/auth/*
    user_routes.py             # /api/users/*
    assessment_routes.py       # /api/assessments/*  (the ML endpoint)
    financial_routes.py        # /api/financial/*
    document_routes.py         # /api/documents/*
    notification_routes.py     # /api/notifications/*
  ml/
    train_model.py             # generates dataset + trains + saves model.pkl
    career_dataset.csv         # generated synthetic training data (6000 rows)
    model.pkl                  # trained RandomForestClassifier
    preprocessor.pkl           # fitted LabelEncoders + StandardScaler
    careers_map.json           # careerId -> slug mapping
    training_report.txt        # accuracy / classification report / feature importances
  instance/
    career_advisor.db          # SQLite database (created automatically)
  requirements.txt
```

## 3. Setup & run

Requires **Python 3.10+**.

```bash
cd backend
pip install -r requirements.txt --break-system-packages   # drop the flag if using a venv

# (optional — app.py auto-trains on first run if these are missing)
python train_model.py    # from inside ml/, or: python ml/train_model.py from backend/

python app.py
```

The backend:
1. Initializes the SQLite database at `backend/instance/career_advisor.db` (auto-created).
2. Loads (or trains, on first run) the ML model.
3. Serves the **existing frontend unchanged** at `http://localhost:5000/`.
4. Serves the REST API at `http://localhost:5000/api/*`.

Open `http://localhost:5000` in your browser — frontend and backend run together from a single command, no separate dev server or CORS setup needed.

**Running the frontend separately** (e.g. via `python -m http.server` or a different port) also works — CORS is enabled on all `/api/*` routes. If your API isn't on the same origin, set `window.SCA_API_BASE = 'http://localhost:5000'` in a small `<script>` before `js/app.js` loads.

### Retraining the model
```bash
cd backend
python ml/train_model.py
```
This regenerates `career_dataset.csv`, retrains, and overwrites `model.pkl` / `preprocessor.pkl` / `training_report.txt`. Current model (`rf-v2`, 10 career classes including M.Tech): **73.4% test accuracy**, 72.2% 5-fold CV accuracy (see `ml/training_report.txt` for the full classification report and confusion matrix — accuracy is intentionally not 100%, since the synthetic dataset includes realistic class overlap and ~6% label noise).

## 4. Switching to MySQL

All queries in `db.py` use plain parameterized SQL with `?` placeholders (sqlite3 style). To use MySQL:
1. `pip install pymysql`
2. In `db.py`, replace `get_conn()` with a `pymysql.connect(...)` call (returning `pymysql.cursors.DictCursor` rows), and change `?` placeholders to `%s` throughout the route files (a find/replace).
3. Replace `datetime('now')` in `SCHEMA` with `NOW()`, and `AUTOINCREMENT` with `AUTO_INCREMENT`.
4. Run the adjusted `SCHEMA` once (or use `sql/schema.sql` from the frontend package as your starting point, extended with the columns in `db.py`'s `SCHEMA` string).

## 5. Files added or modified

**Added (all new):**
- `backend/app.py`, `backend/db.py`, `backend/auth.py`, `backend/ml_engine.py`, `backend/business_logic.py`, `backend/reference_data.py`
- `backend/routes/auth_routes.py`, `user_routes.py`, `assessment_routes.py`, `financial_routes.py`, `document_routes.py`, `notification_routes.py`
- `backend/ml/train_model.py` (+ generated `career_dataset.csv`, `model.pkl`, `preprocessor.pkl`, `careers_map.json`, `training_report.txt`)
- `backend/requirements.txt`, `backend/README.md` (this file)

**Modified:**
- `js/app.js` — all `localStorage`-based persistence replaced with `fetch()` calls to the Flask API; `AIEngine.calcCareerSuitability` usage replaced with a call to `POST /api/assessments` (real ML inference)

**Unchanged (byte-identical to your upload):**
- `index.html`, `css/style.css`, `js/data.js`, `sql/schema.sql`

## 6. Authentication

Login/register return a JWT (`token`). The frontend stores only this token in `localStorage` (`sca_token`) — no user data — and sends it as `Authorization: Bearer <token>` on every subsequent request. Tokens expire after 7 days.

---

## 7. Sample API requests & responses

### Register
```
POST /api/auth/register
Content-Type: application/json

{ "name": "Arjun Sharma", "email": "arjun@test.com", "password": "secret123", "educationLevel": "inter_mpc" }
```
```json
{
  "user": { "id": 1, "name": "Arjun Sharma", "email": "arjun@test.com", "educationLevel": "inter_mpc",
            "familyIncome": 0, "careerChoice": null, "readinessScore": 0, "createdAt": "2026-07-11 06:56:18" },
  "token": "eyJhbGciOiJIUzI1NiIs..."
}
```

### Login
```
POST /api/auth/login
{ "email": "arjun@test.com", "password": "secret123" }
```
→ same shape as register.

### Run a career assessment (real ML inference)
```
POST /api/assessments
Authorization: Bearer <token>

{
  "eduLevel": "inter_mpc", "marks12": 88, "marks10": 91, "familyIncome": 650000,
  "mathScore": 96, "scienceScore": 88, "englishScore": 88,
  "techSkills": 5, "communication": 2, "leadership": 2, "researchInterest": 4,
  "careerId": 1, "gender": "Male", "skills": ["Coding", "Mathematics", "Problem Solving"],
  "govtInterest": false, "higherEdInterest": true
}
```
```json
{
  "id": 1,
  "careerId": 1,
  "careerTitle": "B.Tech Engineering",
  "suitabilityScore": 61.3,
  "readinessScore": 57,
  "skillGaps": [],
  "predictedCareerId": 1,
  "predictedCareerSlug": "engineering",
  "predictedConfidence": 61.3,
  "probabilities": { "1": 61.3, "2": 0.9, "3": 2.1, "4": 22.4, "5": 0.3, "6": 0.2, "7": 4.1, "8": 0.6, "9": 0.1, "10": 8.0 },
  "modelVersion": "rf-v2",
  "timestamp": "2026-07-11 06:56:22"
}
```

### Financial prediction
```
POST /api/financial/predict
Authorization: Bearer <token>
{ "marks12": 88, "familyIncome": 600000, "careerId": 1, "loanAmount": 1500000, "gender": "Male" }
```
```json
{
  "id": 1, "careerId": 1, "marks12": 88.0, "familyIncome": 600000.0,
  "loanAmount": 1500000.0, "loanProbability": 60, "scholarshipProb": 40,
  "actionPlan": [
    { "step": 1, "action": "Prepare Document Checklist", "detail": "Upload all required documents..." },
    { "step": 2, "action": "Open Education Loan Account", "detail": "Visit the nearest SBI/HDFC branch..." }
  ],
  "timestamp": "2026-07-10 03:36:05"
}
```

### Document upload
```
POST /api/documents/upload
Authorization: Bearer <token>
{ "docKey": "Marksheet_10", "fileName": "marks.pdf", "fileSize": 20480 }
```
```json
{ "docKey": "Marksheet_10", "status": "uploaded" }
```

### Notifications
```
GET /api/notifications
Authorization: Bearer <token>
```
```json
{ "notifications": [
  { "id": 3, "title": "Welcome back!", "msg": "Good to see you, Arjun!", "type": "success", "icon": "👋", "read": false, "time": "2026-07-10 03:36:00" }
]}
```
