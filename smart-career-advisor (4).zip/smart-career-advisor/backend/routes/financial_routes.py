import json

from flask import Blueprint, g, jsonify, request

from auth import login_required
from business_logic import calc_emi, calc_loan_probability, calc_scholarship_probability, generate_action_plan
from db import db_cursor, row_to_dict, jloads
from reference_data import match_scholarships

bp = Blueprint("financial_routes", __name__, url_prefix="/api/financial")


def _row_to_plan_json(row):
    d = row_to_dict(row)
    if not d:
        return None
    return {
        "id": d["id"],
        "careerId": d["career_id"],
        "marks12": d["marks12"],
        "familyIncome": d["family_income"],
        "loanAmount": d["loan_amount"],
        "loanProbability": d["loan_probability"],
        "scholarshipProb": d["scholarship_prob"],
        "actionPlan": jloads(d["action_plan"], []),
        "timestamp": d["created_at"],
    }


@bp.post("/predict")
@login_required
def predict():
    body = request.get_json(force=True) or {}
    marks12 = float(body.get("marks12") or 0)
    family_income = float(body.get("familyIncome") or 0)
    career_id = int(body.get("careerId") or 1)
    loan_amount = float(body.get("loanAmount") or 1000000)
    gender = body.get("gender") or "Male"
    is_school_level = bool(body.get("isSchoolLevel"))

    if not marks12 or not family_income:
        return jsonify({"error": "marks12 and familyIncome are required"}), 400

    loan_prob = None if is_school_level else calc_loan_probability(marks12, family_income, loan_amount)
    schol_prob = calc_scholarship_probability(marks12, family_income, gender)
    action_plan = generate_action_plan(marks12, family_income, career_id, gender, loan_prob, schol_prob, is_school_level)

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO financial_plans
               (user_id, career_id, marks12, family_income, loan_amount, loan_probability, scholarship_prob, action_plan)
               VALUES (?,?,?,?,?,?,?,?)""",
            (g.user_id, career_id, marks12, family_income, loan_amount if not is_school_level else 0,
             loan_prob, schol_prob, json.dumps(action_plan)),
        )
        plan_id = cur.lastrowid
        cur.execute("SELECT * FROM financial_plans WHERE id = ?", (plan_id,))
        row = cur.fetchone()

    result = _row_to_plan_json(row)
    result["isSchoolLevel"] = is_school_level
    return jsonify(result), 201


@bp.get("/plan")
@login_required
def get_plan():
    with db_cursor() as cur:
        cur.execute(
            "SELECT * FROM financial_plans WHERE user_id = ? ORDER BY id DESC LIMIT 1",
            (g.user_id,),
        )
        row = cur.fetchone()
    return jsonify({"plan": _row_to_plan_json(row)})


@bp.delete("/plan")
@login_required
def clear_plan():
    # "Clearing" just stops surfacing a plan on the dashboard; prediction
    # history for the user is preserved in the table for audit purposes.
    return jsonify({"cleared": True})


@bp.get("/scholarships")
@login_required
def scholarships():
    marks12 = float(request.args.get("marks12", 0))
    family_income = float(request.args.get("familyIncome", 0))
    career_id = int(request.args.get("careerId", 1))
    gender = request.args.get("gender", "Male")
    state = request.args.get("state", "")
    matched = match_scholarships(marks12, family_income, career_id, gender, state)
    return jsonify({"matched": matched})


@bp.post("/emi")
@login_required
def emi():
    body = request.get_json(force=True) or {}
    principal = float(body.get("principal") or 0)
    rate = float(body.get("rate") or 0)
    months = int(body.get("months") or 1)
    return jsonify({"emi": round(calc_emi(principal, rate, months), 2)})
