import json

from flask import Blueprint, g, jsonify, request

from auth import login_required
from business_logic import calc_readiness, career_title, skill_gaps
from db import db_cursor, row_to_dict, jloads
from ml_engine import predict_profile, edu_group_from_level

bp = Blueprint("assessment_routes", __name__, url_prefix="/api/assessments")


def _row_to_assessment_json(row):
    d = row_to_dict(row)
    if not d:
        return None
    return {
        "id": d["id"],
        "eduLevel": d["edu_level"],
        "eduPath": d["edu_path"],
        "stream": d["stream"],
        "marks12": d["marks12"],
        "marks10": d["marks10"],
        "familyIncome": d["family_income"],
        "mathScore": d["math_score"],
        "scienceScore": d["science_score"],
        "englishScore": d["english_score"],
        "techSkills": d["tech_skills"],
        "communication": d["communication"],
        "leadership": d["leadership"],
        "researchInterest": d["research_interest"],
        "gender": d["gender"],
        "skills": jloads(d["skills"], []),
        "govtInterest": bool(d["govt_interest"]),
        "govtCategory": d["govt_category"],
        "higherEdInterest": bool(d["higher_ed_interest"]),
        "careerId": d["career_id"],
        "careerTitle": d["career_title"],
        "suitabilityScore": d["suitability_score"],
        "readinessScore": d["readiness_score"],
        "skillGaps": jloads(d["skill_gaps"], []),
        "probabilities": jloads(d["probabilities"], {}),
        "modelVersion": d["model_version"],
        "timestamp": d["created_at"],
    }


@bp.post("")
@login_required
def create_assessment():
    body = request.get_json(force=True) or {}

    required = ["marks12", "careerId"]
    for r in required:
        if body.get(r) in (None, ""):
            return jsonify({"error": f"'{r}' is required"}), 400

    edu_level = body.get("eduLevel") or ""
    edu_path = body.get("eduPath") or ""
    stream = body.get("stream") or ""
    marks12 = float(body.get("marks12"))
    marks10 = float(body.get("marks10") or marks12)
    family_income = float(body.get("familyIncome") or 0)
    math_score = float(body.get("mathScore") or 0)
    science_score = float(body.get("scienceScore") or 0)
    english_score = float(body.get("englishScore") or 0)
    tech_skills = int(body.get("techSkills") or 2)
    communication = int(body.get("communication") or 2)
    leadership = int(body.get("leadership") or 2)
    research_interest = int(body.get("researchInterest") or 3)
    gender = body.get("gender") or "Male"
    skills = body.get("skills") or []
    govt_interest = bool(body.get("govtInterest"))
    govt_category = body.get("govtCategory") or ""
    higher_ed_interest = bool(body.get("higherEdInterest"))
    career_id = int(body.get("careerId"))

    # --- genuine ML inference (replaces the old rule-based AIEngine.calcCareerSuitability) ---
    edu_group = edu_group_from_level(edu_level)
    ml_profile = dict(
        marks12=marks12, marks10=marks10, mathScore=math_score, scienceScore=science_score,
        englishScore=english_score, techSkills=tech_skills, communication=communication,
        leadership=leadership, researchInterest=research_interest,
        familyIncome=family_income, eduGroup=edu_group, gender=gender,
    )
    ml_result = predict_profile(ml_profile)
    suitability = ml_result["probabilities"].get(career_id, 0.0)

    readiness = calc_readiness(marks12, suitability, tech_skills, communication, leadership)
    gaps = skill_gaps(math_score, english_score, tech_skills, research_interest, career_id)
    title = career_title(career_id)

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO assessments (
                user_id, edu_level, edu_path, stream, marks12, marks10, family_income,
                math_score, science_score, english_score,
                tech_skills, communication, leadership, research_interest, gender, skills,
                govt_interest, govt_category, higher_ed_interest,
                career_id, career_title, suitability_score, readiness_score, skill_gaps,
                probabilities, model_version
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                g.user_id, edu_level, edu_path, stream, marks12, marks10, family_income,
                math_score, science_score, english_score,
                tech_skills, communication, leadership, research_interest, gender, json.dumps(skills),
                int(govt_interest), govt_category, int(higher_ed_interest),
                career_id, title, suitability, readiness, json.dumps(gaps),
                json.dumps(ml_result["probabilities"]), ml_result["modelVersion"],
            ),
        )
        assessment_id = cur.lastrowid
        cur.execute("SELECT * FROM assessments WHERE id = ?", (assessment_id,))
        row = cur.fetchone()

        # keep users.readiness_score / career_choice / education_level in sync
        from reference_data import CAREER_SLUGS
        cur.execute(
            "UPDATE users SET readiness_score = ?, career_choice = ?, education_level = ? WHERE id = ?",
            (readiness, CAREER_SLUGS.get(career_id), edu_level, g.user_id),
        )

    result = _row_to_assessment_json(row)
    result["predictedCareerId"] = ml_result["predictedCareerId"]
    result["predictedCareerSlug"] = ml_result["predictedCareerSlug"]
    result["predictedConfidence"] = ml_result["confidence"]
    return jsonify(result), 201


@bp.get("/latest")
@login_required
def latest_assessment():
    with db_cursor() as cur:
        cur.execute(
            "SELECT * FROM assessments WHERE user_id = ? ORDER BY id DESC LIMIT 1",
            (g.user_id,),
        )
        row = cur.fetchone()
    return jsonify({"assessment": _row_to_assessment_json(row)})


@bp.get("/history")
@login_required
def assessment_history():
    with db_cursor() as cur:
        cur.execute(
            "SELECT * FROM assessments WHERE user_id = ? ORDER BY id DESC",
            (g.user_id,),
        )
        rows = cur.fetchall()
    return jsonify({"history": [_row_to_assessment_json(r) for r in rows]})
